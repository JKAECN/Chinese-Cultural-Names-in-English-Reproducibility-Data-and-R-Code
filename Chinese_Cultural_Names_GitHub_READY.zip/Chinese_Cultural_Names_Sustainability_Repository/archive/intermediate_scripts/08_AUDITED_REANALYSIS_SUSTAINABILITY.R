# ============================================================
# 08_AUDITED_REANALYSIS_SUSTAINABILITY.R
#
# Major-revision reanalysis after external review.
#
# Core changes:
#   1) Restore final three-way pathway scheme:
#        source_form / pure_calque / mixed
#      and eliminate "overlap" as a substantive pathway.
#   2) Apply historically defensible no-earlier-than boundaries
#      to date-sensitive political / institutional expressions.
#   3) Restore fixed 20-year and 30-year persistence windows.
#   4) Recompute H1, H2, RQ1-RQ4 after the corrections.
#   5) Report ALL RQ3 interactions + within-domain simple effects.
#   6) Historical-spelling sensitivity uses ONLY individually
#      verified historical variants with variant-specific boundaries.
#      Unverified Nien / tang chung forms are explicitly blocked.
#   7) Bootstrap the paired change in pathway coefficient (delta-b).
#
# IMPORTANT:
#   The previous kappa=.972 described agreement under the provisional
#   pathway scheme. It should NOT be presented as proof that the
#   revised three-way labels are correct. The rule-sensitive cases
#   below are etymologically adjudicated and exported for audit.
# ============================================================


# ------------------------------------------------------------
# 0. SETTINGS
# ------------------------------------------------------------
ROOT_DIR <- "E:/论文/中国文化/英语中的中文"
OUT_DIR  <- file.path(ROOT_DIR, "AUDITED_REANALYSIS_OUTPUTS")
dir.create(OUT_DIR, recursive = TRUE, showWarnings = FALSE)

YEAR_START <- 1800L
YEAR_END   <- 2022L
MONTE_CARLO_B <- 50000L
BOOT_B <- 2000L
INSTALL_MISSING <- TRUE

# Optional overrides
FINAL_ANNUAL_OVERRIDE <- NA_character_
HIST_VARIANTS_OVERRIDE <- NA_character_
HIST_MAP_OVERRIDE <- NA_character_

# Main sustained-onset definition
MAIN_WINDOW <- 5L
MAIN_MIN_POSITIVE <- 3L


# ------------------------------------------------------------
# 1. PACKAGES
# ------------------------------------------------------------
packages <- c(
  "readr","dplyr","tidyr","stringr","purrr","forcats",
  "ggplot2","slider","broom","sandwich","lmtest","mgcv",
  "scales","ggrepel","tibble"
)

missing_packages <- packages[
  !vapply(packages, requireNamespace, logical(1), quietly = TRUE)
]

if (length(missing_packages) > 0) {
  if (!INSTALL_MISSING) {
    stop("Missing packages: ", paste(missing_packages, collapse=", "))
  }
  install.packages(missing_packages, repos="https://cloud.r-project.org")
}

suppressPackageStartupMessages({
  library(readr); library(dplyr); library(tidyr); library(stringr)
  library(purrr); library(forcats); library(ggplot2); library(slider)
  library(broom); library(sandwich); library(lmtest); library(mgcv)
  library(scales); library(ggrepel); library(tibble)
})

theme_set(
  theme_bw(base_size = 11) +
    theme(
      panel.grid.minor = element_blank(),
      legend.position = "bottom",
      plot.title = element_blank()
    )
)


# ------------------------------------------------------------
# 2. HELPERS
# ------------------------------------------------------------
find_exact <- function(filename, required=TRUE) {
  hits <- list.files(
    ROOT_DIR,
    pattern=paste0("^", gsub("\\.", "\\\\.", filename), "$"),
    recursive=TRUE, full.names=TRUE, ignore.case=TRUE
  )
  if (length(hits)==0) {
    if (required) stop("Cannot find: ", filename)
    return(NA_character_)
  }
  info <- file.info(hits)
  hits[order(info$mtime, decreasing=TRUE)][1]
}

to_logical <- function(x) {
  if (is.logical(x)) return(x)
  z <- tolower(trimws(as.character(x)))
  dplyr::case_when(
    z %in% c("true","t","1","yes","y") ~ TRUE,
    z %in% c("false","f","0","no","n") ~ FALSE,
    TRUE ~ NA
  )
}

write_txt <- function(lines, path) {
  con <- file(path, "wt", encoding="UTF-8")
  on.exit(close(con), add=TRUE)
  writeLines(lines, con, useBytes=TRUE)
}

make_formula <- function(outcome, rhs) {
  as.formula(paste(outcome, "~", paste(rhs, collapse=" + ")))
}

safe_vcovHC <- function(model) {
  tryCatch(sandwich::vcovHC(model, type="HC3"), error=function(e) NULL)
}

tidy_robust <- function(model, model_name, exponentiate=FALSE) {
  vc <- safe_vcovHC(model)
  if (is.null(vc) || any(!is.finite(vc))) {
    return(tibble(
      model=model_name, term=names(coef(model)),
      estimate=unname(coef(model)),
      std_error=NA_real_, statistic=NA_real_, p_value=NA_real_,
      conf_low=NA_real_, conf_high=NA_real_,
      effect_ratio=NA_real_, effect_ratio_low=NA_real_,
      effect_ratio_high=NA_real_, hc3_status="FAILED"
    ))
  }

  ct <- lmtest::coeftest(model, vcov.=vc)
  z <- tibble(
    model=model_name,
    term=rownames(ct),
    estimate=ct[,1],
    std_error=ct[,2],
    statistic=ct[,3],
    p_value=ct[,4],
    conf_low=ct[,1]-1.96*ct[,2],
    conf_high=ct[,1]+1.96*ct[,2],
    hc3_status="PASS"
  )

  if (exponentiate) {
    z <- z %>% mutate(
      effect_ratio=exp(estimate),
      effect_ratio_low=exp(conf_low),
      effect_ratio_high=exp(conf_high)
    )
  } else {
    z <- z %>% mutate(
      effect_ratio=NA_real_,
      effect_ratio_low=NA_real_,
      effect_ratio_high=NA_real_
    )
  }
  z
}

calc_sustained_onset <- function(year, frequency,
                                 window=5L, min_positive=3L) {
  o <- order(year)
  year <- as.integer(year[o])
  frequency <- as.numeric(frequency[o])
  pos <- !is.na(frequency) & frequency > 0

  if (length(pos) < window) return(NA_integer_)

  for (i in seq_len(length(pos)-window+1L)) {
    idx <- i:(i+window-1L)
    if (sum(pos[idx]) >= min_positive) return(year[i])
  }
  NA_integer_
}

calc_sustained_indicator <- function(year, positive,
                                     window=5L, min_positive=3L) {
  o <- order(year)
  year <- as.integer(year[o])
  positive <- as.logical(positive[o])
  positive[is.na(positive)] <- FALSE

  if (length(positive) < window) return(NA_integer_)

  for (i in seq_len(length(positive)-window+1L)) {
    idx <- i:(i+window-1L)
    if (sum(positive[idx]) >= min_positive) return(year[i])
  }
  NA_integer_
}

calc_consecutive_onset <- function(year, frequency, run=3L) {
  o <- order(year)
  year <- as.integer(year[o])
  frequency <- as.numeric(frequency[o])
  pos <- !is.na(frequency) & frequency > 0

  if (length(pos) < run) return(NA_integer_)

  for (i in seq_len(length(pos)-run+1L)) {
    idx <- i:(i+run-1L)
    if (all(pos[idx])) return(year[i])
  }
  NA_integer_
}

calc_fixed_window <- function(year, frequency, onset, width) {
  if (is.na(onset)) return(NA_real_)
  end_year <- onset + width - 1L
  if (end_year > YEAR_END) return(NA_real_)

  use <- year >= onset & year <= end_year
  # Require a complete calendar window after semantic/date filtering.
  if (sum(use) != width) return(NA_real_)
  mean(frequency[use] > 0, na.rm=TRUE)
}

calc_term_metrics <- function(df) {
  df <- df %>% arrange(year)
  year <- df$year
  freq <- df$frequency

  first_positive <- if (any(freq > 0, na.rm=TRUE)) {
    min(year[freq > 0], na.rm=TRUE)
  } else NA_integer_

  onset <- calc_sustained_onset(
    year, freq, MAIN_WINDOW, MAIN_MIN_POSITIVE
  )
  onset4 <- calc_sustained_onset(year, freq, 5L, 4L)
  onset3c <- calc_consecutive_onset(year, freq, 3L)

  roll10 <- slider::slide_dbl(
    freq, mean, .before=4L, .after=5L,
    .complete=TRUE, na.rm=TRUE
  )

  peak10 <- if (all(is.na(roll10))) NA_real_ else max(roll10, na.rm=TRUE)

  if (!is.na(onset)) {
    post <- year >= onset
    exposure_years <- sum(post)
    persistence_to_2022 <- mean(freq[post] > 0, na.rm=TRUE)
  } else {
    exposure_years <- NA_integer_
    persistence_to_2022 <- NA_real_
  }

  contemporary_mean <- mean(
    freq[year >= 2000 & year <= 2022], na.rm=TRUE
  )

  contemporary_retention <- if (is.finite(peak10) && peak10 > 0) {
    contemporary_mean / peak10
  } else NA_real_

  tibble(
    first_positive_year=first_positive,
    sustained_onset=onset,
    sustained_onset_4of5=onset4,
    sustained_onset_3consecutive=onset3c,
    exposure_years=exposure_years,
    persistence_to_2022=persistence_to_2022,
    persistence_20y=calc_fixed_window(year, freq, onset, 20L),
    persistence_30y=calc_fixed_window(year, freq, onset, 30L),
    contemporary_retention=contemporary_retention,
    cumulative_frequency=sum(freq, na.rm=TRUE)
  )
}

collapse_domain3 <- function(x) {
  case_when(
    x %in% c(
      "food_drink","body_medicine_martial",
      "heritage_historical_space","material_culture_architecture"
    ) ~ "material_practice",
    x %in% c(
      "arts_literature_writing_language",
      "festivals_ritual_myth",
      "philosophy_religion_cosmology"
    ) ~ "symbolic_ideational",
    x %in% c(
      "popular_digital","social_political_historical"
    ) ~ "social_political_modern",
    TRUE ~ NA_character_
  )
}


# ------------------------------------------------------------
# 3. INPUTS
# ------------------------------------------------------------
FINAL_ANNUAL_FILE <- if (!is.na(FINAL_ANNUAL_OVERRIDE)) {
  FINAL_ANNUAL_OVERRIDE
} else {
  find_exact("Semantic_Clean_Annual_Data_FINAL.csv")
}

HIST_VARIANTS_FILE <- if (!is.na(HIST_VARIANTS_OVERRIDE)) {
  HIST_VARIANTS_OVERRIDE
} else {
  find_exact("historical_spelling_annual_variants.csv", required=FALSE)
}

HIST_MAP_FILE <- if (!is.na(HIST_MAP_OVERRIDE)) {
  HIST_MAP_OVERRIDE
} else {
  find_exact("historical_spelling_variant_map_predefined.csv", required=FALSE)
}

cat("\nFINAL annual:", FINAL_ANNUAL_FILE, "\n")
cat("Historical variants:", HIST_VARIANTS_FILE, "\n")
cat("Historical map:", HIST_MAP_FILE, "\n\n")


# ------------------------------------------------------------
# 4. READ FINAL SEMANTIC-CLEAN ANNUAL DATA
# ------------------------------------------------------------
raw <- suppressMessages(
  read_csv(FINAL_ANNUAL_FILE, show_col_types=FALSE)
)

needed <- c(
  "row_id","term","ngram_query","pathway",
  "pathway_comparison_eligible","cultural_domain",
  "concept_group","query_risk","case_insensitive",
  "year","frequency","decision","valid_from_year"
)

miss <- setdiff(needed, names(raw))
if (length(miss)>0) {
  stop("Missing columns: ", paste(miss, collapse=", "))
}

raw <- raw %>%
  mutate(
    row_id=as.integer(row_id),
    year=as.integer(year),
    frequency=as.numeric(frequency),
    pathway_comparison_eligible=to_logical(pathway_comparison_eligible),
    case_insensitive=to_logical(case_insensitive)
  )

if (raw %>% count(row_id, year) %>% filter(n>1) %>% nrow() > 0) {
  stop("Duplicate row_id-year records found.")
}


# ------------------------------------------------------------
# 5. FINAL PATHWAY RE-ADJUDICATION
# ------------------------------------------------------------
# These rules restore the earlier corrected Sustainability design.
# Parent-category overlap is NOT a linguistic pathway.
#
# Source-form = source phonological/romanized form retained.
# Pure calque = English morphemes translate the source expression.
# Mixed = source-form component + English translated/generic component.

mixed_terms <- c(
  "Qingming Festival",
  "Gougu theorem",
  "Laba Festival",
  "Chinkiang vinegar",
  "Laba congee",
  "Laba porridge"
)

explicit_calque_terms <- c(
  "Mid-Autumn Festival",
  "Double Ninth Festival",
  "yellow wine",
  "insect wax",
  "white wax",
  "Pure Land"
)

meta0 <- raw %>%
  distinct(
    row_id, term, ngram_query, pathway,
    pathway_comparison_eligible, cultural_domain,
    concept_group, query_risk, case_insensitive,
    decision, valid_from_year
  )

path_audit <- meta0 %>%
  mutate(
    pathway_provisional=pathway,
    pathway_final=case_when(
      term %in% mixed_terms ~ "mixed",
      term %in% explicit_calque_terms ~ "pure_calque",
      pathway == "direct_borrowing" ~ "source_form",
      pathway == "calque" ~ "pure_calque",
      pathway == "overlap_direct_and_calque" ~ "pure_calque",
      TRUE ~ NA_character_
    ),
    pathway_change=pathway_final != case_when(
      pathway=="direct_borrowing" ~ "source_form",
      pathway=="calque" ~ "pure_calque",
      pathway=="overlap_direct_and_calque" ~ "overlap",
      TRUE ~ pathway
    ),
    adjudication_basis=case_when(
      term=="Qingming Festival" ~
        "Wiktionary etymology: partial calque; source form Qingming + English Festival",
      term=="Mid-Autumn Festival" ~
        "Wiktionary etymology: calque of Chinese 中秋節/中秋节",
      term %in% c("Double Ninth Festival","yellow wine","insect wax",
                  "white wax","Pure Land") ~
        "Parent-category overlap resolved by entry-level calque etymology",
      term %in% c("Gougu theorem","Laba Festival","Chinkiang vinegar",
                  "Laba congee","Laba porridge") ~
        "Mixed surface structure: retained source-form component + English generic/translated component",
      pathway=="overlap_direct_and_calque" ~
        "Old overlap label represented category nesting, not a linguistic pathway",
      TRUE ~ "No rule-sensitive reclassification"
    )
  )

write_csv(
  path_audit,
  file.path(OUT_DIR, "PATHWAY_FINAL_AUDIT.csv")
)

cat("\nPathway counts after final adjudication (retained terms):\n")
print(path_audit %>% count(pathway_final))

# Apply pathway labels to annual data
main0 <- raw %>%
  select(-pathway) %>%
  left_join(
    path_audit %>% select(row_id, pathway_final),
    by="row_id"
  ) %>%
  rename(pathway=pathway_final)


# ------------------------------------------------------------
# 6. DATE-CONSISTENCY AUDIT / TEMPORAL GUARDRAILS
# ------------------------------------------------------------
# These are conservative NO-EARLIER-THAN boundaries for target senses.
# They are not claims that the listed year is necessarily the first
# English attestation, except where explicitly noted.
#
# "strict_attestation" = directly documented target English label/use.
# "historical_guardrail" = target entity/practice did not exist earlier.
#
# Uncertain cases should NOT be silently backdated from raw string hits.

date_audit <- tribble(
  ~term, ~audit_boundary, ~boundary_type, ~evidence_note,
  "Belt and Road", 2015L, "strict_attestation",
  "Official English rendering 'the Belt and Road' / 'Belt and Road Initiative' standardized in 2015.",
  "brainwash", 1950L, "strict_attestation",
  "OUP dates the English brainwashing term to 1950; earlier generic 'brain washing' strings are non-target.",
  "brainwashing", 1950L, "strict_attestation",
  "OUP dates the English brainwashing term to 1950; earlier generic strings are non-target.",
  "Eighth Route Army", 1937L, "historical_guardrail",
  "The Eighth Route Army was created in September 1937; pre-1937 hits cannot denote that institution.",
  "Great Leap Forward", 1958L, "historical_guardrail",
  "The PRC Great Leap Forward program began in 1958; earlier generic strings are non-target.",
  "Chinese Dream", 2012L, "historical_guardrail",
  "Xi Jinping first introduced the current political slogan in November 2012; earlier generic 'Chinese dream' strings are non-target.",
  "Four Olds", 1966L, "historical_guardrail",
  "The Four Olds campaign belongs to the Cultural Revolution launched in 1966.",
  "Gang of Four", 1976L, "historical_guardrail",
  "The political faction label refers to Jiang Qing and three associates associated with the 1976 post-Mao crisis.",
  "capitalist roader", 1965L, "historical_guardrail",
  "The Maoist political label is documented from 1965; earlier generic strings cannot carry this target sense.",
  "wumao", 2004L, "historical_guardrail",
  "The paid-online-commentator phenomenon is documented from 2004; earlier hits cannot denote this internet-political sense.",
  "iron rice bowl", 1980L, "strict_conservative_boundary",
  "Conservative English-documentation boundary: English policy discussions are directly documented from 1980; this may understate earlier valid English uses.",
  "struggle session", 1946L, "historical_guardrail",
  "The target Maoist practice is documented in land-reform contexts from the late 1940s; this boundary only removes impossible earlier generic uses."
)

write_csv(
  date_audit,
  file.path(OUT_DIR, "DATE_CONSISTENCY_AUDIT.csv")
)

# Existing semantic valid_from_year remains authoritative when later.
main1 <- main0 %>%
  left_join(date_audit, by="term") %>%
  mutate(
    semantic_valid_from=coalesce(as.integer(valid_from_year), YEAR_START),
    audited_valid_from=case_when(
      !is.na(audit_boundary) ~ pmax(semantic_valid_from, audit_boundary),
      TRUE ~ semantic_valid_from
    )
  ) %>%
  filter(year >= audited_valid_from)

# Save the rebuilt audited annual dataset.
write_csv(
  main1,
  file.path(OUT_DIR, "Semantic_Clean_Annual_Data_AUDITED.csv")
)

date_changes <- main0 %>%
  distinct(row_id, term, valid_from_year) %>%
  left_join(date_audit, by="term") %>%
  mutate(
    original_valid_from=coalesce(as.integer(valid_from_year), YEAR_START),
    audited_valid_from=if_else(
      !is.na(audit_boundary),
      pmax(original_valid_from, audit_boundary),
      original_valid_from
    ),
    years_shifted=audited_valid_from-original_valid_from
  ) %>%
  filter(!is.na(audit_boundary))

write_csv(
  date_changes,
  file.path(OUT_DIR, "DATE_CONSISTENCY_BEFORE_AFTER.csv")
)


# ------------------------------------------------------------
# 7. TERM METRICS INCLUDING FIXED 20/30-YEAR WINDOWS
# ------------------------------------------------------------
term_meta <- main1 %>%
  distinct(
    row_id, term, ngram_query, pathway, cultural_domain,
    concept_group, query_risk, case_insensitive,
    audited_valid_from, decision
  ) %>%
  mutate(
    pathway_binary=if_else(
      pathway %in% c("source_form","pure_calque"),
      pathway, NA_character_
    ),
    pathway_binary=factor(
      pathway_binary,
      levels=c("source_form","pure_calque")
    ),
    token_count=str_count(ngram_query, "\\S+"),
    domain3=factor(
      collapse_domain3(cultural_domain),
      levels=c("material_practice","symbolic_ideational",
               "social_political_modern")
    ),
    query_risk=factor(query_risk, levels=c("low","moderate")),
    case_insensitive=factor(case_insensitive)
  )

term_metrics <- main1 %>%
  group_by(row_id) %>%
  group_modify(~calc_term_metrics(.x)) %>%
  ungroup() %>%
  left_join(term_meta, by="row_id") %>%
  mutate(
    token_count_c=token_count-mean(token_count, na.rm=TRUE)
  )

write_csv(
  term_metrics,
  file.path(OUT_DIR, "TERM_METRICS_AUDITED.csv")
)


# ------------------------------------------------------------
# 8. BROADER DATE SCREEN FOR POLITICAL / INSTITUTIONAL TERMS
# ------------------------------------------------------------
date_screen <- term_metrics %>%
  filter(cultural_domain=="social_political_historical") %>%
  arrange(sustained_onset) %>%
  select(
    row_id, term, pathway, sustained_onset,
    first_positive_year, audited_valid_from,
    query_risk, decision
  ) %>%
  mutate(
    needs_manual_context_check =
      sustained_onset < 1949 & !term %in% date_audit$term
  )

write_csv(
  date_screen,
  file.path(OUT_DIR, "DATE_SCREEN_ALL_SOCIAL_POLITICAL_TERMS.csv")
)


# ------------------------------------------------------------
# 9. H1: FINAL THREE-WAY CODING, BINARY INFERENCE ONLY
# ------------------------------------------------------------
h1 <- term_metrics %>%
  filter(!is.na(pathway_binary))

tab <- table(h1$cultural_domain, h1$pathway_binary)

chi <- suppressWarnings(chisq.test(tab, correct=FALSE))
set.seed(20261029)
chi_mc <- chisq.test(tab, simulate.p.value=TRUE, B=MONTE_CARLO_B)

V <- sqrt(
  as.numeric(chi$statistic) /
    (sum(tab)*min(nrow(tab)-1, ncol(tab)-1))
)

h1_test <- tibble(
  n=sum(tab),
  chi_square=as.numeric(chi$statistic),
  df=as.numeric(chi$parameter),
  p_asymptotic=chi$p.value,
  p_monte_carlo=chi_mc$p.value,
  B=MONTE_CARLO_B,
  cramers_v=V,
  min_expected=min(chi$expected)
)

h1_counts <- as.data.frame.matrix(tab) %>%
  tibble::rownames_to_column("cultural_domain")

h1_resid <- as.data.frame(as.table(chi$stdres)) %>%
  rename(
    cultural_domain=Var1,
    pathway=Var2,
    standardized_residual=Freq
  )

write_csv(h1_test, file.path(OUT_DIR,"H1_FINAL_TEST.csv"))
write_csv(h1_counts, file.path(OUT_DIR,"H1_FINAL_COUNTS.csv"))
write_csv(h1_resid, file.path(OUT_DIR,"H1_FINAL_RESIDUALS.csv"))


# ------------------------------------------------------------
# 10. H2: ONSET + LONG PERSISTENCE + FIXED WINDOWS
# ------------------------------------------------------------
h2 <- term_metrics %>%
  filter(
    !is.na(pathway_binary),
    !is.na(domain3),
    !is.na(sustained_onset),
    !is.na(persistence_to_2022),
    !is.na(contemporary_retention)
  ) %>%
  mutate(
    pathway_binary=relevel(pathway_binary, ref="source_form"),
    domain3=relevel(domain3, ref="material_practice"),
    query_risk=relevel(query_risk, ref="low")
  )

rhs <- c(
  "pathway_binary","domain3","token_count_c",
  "query_risk","case_insensitive"
)

m_onset <- lm(make_formula("sustained_onset", rhs), data=h2)

m_persist <- glm(
  make_formula("persistence_to_2022", rhs),
  data=h2,
  family=quasibinomial(link="logit"),
  weights=exposure_years
)

m_ret <- glm(
  make_formula("contemporary_retention", rhs),
  data=h2,
  family=quasibinomial(link="logit")
)

h2_models <- bind_rows(
  tidy_robust(m_onset,"onset_current_spelling",FALSE),
  tidy_robust(m_persist,"persistence_to_2022",TRUE),
  tidy_robust(m_ret,"contemporary_retention",TRUE)
)

write_csv(
  h2_models,
  file.path(OUT_DIR,"H2_FINAL_ADJUSTED_MODELS.csv")
)

h2_desc <- h2 %>%
  group_by(pathway_binary) %>%
  summarise(
    n=n(),
    onset_median=median(sustained_onset),
    onset_IQR=IQR(sustained_onset),
    persistence_median=median(persistence_to_2022),
    persistence_IQR=IQR(persistence_to_2022),
    retention_median=median(contemporary_retention),
    retention_IQR=IQR(contemporary_retention),
    .groups="drop"
  )

write_csv(
  h2_desc,
  file.path(OUT_DIR,"H2_FINAL_DESCRIPTIVE.csv")
)


# ------------------------------------------------------------
# 11. FIXED 20- AND 30-YEAR PERSISTENCE
# ------------------------------------------------------------
fixed_desc <- term_metrics %>%
  filter(!is.na(pathway_binary)) %>%
  group_by(pathway_binary) %>%
  summarise(
    n20=sum(!is.na(persistence_20y)),
    p20_median=median(persistence_20y, na.rm=TRUE),
    p20_IQR=IQR(persistence_20y, na.rm=TRUE),
    n30=sum(!is.na(persistence_30y)),
    p30_median=median(persistence_30y, na.rm=TRUE),
    p30_IQR=IQR(persistence_30y, na.rm=TRUE),
    .groups="drop"
  )

fixed_tests <- bind_rows(
  broom::tidy(
    wilcox.test(
      persistence_20y ~ pathway_binary,
      data=term_metrics %>%
        filter(!is.na(pathway_binary), !is.na(persistence_20y)),
      exact=FALSE
    )
  ) %>% mutate(window="20_year"),
  broom::tidy(
    wilcox.test(
      persistence_30y ~ pathway_binary,
      data=term_metrics %>%
        filter(!is.na(pathway_binary), !is.na(persistence_30y)),
      exact=FALSE
    )
  ) %>% mutate(window="30_year")
)

# Adjusted fixed-window models, with equal exposure windows.
fit_fixed <- function(outcome, label) {
  d <- term_metrics %>%
    filter(
      !is.na(pathway_binary), !is.na(domain3),
      !is.na(.data[[outcome]])
    ) %>%
    mutate(
      pathway_binary=relevel(pathway_binary, ref="source_form"),
      domain3=relevel(domain3, ref="material_practice"),
      query_risk=relevel(query_risk, ref="low")
    )

  m <- glm(
    make_formula(outcome, rhs),
    data=d,
    family=quasibinomial(link="logit")
  )
  tidy_robust(m,label,TRUE)
}

fixed_models <- bind_rows(
  fit_fixed("persistence_20y","fixed_20y"),
  fit_fixed("persistence_30y","fixed_30y")
)

write_csv(fixed_desc,file.path(OUT_DIR,"FIXED_WINDOW_DESCRIPTIVE.csv"))
write_csv(fixed_tests,file.path(OUT_DIR,"FIXED_WINDOW_WILCOXON.csv"))
write_csv(fixed_models,file.path(OUT_DIR,"FIXED_WINDOW_ADJUSTED_MODELS.csv"))


# ------------------------------------------------------------
# 12. ONSET-DEFINITION / LOW-RISK SENSITIVITY
# ------------------------------------------------------------
fit_onset_alt <- function(outcome,label) {
  d <- term_metrics %>%
    filter(
      !is.na(pathway_binary),!is.na(domain3),
      !is.na(.data[[outcome]])
    ) %>%
    mutate(
      pathway_binary=relevel(pathway_binary,ref="source_form"),
      domain3=relevel(domain3,ref="material_practice"),
      query_risk=relevel(query_risk,ref="low")
    )
  m <- lm(make_formula(outcome,rhs),data=d)
  tidy_robust(m,label,FALSE)
}

onset_sens <- bind_rows(
  fit_onset_alt("sustained_onset","3of5"),
  fit_onset_alt("sustained_onset_4of5","4of5"),
  fit_onset_alt("sustained_onset_3consecutive","3_consecutive")
)

low <- h2 %>% filter(query_risk=="low") %>% droplevels()

low_rhs <- c(
  "pathway_binary","domain3","token_count_c","case_insensitive"
)

low_onset <- lm(
  make_formula("sustained_onset",low_rhs),
  data=low
)

write_csv(
  onset_sens,
  file.path(OUT_DIR,"ONSET_DEFINITION_SENSITIVITY.csv")
)
write_csv(
  tidy_robust(low_onset,"low_query_risk",FALSE),
  file.path(OUT_DIR,"LOW_QUERY_RISK_ONSET_MODEL.csv")
)


# ------------------------------------------------------------
# 13. RQ1: FULL DECADES ONLY; 2020-2022 SEPARATE
# ------------------------------------------------------------
panel <- main1 %>%
  left_join(
    term_metrics %>%
      select(row_id,sustained_onset,pathway_binary),
    by="row_id"
  )

decade <- panel %>%
  filter(year <= 2019) %>%
  mutate(decade=floor(year/10)*10) %>%
  group_by(row_id,term,cultural_domain,decade) %>%
  summarise(
    n_years=n(),
    positive_years=sum(frequency>0,na.rm=TRUE),
    active=positive_years >= ceiling(.30*n_years),
    .groups="drop"
  ) %>%
  filter(active) %>%
  count(decade,cultural_domain,name="active_terms") %>%
  group_by(decade) %>%
  mutate(
    all_active_terms=sum(active_terms),
    domain_share=active_terms/all_active_terms
  ) %>%
  ungroup()

recent2020 <- panel %>%
  filter(year>=2020,year<=2022) %>%
  group_by(row_id,term,cultural_domain) %>%
  summarise(
    n_years=n(),
    positive_years=sum(frequency>0,na.rm=TRUE),
    active=positive_years >= ceiling(.30*n_years),
    .groups="drop"
  ) %>%
  filter(active) %>%
  count(cultural_domain,name="active_terms") %>%
  mutate(period="2020-2022")

write_csv(decade,file.path(OUT_DIR,"RQ1_FULL_DECADES.csv"))
write_csv(recent2020,file.path(OUT_DIR,"RQ1_2020_2022_SUPPLEMENT.csv"))


# ------------------------------------------------------------
# 14. RQ2: DESCRIPTIVE LONG-TERM TRAJECTORIES
# ------------------------------------------------------------
traj <- panel %>%
  filter(!is.na(pathway_binary)) %>%
  mutate(
    frequency_per_billion=frequency*1e9,
    log_frequency=log1p(frequency_per_billion)
  ) %>%
  group_by(row_id) %>%
  mutate(
    mu=mean(log_frequency,na.rm=TRUE),
    s=sd(log_frequency,na.rm=TRUE),
    z=if_else(is.finite(s)&s>0,(log_frequency-mu)/s,0)
  ) %>%
  ungroup() %>%
  mutate(term_factor=factor(row_id)) %>%
  arrange(row_id,year) %>%
  group_by(row_id) %>%
  mutate(AR_start=row_number()==1L) %>%
  ungroup()

bam0 <- mgcv::bam(
  z ~ pathway_binary +
    s(year,by=pathway_binary,k=15) +
    s(term_factor,bs="re"),
  data=traj, method="fREML", discrete=TRUE
)

traj$resid0 <- residuals(bam0)

rho_terms <- traj %>%
  group_by(row_id) %>%
  summarise(
    rho=if(n()>=3 && sd(resid0,na.rm=TRUE)>0) {
      suppressWarnings(cor(
        resid0[-n()],resid0[-1],use="complete.obs"
      ))
    } else NA_real_,
    .groups="drop"
  )

rho_hat <- median(rho_terms$rho,na.rm=TRUE)
if(!is.finite(rho_hat)) rho_hat <- 0
rho_hat <- max(0,min(.90,rho_hat))

bam1 <- mgcv::bam(
  z ~ pathway_binary +
    s(year,by=pathway_binary,k=15) +
    s(term_factor,bs="re"),
  data=traj, method="fREML", discrete=TRUE,
  rho=rho_hat, AR.start=traj$AR_start
)

capture.output(
  summary(bam1),
  file=file.path(OUT_DIR,"RQ2_BAM_AR1_SUMMARY.txt")
)


# ------------------------------------------------------------
# 15. RQ3: ALL INTERACTIONS + SIMPLE EFFECTS
# ------------------------------------------------------------
cells <- h2 %>%
  count(cultural_domain,pathway_binary,name="n") %>%
  complete(cultural_domain,pathway_binary,fill=list(n=0))

eligible_domains <- cells %>%
  group_by(cultural_domain) %>%
  summarise(min_n=min(n),.groups="drop") %>%
  filter(min_n>=3) %>%
  pull(cultural_domain)

write_csv(cells,file.path(OUT_DIR,"RQ3_DOMAIN_CELLS.csv"))

rq3_all <- tibble()
rq3_simple <- tibble()

if(length(eligible_domains)>=2) {
  d3 <- h2 %>%
    filter(cultural_domain %in% eligible_domains) %>%
    mutate(
      domain_interaction=factor(cultural_domain),
      domain_interaction=relevel(
        domain_interaction,
        ref=sort(unique(as.character(domain_interaction)))[1]
      )
    )

  m3 <- lm(
    sustained_onset ~ pathway_binary*domain_interaction +
      token_count_c + query_risk + case_insensitive,
    data=d3
  )

  rq3_all <- tidy_robust(m3,"RQ3_all_coefficients",FALSE)
  write_csv(
    rq3_all,
    file.path(OUT_DIR,"RQ3_ALL_INTERACTION_COEFFICIENTS.csv")
  )

  vc <- sandwich::vcovHC(m3,type="HC3")
  b <- coef(m3)
  cn <- names(b)

  simple_one <- function(dom) {
    L <- rep(0,length(b)); names(L)<-cn
    L["pathway_binarypure_calque"] <- 1

    ref <- levels(d3$domain_interaction)[1]
    if(dom != ref) {
      int1 <- paste0(
        "pathway_binarypure_calque:domain_interaction",dom
      )
      int2 <- paste0(
        "domain_interaction",dom,":pathway_binarypure_calque"
      )
      if(int1 %in% cn) L[int1] <- 1
      if(int2 %in% cn) L[int2] <- 1
    }

    est <- sum(L*b)
    se <- sqrt(as.numeric(t(L)%*%vc%*%L))
    tibble(
      cultural_domain=dom,
      b_years=est,
      se_hc3=se,
      ci_low=est-1.96*se,
      ci_high=est+1.96*se,
      z=est/se,
      p=2*pnorm(abs(est/se),lower.tail=FALSE)
    )
  }

  rq3_simple <- map_dfr(
    levels(d3$domain_interaction),
    simple_one
  )

  write_csv(
    rq3_simple,
    file.path(OUT_DIR,"RQ3_WITHIN_DOMAIN_SIMPLE_EFFECTS.csv")
  )
}


# ------------------------------------------------------------
# 16. RQ4: MULTI-NAME CASES + DIRECT-LABEL FIGURE
# ------------------------------------------------------------
concepts <- term_metrics %>%
  filter(!is.na(concept_group),concept_group!="") %>%
  group_by(concept_group) %>%
  summarise(
    n=n_distinct(row_id),
    has_source=any(pathway=="source_form"),
    has_calque=any(pathway=="pure_calque"),
    has_mixed=any(pathway=="mixed"),
    .groups="drop"
  ) %>%
  filter(n>=2)

rq4_metrics <- term_metrics %>%
  filter(concept_group %in% concepts$concept_group) %>%
  select(
    concept_group,row_id,term,pathway,
    sustained_onset,persistence_20y,persistence_30y,
    persistence_to_2022,contemporary_retention
  )

write_csv(
  rq4_metrics,
  file.path(OUT_DIR,"RQ4_MULTI_NAME_METRICS.csv")
)

pair_panel <- panel %>%
  filter(concept_group %in% concepts$concept_group) %>%
  group_by(row_id) %>%
  mutate(
    peak=max(frequency,na.rm=TRUE),
    relative_to_own_peak=if_else(
      is.finite(peak)&peak>0, frequency/peak, 0
    )
  ) %>%
  ungroup()

end_labels <- pair_panel %>%
  group_by(concept_group,term) %>%
  filter(year==max(year)) %>%
  slice_tail(n=1) %>%
  ungroup()

p4 <- ggplot(
  pair_panel,
  aes(x=year,y=relative_to_own_peak,group=term,linetype=term)
) +
  geom_line(linewidth=.55) +
  facet_wrap(~concept_group,scales="free_y") +
  ggrepel::geom_text_repel(
    data=end_labels,
    aes(label=term),
    size=2.4,
    direction="y",
    hjust=0,
    nudge_x=3,
    segment.size=.2,
    show.legend=FALSE
  ) +
  coord_cartesian(xlim=c(YEAR_START,YEAR_END+18),clip="off") +
  scale_y_continuous(labels=percent_format(accuracy=1)) +
  labs(
    x="Year",
    y="Frequency relative to each form's own historical peak",
    linetype="English form"
  ) +
  theme(plot.margin=margin(5.5,90,5.5,5.5))

ggsave(
  file.path(OUT_DIR,"Figure_4_DIRECT_LABELS.png"),
  p4,width=11,height=8,dpi=600
)


# ------------------------------------------------------------
# 17. HISTORICAL VARIANT AUDIT
# ------------------------------------------------------------
hist_effect <- tibble()
delta_boot <- tibble()

if(
  !is.na(HIST_VARIANTS_FILE) && file.exists(HIST_VARIANTS_FILE) &&
  !is.na(HIST_MAP_FILE) && file.exists(HIST_MAP_FILE)
) {

  hmap <- suppressMessages(
    read_csv(HIST_MAP_FILE,show_col_types=FALSE)
  )

  # Default: NOT VERIFIED, therefore excluded from union.
  # Positive cases currently supported by a historical target-sense source:
  #   dao -> Tao (James Legge, 1891)
  #   huangjiu -> huang chiu (Robert Coltman, 1891, pp. 122-124)
  # Negative/high-risk controls explicitly blocked:
  #   Nian -> Nien
  #   tangzhong -> t'ang chung / tang chung

  hist_audit <- hmap %>%
    mutate(
      variant_status=case_when(
        term=="dao" & historical_variant=="Tao" ~ "verified",
        term=="huangjiu" &
          tolower(historical_variant)=="huang chiu" ~ "verified",
        term=="Nian" &
          tolower(historical_variant)=="nien" ~ "blocked_semantic_risk",
        term=="tangzhong" &
          tolower(historical_variant) %in%
          c("t'ang chung","tang chung") ~ "blocked_semantic_risk",
        TRUE ~ "unverified_do_not_use"
      ),
      variant_valid_from_year=case_when(
        term=="dao" & historical_variant=="Tao" ~ 1891L,
        term=="huangjiu" &
          tolower(historical_variant)=="huang chiu" ~ 1891L,
        TRUE ~ NA_integer_
      ),
      evidence_note=case_when(
        term=="dao" & historical_variant=="Tao" ~
          "James Legge, The Texts of Taoism (1891): target philosophical/Daoist use.",
        term=="huangjiu" &
          tolower(historical_variant)=="huang chiu" ~
          "Robert Coltman, The Chinese, Their Present and Future (1891), pp.122-124: 'huang chiu' explicitly glossed as yellow wine.",
        term=="Nian" &
          tolower(historical_variant)=="nien" ~
          "Blocked: early Nien can mean 'year' or other referents; no early target year-beast evidence established.",
        term=="tangzhong" &
          tolower(historical_variant) %in%
          c("t'ang chung","tang chung") ~
          "Blocked: spelling equivalence alone does not establish early bread-technique sense.",
        TRUE ~
          "No token-level historical target-sense validation supplied; excluded from validated union."
      )
    )

  write_csv(
    hist_audit,
    file.path(OUT_DIR,"HISTORICAL_VARIANT_AUDIT.csv")
  )

  hv <- suppressMessages(
    read_csv(HIST_VARIANTS_FILE,show_col_types=FALSE)
  ) %>%
    mutate(
      row_id=as.integer(row_id),
      year=as.integer(year),
      frequency=as.numeric(frequency)
    ) %>%
    inner_join(
      hist_audit %>%
        filter(variant_status=="verified") %>%
        select(
          term,
          variant=historical_variant,
          variant_valid_from_year
        ),
      by=c("term","variant")
    ) %>%
    filter(year >= variant_valid_from_year)

  verified_pos <- hv %>%
    group_by(row_id,year) %>%
    summarise(
      historical_positive=any(frequency>0,na.rm=TRUE),
      .groups="drop"
    )

  current_valid <- main1 %>%
    transmute(
      row_id,year,current_positive=frequency>0
    )

  verified_start <- hv %>%
    group_by(row_id) %>%
    summarise(
      variant_start=min(variant_valid_from_year),
      .groups="drop"
    )

  family_start <- term_meta %>%
    select(row_id,audited_valid_from) %>%
    left_join(verified_start,by="row_id") %>%
    mutate(
      family_valid_from=if_else(
        !is.na(variant_start),
        pmin(audited_valid_from,variant_start),
        audited_valid_from
      )
    )

  grid <- family_start %>%
    rowwise() %>%
    mutate(years=list(seq(family_valid_from,YEAR_END))) %>%
    unnest(years) %>%
    rename(year=years) %>%
    ungroup()

  fam_panel <- grid %>%
    left_join(current_valid,by=c("row_id","year")) %>%
    left_join(verified_pos,by=c("row_id","year")) %>%
    mutate(
      current_positive=coalesce(current_positive,FALSE),
      historical_positive=coalesce(historical_positive,FALSE),
      family_positive=current_positive|historical_positive
    )

  fam_onset <- fam_panel %>%
    group_by(row_id) %>%
    summarise(
      onset_family_verified=calc_sustained_indicator(
        year,family_positive,MAIN_WINDOW,MAIN_MIN_POSITIVE
      ),
      .groups="drop"
    )

  hist_dat <- h2 %>%
    select(
      row_id,term,pathway_binary,domain3,
      token_count_c,query_risk,case_insensitive,
      onset_current=sustained_onset
    ) %>%
    left_join(fam_onset,by="row_id") %>%
    filter(
      !is.na(onset_current),
      !is.na(onset_family_verified)
    )

  m_cur <- lm(
    make_formula("onset_current",rhs),
    data=hist_dat
  )
  m_fam <- lm(
    make_formula("onset_family_verified",rhs),
    data=hist_dat
  )

  extract_path <- function(m,label) {
    tidy_robust(m,label,FALSE) %>%
      filter(term=="pathway_binarypure_calque") %>%
      transmute(
        model=label,n=nobs(m),
        b=estimate,se_hc3=std_error,
        ci_low=conf_low,ci_high=conf_high,p=p_value
      )
  }

  hist_effect <- bind_rows(
    extract_path(m_cur,"current_spelling_audited"),
    extract_path(m_fam,"verified_historical_variants_only")
  )

  write_csv(
    hist_effect,
    file.path(OUT_DIR,"HISTORICAL_SPELLING_VERIFIED_EFFECT.csv")
  )

  # Paired bootstrap of attenuation delta:
  # delta = b_family - b_current.
  # Positive delta means the negative calque coefficient moves toward zero.
  coef_path <- function(d,outcome) {
    tryCatch({
      m <- lm(make_formula(outcome,rhs),data=d)
      unname(coef(m)["pathway_binarypure_calque"])
    }, error=function(e) NA_real_)
  }

  set.seed(20261029)
  boots <- map_dfr(seq_len(BOOT_B),function(bi){
    idx <- sample(seq_len(nrow(hist_dat)),replace=TRUE)
    db <- hist_dat[idx,,drop=FALSE]
    bc <- coef_path(db,"onset_current")
    bf <- coef_path(db,"onset_family_verified")
    tibble(
      replicate=bi,
      b_current=bc,
      b_family=bf,
      delta_b=bf-bc
    )
  }) %>%
    filter(is.finite(delta_b))

  delta_boot <- tibble(
    B=nrow(boots),
    delta_b_mean=mean(boots$delta_b),
    delta_b_median=median(boots$delta_b),
    ci_low=quantile(boots$delta_b,.025,names=FALSE),
    ci_high=quantile(boots$delta_b,.975,names=FALSE),
    verified_variant_terms=n_distinct(hv$row_id)
  )

  write_csv(
    boots,
    file.path(OUT_DIR,"HISTORICAL_SPELLING_DELTA_BOOTSTRAP_DRAWS.csv")
  )
  write_csv(
    delta_boot,
    file.path(OUT_DIR,"HISTORICAL_SPELLING_DELTA_BOOTSTRAP_SUMMARY.csv")
  )
}


# ------------------------------------------------------------
# 18. EXAMPLE / EVIDENCE AUDIT TABLE FOR MANUSCRIPT
# ------------------------------------------------------------
example_audit <- tribble(
  ~evidence_task, ~term_or_pair, ~status, ~source_note,
  "pathway_boundary","Qingming Festival","verified",
  "Wiktionary: partial calque; Qingming + English Festival.",
  "pathway_boundary","Mid-Autumn Festival","verified",
  "Wiktionary: calque of Chinese 中秋節/中秋节.",
  "date_boundary","Belt and Road","verified",
  "Official Chinese agencies standardized 'the Belt and Road' / 'Belt and Road Initiative' in 2015.",
  "date_boundary","brainwashing","verified",
  "Oxford University Press: term first recorded in 1950.",
  "date_boundary","Eighth Route Army","verified",
  "Agnes Smedley, China Fights Back: An American Woman with the Eighth Route Army (1938); unit created in 1937.",
  "date_boundary","Great Leap Forward","verified",
  "1959 U.S. historical document explicitly discusses China's 1958 'great leap forward' program.",
  "historical_variant","dao / Tao","verified_positive",
  "James Legge, The Texts of Taoism (1891), target philosophical/Daoist usage.",
  "historical_variant","huangjiu / huang chiu","verified_positive",
  "Robert Coltman (1891), pp.122-124, explicitly glosses 'huang chiu' as yellow wine.",
  "historical_variant","Nian / Nien","negative_control",
  "Do not union early Nien hits without token-level evidence for the year-beast sense.",
  "historical_variant","tangzhong / tang chung","negative_control",
  "Do not union early tang chung hits without token-level evidence for the bread-technique sense.",
  "co_reference","Monkey King / Sun Wukong","verified_modern",
  "Penguin description: the Monkey King is called Sun Wukong."
)

write_csv(
  example_audit,
  file.path(OUT_DIR,"MANUSCRIPT_EXAMPLE_EVIDENCE_AUDIT.csv")
)


# ------------------------------------------------------------
# 19. SUMMARY
# ------------------------------------------------------------
path_counts <- path_audit %>% count(pathway_final)

h2_key <- tidy_robust(m_onset,"onset",FALSE) %>%
  filter(term=="pathway_binarypure_calque")

fixed_key <- fixed_tests %>%
  select(window,statistic,p.value)

summary_lines <- c(
  "AUDITED SUSTAINABILITY REANALYSIS",
  "=================================",
  "",
  paste0("Input: ",FINAL_ANNUAL_FILE),
  paste0("Audited annual rows: ",nrow(main1)),
  paste0("Audited retained terms: ",n_distinct(main1$row_id)),
  "",
  "Final pathway counts among retained terms:",
  paste(capture.output(print(path_counts)),collapse="\n"),
  "",
  paste0(
    "H1: chi-square=",round(h1_test$chi_square,2),
    ", df=",h1_test$df,
    ", Monte Carlo p=",signif(h1_test$p_monte_carlo,4),
    ", Cramer's V=",round(h1_test$cramers_v,3),
    ", n=",h1_test$n
  ),
  "",
  paste0(
    "H2 audited current-spelling onset effect (pure calque vs source form): b=",
    round(h2_key$estimate,2),
    ", HC3 SE=",round(h2_key$std_error,2),
    ", 95% CI [",round(h2_key$conf_low,2),", ",
    round(h2_key$conf_high,2),"], p=",
    signif(h2_key$p_value,4)
  ),
  "",
  "Fixed-window Wilcoxon tests:",
  paste(capture.output(print(fixed_key)),collapse="\n"),
  "",
  paste0(
    "RQ3 eligible domains: ",
    paste(eligible_domains,collapse=" | ")
  ),
  "",
  "Historical spelling:",
  if(nrow(hist_effect)>0) paste(
    capture.output(print(hist_effect)),collapse="\n"
  ) else "Not run / historical files unavailable.",
  "",
  "Paired delta-b bootstrap:",
  if(nrow(delta_boot)>0) paste(
    capture.output(print(delta_boot)),collapse="\n"
  ) else "Not available.",
  "",
  "METHOD NOTE:",
  "Do not report the old pathway kappa=.972 as validation of the revised three-way coding.",
  "Report it only as agreement under the provisional scheme, followed by etymological adjudication of rule-sensitive cases.",
  "",
  "HISTORICAL VARIANT NOTE:",
  "Only individually verified historical variants enter the validated spelling union.",
  "Nien and tang chung/t'ang chung are blocked pending target-sense historical evidence."
)

write_txt(
  summary_lines,
  file.path(OUT_DIR,"00_AUDITED_RESULTS_SUMMARY.txt")
)

saveRDS(
  list(
    h2_onset=m_onset,
    h2_persistence=m_persist,
    h2_retention=m_ret,
    rq2_bam=bam1,
    rq3=if(exists("m3")) m3 else NULL,
    hist_current=if(exists("m_cur")) m_cur else NULL,
    hist_verified=if(exists("m_fam")) m_fam else NULL
  ),
  file.path(OUT_DIR,"AUDITED_MODELS.rds")
)

capture.output(
  sessionInfo(),
  file=file.path(OUT_DIR,"sessionInfo_AUDITED.txt")
)

cat("\n====================================================\n")
cat("AUDITED REANALYSIS COMPLETE\n")
cat("Output:",OUT_DIR,"\n")
cat("First open: 00_AUDITED_RESULTS_SUMMARY.txt\n")
cat("Also inspect:\n")
cat(" - PATHWAY_FINAL_AUDIT.csv\n")
cat(" - DATE_CONSISTENCY_AUDIT.csv\n")
cat(" - DATE_SCREEN_ALL_SOCIAL_POLITICAL_TERMS.csv\n")
cat(" - FIXED_WINDOW_DESCRIPTIVE.csv\n")
cat(" - RQ3_ALL_INTERACTION_COEFFICIENTS.csv\n")
cat(" - RQ3_WITHIN_DOMAIN_SIMPLE_EFFECTS.csv\n")
cat(" - HISTORICAL_VARIANT_AUDIT.csv\n")
cat(" - HISTORICAL_SPELLING_DELTA_BOOTSTRAP_SUMMARY.csv\n")
cat("====================================================\n")
