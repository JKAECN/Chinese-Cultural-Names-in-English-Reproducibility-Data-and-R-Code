# ============================================================
# 05_Semantic_Round2_Blind_Coding_Generator.R
# Purpose:
#   Generate two independent Round-2 blind semantic-coding workbooks
#   for the 75 semantic-audit items.
#
# Key design:
#   Q1 -> Can this exact English string support a defensible historical
#         time series for the intended Chinese-cultural sense?
#   Q2 -> If yes, do the earliest usable Ngram hits already express
#         that intended Chinese-cultural sense?
#
# Derived decision:
#   Q1 = no                         -> exclude
#   Q1 = yes & Q2 = yes            -> keep
#   Q1 = yes & Q2 = no             -> truncate
#
# IMPORTANT:
#   - Round-1 semantic answers are NOT copied into either workbook.
#   - Pathway/domain coding is NOT repeated.
#   - The two coders must not view each other's Round-2 coding.
# ============================================================

ROOT_DIR   <- "E:/论文/中国文化/英语中的中文"
SUBMIT_DIR <- file.path(ROOT_DIR, "准备投稿版")
OUT_DIR    <- file.path(ROOT_DIR, "semantic_round2")
dir.create(OUT_DIR, recursive = TRUE, showWarnings = FALSE)

# ------------------------------------------------------------
# 1. Packages
# ------------------------------------------------------------
pkgs <- c("openxlsx", "readxl", "dplyr", "stringr", "tibble")
need <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]

if (length(need) > 0) {
  install.packages(need, repos = "https://cloud.r-project.org")
}

suppressPackageStartupMessages({
  library(openxlsx)
  library(readxl)
  library(dplyr)
  library(stringr)
  library(tibble)
})

# ------------------------------------------------------------
# 2. Robustly locate a VALID workbook containing Semantic_75
# ------------------------------------------------------------

# IMPORTANT:
# Do not select a workbook merely because its filename looks right.
# We first inspect every plausible workbook and keep only those that
# actually contain a sheet named Semantic_75.

safe_sheet_names <- function(path) {

  # Ignore Excel temporary/lock files.
  if (grepl("^~\\$", basename(path))) {
    return(character(0))
  }

  # First try openxlsx.
  sh1 <- tryCatch(
    openxlsx::getSheetNames(path),
    error = function(e) character(0)
  )

  if (length(sh1) > 0) return(sh1)

  # Fallback to readxl.
  sh2 <- tryCatch(
    readxl::excel_sheets(path),
    error = function(e) character(0)
  )

  sh2
}

# Search the whole project, because completed workbooks may have been
# saved outside 准备投稿版.
xlsx_candidates <- list.files(
  ROOT_DIR,
  pattern = "\\.xlsx$",
  recursive = TRUE,
  full.names = TRUE,
  ignore.case = TRUE
)

# Keep only plausible blind-coding workbooks.
xlsx_candidates <- xlsx_candidates[
  grepl("Second_Coder_Blind", basename(xlsx_candidates), ignore.case = TRUE)
]

# Exclude Round-2 output files if the script is rerun.
xlsx_candidates <- xlsx_candidates[
  !grepl("Semantic_75_Round2", basename(xlsx_candidates), ignore.case = TRUE)
]

# Exclude Excel lock files.
xlsx_candidates <- xlsx_candidates[
  !grepl("^~\\$", basename(xlsx_candidates))
]

if (length(xlsx_candidates) == 0) {
  stop(
    "No Second_Coder_Blind*.xlsx files were found under:\n",
    ROOT_DIR
  )
}

candidate_check <- lapply(xlsx_candidates, function(f) {

  sh <- safe_sheet_names(f)
  has_sem <- "Semantic_75" %in% sh

  # A workbook is considered usable only if Semantic_75 can actually
  # be read, not merely listed.
  readable_sem <- FALSE
  semantic_n <- NA_integer_

  if (has_sem) {
    test_read <- tryCatch(
      readxl::read_excel(
        f,
        sheet = "Semantic_75",
        .name_repair = "minimal"
      ),
      error = function(e) NULL
    )

    if (!is.null(test_read)) {
      readable_sem <- TRUE
      semantic_n <- nrow(test_read)
    }
  }

  data.frame(
    file = f,
    sheets = paste(sh, collapse = " | "),
    has_semantic_75 = has_sem,
    readable_semantic_75 = readable_sem,
    semantic_n = semantic_n,
    stringsAsFactors = FALSE
  )
})

candidate_check <- dplyr::bind_rows(candidate_check)

cat("\n===== Workbook candidates =====\n")
print(candidate_check, row.names = FALSE)

# Save diagnostics so we know exactly what R inspected.
dir.create(OUT_DIR, recursive = TRUE, showWarnings = FALSE)

write.csv(
  candidate_check,
  file.path(OUT_DIR, "Round2_source_workbook_diagnostic.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

valid_workbooks <- candidate_check$file[
  candidate_check$has_semantic_75 & candidate_check$readable_semantic_75
]

if (length(valid_workbooks) == 0) {
  stop(
    paste0(
      "\nR found Second_Coder_Blind*.xlsx files, but none of them ",
      "could be verified as containing a readable Semantic_75 sheet.\n\n",
      "Please inspect:\n",
      file.path(OUT_DIR, "Round2_source_workbook_diagnostic.csv"),
      "\n\n",
      "This usually means R is seeing an old/empty copy or an Excel ",
      "temporary file rather than the completed workbook."
    )
  )
}

# Preference order:
# 1. uncoded master workbook, if valid
# 2. CODED workbook
# 3. coder2_coded workbook
# 4. any remaining valid workbook
preference_score <- function(path) {
  bn <- basename(path)

  dplyr::case_when(
    grepl("^Second_Coder_Blind\\.xlsx$", bn, ignore.case = TRUE) ~ 1L,
    grepl("^Second_Coder_Blind\\(1\\)\\.xlsx$", bn, ignore.case = TRUE) ~ 2L,
    grepl("CODED", bn, ignore.case = TRUE) &
      !grepl("coder2", bn, ignore.case = TRUE) ~ 3L,
    grepl("coder2.*coded", bn, ignore.case = TRUE) ~ 4L,
    TRUE ~ 5L
  )
}

valid_workbooks <- valid_workbooks[
  order(vapply(valid_workbooks, preference_score, integer(1)))
]

SOURCE_XLSX <- valid_workbooks[1]

sheets <- safe_sheet_names(SOURCE_XLSX)

cat("\n===== Selected source workbook =====\n")
cat(SOURCE_XLSX, "\n")
cat("Sheets: ", paste(sheets, collapse = " | "), "\n", sep = "")

if (!"Semantic_75" %in% sheets) {
  stop(
    "Internal validation failed: selected workbook does not contain Semantic_75."
  )
}

# ------------------------------------------------------------
# 3. Read ONLY source information; strip all Round-1 answers
# ------------------------------------------------------------
# Read the source sheet with readxl.
# openxlsx is intentionally NOT used for source reading here because
# some valid .xlsx files can expose sheet names but still trigger
# "Workbook has no worksheets" in openxlsx::read.xlsx().
sem0 <- tryCatch(
  readxl::read_excel(
    SOURCE_XLSX,
    sheet = "Semantic_75",
    .name_repair = "minimal"
  ),
  error = function(e) {
    stop(
      "Failed to read Semantic_75 with readxl from:\n",
      SOURCE_XLSX,
      "\nOriginal error: ", conditionMessage(e)
    )
  }
)

sem0 <- as.data.frame(sem0, stringsAsFactors = FALSE)

required_source_cols <- c(
  "row_id",
  "term",
  "ngram_query",
  "audit_reason",
  "query_risk"
)

missing_cols <- setdiff(required_source_cols, names(sem0))

if (length(missing_cols) > 0) {
  stop(
    "Missing required columns in Semantic_75: ",
    paste(missing_cols, collapse = ", ")
  )
}

semantic_items <- sem0 %>%
  transmute(
    row_id       = as.character(row_id),
    term         = as.character(term),
    ngram_query  = as.character(ngram_query),
    audit_reason = as.character(audit_reason),
    query_risk   = as.character(query_risk)
  ) %>%
  filter(
    !is.na(row_id), str_trim(row_id) != "",
    !is.na(term),   str_trim(term) != ""
  ) %>%
  distinct(row_id, .keep_all = TRUE)

if (nrow(semantic_items) != 75) {
  stop(
    "Expected exactly 75 semantic-audit items, but found ",
    nrow(semantic_items),
    ". Check the Semantic_75 sheet before proceeding."
  )
}

cat("Semantic items found:", nrow(semantic_items), "\n")

# ------------------------------------------------------------
# 4. Frozen Round-2 coding rules
# ------------------------------------------------------------
instructions <- tibble(
  Instruction = c(
    "Purpose",
    "Independence",
    "What to code",
    "Q1",
    "Q2",
    "Derived decision",
    "KEEP",
    "TRUNCATE",
    "EXCLUDE",
    "valid_from_year",
    "Evidence rule",
    "Conservative rule",
    "Confidence",
    "Do not use Round-1 answers",
    "Do not discuss before reliability",
    "Completion check"
  ),
  Detail = c(
    "Round 2 is a confirmatory semantic-validity recoding of the same 75 audit items after clarifying the operational rules.",
    "Code independently. Do not view the other coder's Round-2 file or discuss individual items until inter-rater reliability has been calculated.",
    "Judge only whether the exact Ngram query can support the intended Chinese-cultural sense historically. Pathway and cultural-domain coding are already frozen and are not recoded here.",
    "Q1_target_series_possible: YES if the exact English string has a historically defensible use for the intended Chinese-cultural referent at some point in the series. NO if the target sense cannot be isolated reliably because the string is dominated by another sense/name/OCR noise or no defensible target-sense evidence can be established.",
    "Q2_earliest_hits_target_sense: Answer only when Q1=YES. YES if the earliest usable positive Ngram period can already be contextually defended as the intended Chinese-cultural sense. NO if early hits are another sense/name/noise, or if the intended sense becomes defensible only later.",
    "The workbook derives the category mechanically: Q1=NO -> EXCLUDE; Q1=YES and Q2=YES -> KEEP; Q1=YES and Q2=NO -> TRUNCATE.",
    "KEEP means the usable series can begin at the earliest observed Ngram evidence because the intended Chinese-cultural sense is already defensible there.",
    "TRUNCATE means the exact string is usable for the target sense, but early Ngram hits cannot be defended as that sense; retain only observations from a later conservative boundary year.",
    "EXCLUDE means the exact string cannot yield a sufficiently reliable historical series for the intended Chinese-cultural sense.",
    "Enter a year ONLY for TRUNCATE. It is the earliest conservative year from which the intended Chinese-cultural sense is supported by contextual/historical evidence. Do not use an Ngram spike or first-positive year alone as proof.",
    "For TRUNCATE and EXCLUDE, provide at least one evidence URL or a precise bibliographic/source note. For borderline KEEP cases, evidence is strongly recommended.",
    "When early evidence is ambiguous but later target-sense evidence is clear, choose TRUNCATE rather than KEEP. When no defensible target-sense period can be established, choose EXCLUDE rather than guessing a boundary year.",
    "HIGH = multiple/clear contextual sources; MEDIUM = one clear source or limited contextual coverage; LOW = genuine boundary case. Confidence does not replace the decision rules.",
    "Round-1 decisions, years, confidence ratings, evidence notes, and the other coder's answers must not be consulted while doing Round 2.",
    "Do not adjudicate disagreements before raw agreement and Cohen's kappa are calculated from the two independent Round-2 files.",
    "Complete all 75 rows. Q1 is required for every row. Q2 is required when Q1=YES. valid_from_year is required only for TRUNCATE."
  )
)

codebook <- tribble(
  ~Field, ~Allowed_value, ~Operational_rule,
  "q1_target_series_possible", "yes",
  "The exact query has a defensible historical use for the intended Chinese-cultural sense at some point in the Ngram period.",
  "q1_target_series_possible", "no",
  "A reliable target-sense historical series cannot be established for the exact query.",
  "q2_earliest_hits_target_sense", "yes",
  "Only if Q1=yes: the earliest usable positive Ngram period already has contextual evidence for the intended Chinese-cultural sense.",
  "q2_earliest_hits_target_sense", "no",
  "Only if Q1=yes: early hits are non-target/ambiguous/noisy and the target sense becomes defensible only later.",
  "q2_earliest_hits_target_sense", "not_applicable",
  "Use only when Q1=no.",
  "decision_derived", "keep",
  "Automatically derived when Q1=yes and Q2=yes.",
  "decision_derived", "truncate",
  "Automatically derived when Q1=yes and Q2=no.",
  "decision_derived", "exclude",
  "Automatically derived when Q1=no.",
  "valid_from_year", "1800-2022 integer",
  "TRUNCATE only: earliest conservative year supported by contextual/historical evidence for the intended Chinese-cultural sense.",
  "confidence", "high",
  "Clear evidence from multiple or especially strong contextual sources.",
  "confidence", "medium",
  "Decision is supportable but contextual coverage is limited.",
  "confidence", "low",
  "Genuine boundary case requiring later adjudication after reliability is calculated.",
  "evidence_url", "URL or blank",
  "Required for truncate/exclude where feasible; strongly recommended for low-confidence keep.",
  "evidence_note", "free text",
  "Briefly state why early hits are target/non-target, why a boundary year was chosen, or why the query is excluded."
)

decision_tree <- tibble(
  Step = c("1", "2A", "2B", "2C"),
  Question = c(
    "Can the exact query support a defensible historical series for the intended Chinese-cultural sense at any point?",
    "If NO to Step 1",
    "If YES to Step 1: do the earliest usable positive hits already express the target sense?",
    "If YES to Step 1 but NO to Step 2"
  ),
  Result = c(
    "Answer Q1 yes/no",
    "EXCLUDE",
    "YES -> KEEP",
    "TRUNCATE + enter valid_from_year"
  )
)

# ------------------------------------------------------------
# 5. Build one blind workbook
# ------------------------------------------------------------
build_round2_workbook <- function(coder_id, seed) {

  suffix <- paste0("coder", coder_id)

  set.seed(seed)
  dat <- semantic_items[sample(seq_len(nrow(semantic_items))), ]

  dat[[paste0("q1_target_series_possible_", suffix)]] <- NA_character_
  dat[[paste0("q2_earliest_hits_target_sense_", suffix)]] <- NA_character_
  dat[[paste0("decision_derived_", suffix)]] <- NA_character_
  dat[[paste0("valid_from_year_", suffix)]] <- NA_integer_
  dat[[paste0("confidence_", suffix)]] <- NA_character_
  dat[[paste0("evidence_url_", suffix)]] <- NA_character_
  dat[[paste0("evidence_note_", suffix)]] <- NA_character_

  wb <- createWorkbook()

  addWorksheet(wb, "Instructions")
  addWorksheet(wb, "Decision_Tree")
  addWorksheet(wb, "Codebook_Round2")
  addWorksheet(wb, "Semantic_75_Round2")

  writeData(wb, "Instructions", instructions)
  writeData(wb, "Decision_Tree", decision_tree)
  writeData(wb, "Codebook_Round2", codebook)
  writeData(wb, "Semantic_75_Round2", dat)

  # ---------------------------
  # Styling
  # ---------------------------
  header_style <- createStyle(
    fontColour = "#FFFFFF",
    fgFill = "#4F81BD",
    textDecoration = "bold",
    halign = "center",
    valign = "center",
    wrapText = TRUE,
    border = "Bottom",
    borderColour = "#808080"
  )

  subheader_style <- createStyle(
    fgFill = "#D9EAF7",
    textDecoration = "bold",
    valign = "top",
    wrapText = TRUE
  )

  editable_style <- createStyle(
    fgFill = "#FFF2CC",
    valign = "top",
    wrapText = TRUE
  )

  derived_style <- createStyle(
    fgFill = "#E2F0D9",
    textDecoration = "bold",
    halign = "center"
  )

  note_style <- createStyle(
    valign = "top",
    wrapText = TRUE
  )

  sheet_ncols <- c(
    Instructions = 2,
    Decision_Tree = 3,
    Codebook_Round2 = 3,
    Semantic_75_Round2 = 12
  )

  for (sh in names(sheet_ncols)) {
    addStyle(
      wb, sh,
      header_style,
      rows = 1,
      cols = seq_len(sheet_ncols[[sh]]),
      gridExpand = TRUE
    )
    freezePane(wb, sh, firstRow = TRUE)
  }

  # Widths
  setColWidths(wb, "Instructions", cols = 1, widths = 24)
  setColWidths(wb, "Instructions", cols = 2, widths = 105)

  setColWidths(wb, "Decision_Tree", cols = 1, widths = 10)
  setColWidths(wb, "Decision_Tree", cols = 2, widths = 95)
  setColWidths(wb, "Decision_Tree", cols = 3, widths = 28)

  setColWidths(wb, "Codebook_Round2", cols = 1, widths = 32)
  setColWidths(wb, "Codebook_Round2", cols = 2, widths = 24)
  setColWidths(wb, "Codebook_Round2", cols = 3, widths = 100)

  setColWidths(
    wb, "Semantic_75_Round2",
    cols = 1:12,
    widths = c(10, 26, 28, 38, 14, 22, 25, 18, 19, 15, 42, 55)
  )

  freezePane(wb, "Semantic_75_Round2", firstRow = TRUE, firstCol = TRUE)

  n <- nrow(dat)
  first_data_row <- 2
  last_data_row  <- n + 1

  # Editable columns: F:G, I:L
  addStyle(
    wb, "Semantic_75_Round2",
    editable_style,
    rows = first_data_row:last_data_row,
    cols = c(6, 7, 9, 10, 11, 12),
    gridExpand = TRUE,
    stack = TRUE
  )

  # Derived decision column H
  addStyle(
    wb, "Semantic_75_Round2",
    derived_style,
    rows = first_data_row:last_data_row,
    cols = 8,
    gridExpand = TRUE,
    stack = TRUE
  )

  addStyle(
    wb, "Semantic_75_Round2",
    note_style,
    rows = first_data_row:last_data_row,
    cols = 1:12,
    gridExpand = TRUE,
    stack = TRUE
  )

  # ---------------------------
  # Data validation
  # ---------------------------
  dataValidation(
    wb, "Semantic_75_Round2",
    cols = 6,
    rows = first_data_row:last_data_row,
    type = "list",
    value = '"yes,no"'
  )

  dataValidation(
    wb, "Semantic_75_Round2",
    cols = 7,
    rows = first_data_row:last_data_row,
    type = "list",
    value = '"yes,no,not_applicable"'
  )

  dataValidation(
    wb, "Semantic_75_Round2",
    cols = 10,
    rows = first_data_row:last_data_row,
    type = "list",
    value = '"high,medium,low"'
  )

  dataValidation(
    wb, "Semantic_75_Round2",
    cols = 9,
    rows = first_data_row:last_data_row,
    type = "whole",
    operator = "between",
    value = c(1800, 2022)
  )

  # ---------------------------
  # Derived decision formulas
  # H = decision
  # F = Q1, G = Q2
  # ---------------------------
  formulas <- vapply(
    first_data_row:last_data_row,
    function(r) {
      sprintf(
        '=IF(F%d="no","exclude",IF(AND(F%d="yes",G%d="yes"),"keep",IF(AND(F%d="yes",G%d="no"),"truncate","")))',
        r, r, r, r, r
      )
    },
    character(1)
  )

  writeFormula(
    wb,
    "Semantic_75_Round2",
    x = formulas,
    startCol = 8,
    startRow = first_data_row
  )

  # Filter
  addFilter(
    wb,
    "Semantic_75_Round2",
    rows = 1,
    cols = 1:12
  )

  # Conditional formatting to highlight low confidence
  conditionalFormatting(
    wb,
    "Semantic_75_Round2",
    cols = 10,
    rows = first_data_row:last_data_row,
    rule = 'J2="low"',
    style = createStyle(fgFill = "#F4CCCC"),
    type = "expression"
  )

  # Highlight truncate rows if valid_from_year is missing
  conditionalFormatting(
    wb,
    "Semantic_75_Round2",
    cols = 9,
    rows = first_data_row:last_data_row,
    rule = 'AND($H2="truncate",$I2="")',
    style = createStyle(fgFill = "#F4CCCC"),
    type = "expression"
  )

  # Highlight non-truncate rows if a year was entered accidentally
  conditionalFormatting(
    wb,
    "Semantic_75_Round2",
    cols = 9,
    rows = first_data_row:last_data_row,
    rule = 'AND($H2<>"truncate",$H2<>"",$I2<>"")',
    style = createStyle(fgFill = "#FCE5CD"),
    type = "expression"
  )

  # Add a coder-identification note at top of Instructions
  writeData(
    wb,
    "Instructions",
    x = data.frame(
      Instruction = "Coder",
      Detail = paste0("Round-2 independent semantic coder ", coder_id)
    ),
    startRow = nrow(instructions) + 3,
    colNames = FALSE
  )

  outfile <- file.path(
    OUT_DIR,
    paste0("Semantic_75_Round2_Coder", coder_id, ".xlsx")
  )

  saveWorkbook(wb, outfile, overwrite = TRUE)

  return(outfile)
}

# ------------------------------------------------------------
# 6. Generate the two blind workbooks
#    Different seeds -> different row order, same 75 items.
# ------------------------------------------------------------
file_coder1 <- build_round2_workbook(coder_id = 1, seed = 202610281)
file_coder2 <- build_round2_workbook(coder_id = 2, seed = 202610282)

# ------------------------------------------------------------
# 7. Frozen codebook exported separately for audit trail
# ------------------------------------------------------------
write.csv(
  codebook,
  file.path(OUT_DIR, "Semantic_Round2_Codebook_FROZEN.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

write.csv(
  instructions,
  file.path(OUT_DIR, "Semantic_Round2_Instructions_FROZEN.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

cat("\n============================================================\n")
cat("ROUND-2 BLIND SEMANTIC CODING FILES CREATED\n")
cat("============================================================\n")
cat("Coder 1:", file_coder1, "\n")
cat("Coder 2:", file_coder2, "\n")
cat("Frozen codebook:",
    file.path(OUT_DIR, "Semantic_Round2_Codebook_FROZEN.csv"), "\n")
cat("Frozen instructions:",
    file.path(OUT_DIR, "Semantic_Round2_Instructions_FROZEN.csv"), "\n")
cat("\nIMPORTANT:\n")
cat("1. Do not copy Round-1 answers into these files.\n")
cat("2. Do not let coders see each other's Round-2 answers.\n")
cat("3. Calculate reliability BEFORE adjudicating disagreements.\n")
cat("4. Only after reliability is calculated should disagreements be resolved.\n")
cat("\nDONE.\n")
