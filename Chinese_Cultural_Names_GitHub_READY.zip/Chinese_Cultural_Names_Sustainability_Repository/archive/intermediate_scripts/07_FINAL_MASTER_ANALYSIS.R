# ============================================================
# 07_FINAL_MASTER_ANALYSIS.R
#
# 词语如何携带文化远行？
# 1800—2022 年汉源文化词进入英语的传播路径、领域迁移与跨文化持存
#
# FINAL MASTER ANALYSIS
# ------------------------------------------------------------
# This script uses ONLY the frozen semantic-clean annual dataset
# as the analytical source for H1, H2, RQ1-RQ4 and sensitivity tests.
#
# Main input:
#   Semantic_Clean_Annual_Data_FINAL.csv
#
# It also optionally uses:
#   Semantic_75_FINAL_USED.csv / Semantic_75_FINAL.csv
#   ngram_main_sample_cleaned.csv
#   Google_Ngram_download_log.csv
#   historical_spelling_annual_variants.csv
#   historical_spelling_variant_map_predefined.csv
#
# Main outputs:
#   FINAL_ANALYSIS_OUTPUTS/
#     00_FINAL_RESULTS_SUMMARY.txt
#     Table_1_...
#     Table_2_...
#     Table_3_...
#     Table_4_...
#     RQ1_...
#     RQ2_...
#     RQ3_...
#     RQ4_...
#     HistoricalSpelling_...
#     Figure_1 ... Figure_4
#     FINAL_MODELS.rds
#     sessionInfo_FINAL.txt
#
# IMPORTANT:
#   - No old pre-semantic-clean results are reused.
#   - The historical-spelling sensitivity is rebuilt on the frozen
#     semantic dataset.
#   - Historical spellings are combined at the POSITIVE-YEAR indicator
#     level only. Frequencies are NEVER summed across spellings or
#     n-gram lengths.
# ============================================================


# ------------------------------------------------------------
# 0. SETTINGS
# ------------------------------------------------------------
ROOT_DIR <- "E:/论文/中国文化/英语中的中文"

OUT_DIR <- file.path(ROOT_DIR, "FINAL_ANALYSIS_OUTPUTS")
dir.create(OUT_DIR, recursive = TRUE, showWarnings = FALSE)

YEAR_START <- 1800L
YEAR_END   <- 2022L

MAIN_WINDOW <- 5L
MAIN_MIN_POSITIVE <- 3L
MONTE_CARLO_B <- 50000L

INSTALL_MISSING <- TRUE

# Optional manual overrides. Leave NA for automatic discovery.
FINAL_ANNUAL_OVERRIDE <- NA_character_
FINAL_SEMANTIC_OVERRIDE <- NA_character_
LEXICON_OVERRIDE <- NA_character_
DOWNLOAD_LOG_OVERRIDE <- NA_character_
HIST_VARIANTS_OVERRIDE <- NA_character_
HIST_MAP_OVERRIDE <- NA_character_


# ------------------------------------------------------------
# 1. PACKAGES
# ------------------------------------------------------------
packages <- c(
  "readr", "dplyr", "tidyr", "stringr", "purrr", "forcats",
  "ggplot2", "slider", "broom", "sandwich", "lmtest", "mgcv",
  "scales"
)

missing_packages <- packages[
  !vapply(packages, requireNamespace, logical(1), quietly = TRUE)
]

if (length(missing_packages) > 0) {
  if (!INSTALL_MISSING) {
    stop("Missing R packages: ", paste(missing_packages, collapse = ", "))
  }
  install.packages(missing_packages, repos = "https://cloud.r-project.org")
}

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(purrr)
  library(forcats)
  library(ggplot2)
  library(slider)
  library(broom)
  library(sandwich)
  library(lmtest)
  library(mgcv)
  library(scales)
})

theme_set(
  theme_bw(base_size = 11) +
    theme(
      panel.grid.minor = element_blank(),
      legend.position = "bottom",
      plot.title = element_blank()
    )
)


# ------------------------------------------------------------
# 2. HELPERS
# ------------------------------------------------------------
to_logical <- function(x) {
  if (is.logical(x)) return(x)
  z <- tolower(trimws(as.character(x)))
  dplyr::case_when(
    z %in% c("true", "t", "1", "yes", "y") ~ TRUE,
    z %in% c("false", "f", "0", "no", "n") ~ FALSE,
    TRUE ~ NA
  )
}

find_exact <- function(filename, required = TRUE) {
  hits <- list.files(
    ROOT_DIR,
    pattern = paste0("^", gsub("\\.", "\\\\.", filename), "$"),
    recursive = TRUE,
    full.names = TRUE,
    ignore.case = TRUE
  )
  if (length(hits) == 0) {
    if (required) {
      stop("Cannot find: ", filename, "\nSearched recursively under: ", ROOT_DIR)
    }
    return(NA_character_)
  }
  info <- file.info(hits)
  hits <- hits[order(info$mtime, decreasing = TRUE)]
  hits[1]
}

find_first_existing <- function(filenames, required = TRUE) {
  for (nm in filenames) {
    hit <- find_exact(nm, required = FALSE)
    if (!is.na(hit)) return(hit)
  }
  if (required) {
    stop("Cannot find any of: ", paste(filenames, collapse = ", "))
  }
  NA_character_
}

write_txt <- function(lines, path) {
  con <- file(path, open = "wt", encoding = "UTF-8")
  on.exit(close(con), add = TRUE)
  writeLines(lines, con, useBytes = TRUE)
}

safe_hc3 <- function(model) {
  tryCatch(
    sandwich::vcovHC(model, type = "HC3"),
    error = function(e) NULL
  )
}

tidy_robust <- function(model, model_name, exponentiate = FALSE) {
  vc <- safe_hc3(model)

  if (is.null(vc) || any(!is.finite(vc))) {
    return(
      tibble(
        model = model_name,
        term = names(coef(model)),
        estimate = unname(coef(model)),
        std_error = NA_real_,
        statistic = NA_real_,
        p_value = NA_real_,
        conf_low = NA_real_,
        conf_high = NA_real_,
        effect_ratio = NA_real_,
        effect_ratio_low = NA_real_,
        effect_ratio_high = NA_real_,
        hc3_status = "FAILED"
      )
    )
  }

  ct <- lmtest::coeftest(model, vcov. = vc)

  out <- tibble(
    model = model_name,
    term = rownames(ct),
    estimate = ct[, 1],
    std_error = ct[, 2],
    statistic = ct[, 3],
    p_value = ct[, 4],
    conf_low = ct[, 1] - 1.96 * ct[, 2],
    conf_high = ct[, 1] + 1.96 * ct[, 2],
    hc3_status = "PASS"
  )

  if (exponentiate) {
    out <- out %>%
      mutate(
        effect_ratio = exp(estimate),
        effect_ratio_low = exp(conf_low),
        effect_ratio_high = exp(conf_high)
      )
  } else {
    out <- out %>%
      mutate(
        effect_ratio = NA_real_,
        effect_ratio_low = NA_real_,
        effect_ratio_high = NA_real_
      )
  }

  out
}

make_formula <- function(outcome, rhs_terms) {
  as.formula(
    paste(outcome, "~", paste(rhs_terms, collapse = " + "))
  )
}

calc_sustained_onset <- function(
  year, frequency, window = 5L, min_positive = 3L
) {
  ord <- order(year)
  year <- as.integer(year[ord])
  frequency <- as.numeric(frequency[ord])
  positive <- !is.na(frequency) & frequency > 0

  if (length(positive) < window) return(NA_integer_)

  for (i in seq_len(length(positive) - window + 1L)) {
    idx <- i:(i + window - 1L)
    if (sum(positive[idx], na.rm = TRUE) >= min_positive) {
      return(year[i])
    }
  }
  NA_integer_
}

calc_sustained_onset_indicator <- function(
  year, positive, window = 5L, min_positive = 3L
) {
  ord <- order(year)
  year <- as.integer(year[ord])
  positive <- as.logical(positive[ord])
  positive[is.na(positive)] <- FALSE

  if (length(positive) < window) return(NA_integer_)

  for (i in seq_len(length(positive) - window + 1L)) {
    idx <- i:(i + window - 1L)
    if (sum(positive[idx]) >= min_positive) return(year[i])
  }
  NA_integer_
}

calc_consecutive_onset <- function(year, frequency, run = 3L) {
  ord <- order(year)
  year <- as.integer(year[ord])
  frequency <- as.numeric(frequency[ord])
  positive <- !is.na(frequency) & frequency > 0

  if (length(positive) < run) return(NA_integer_)

  for (i in seq_len(length(positive) - run + 1L)) {
    idx <- i:(i + run - 1L)
    if (all(positive[idx])) return(year[i])
  }
  NA_integer_
}

calc_term_metrics <- function(df) {
  df <- df %>% arrange(year)
  year <- df$year
  freq <- df$frequency

  first_positive_year <- if (any(freq > 0, na.rm = TRUE)) {
    min(year[freq > 0], na.rm = TRUE)
  } else NA_integer_

  onset_main <- calc_sustained_onset(
    year, freq, MAIN_WINDOW, MAIN_MIN_POSITIVE
  )

  onset_4of5 <- calc_sustained_onset(year, freq, 5L, 4L)
  onset_3consecutive <- calc_consecutive_onset(year, freq, 3L)

  roll10 <- slider::slide_dbl(
    freq, mean,
    .before = 4L,
    .after = 5L,
    .complete = TRUE,
    na.rm = TRUE
  )

  raw_peak_year <- if (all(is.na(freq))) {
    NA_integer_
  } else {
    year[which.max(replace(freq, is.na(freq), -Inf))][1]
  }

  rolling_peak_year <- if (all(is.na(roll10))) {
    NA_integer_
  } else {
    year[which.max(replace(roll10, is.na(roll10), -Inf))][1]
  }

  rolling_peak_frequency <- if (all(is.na(roll10))) {
    NA_real_
  } else {
    max(roll10, na.rm = TRUE)
  }

  if (!is.na(onset_main)) {
    post <- year >= onset_main
    exposure_years <- sum(post)
    persistence <- mean(freq[post] > 0, na.rm = TRUE)
  } else {
    exposure_years <- NA_integer_
    persistence <- NA_real_
  }

  contemporary_mean <- mean(
    freq[year >= 2000 & year <= 2022],
    na.rm = TRUE
  )

  contemporary_retention <- if (
    is.finite(rolling_peak_frequency) &&
    rolling_peak_frequency > 0
  ) {
    contemporary_mean / rolling_peak_frequency
  } else NA_real_

  tibble(
    first_positive_year = first_positive_year,
    sustained_onset = onset_main,
    sustained_onset_4of5 = onset_4of5,
    sustained_onset_3consecutive = onset_3consecutive,
    raw_peak_year = raw_peak_year,
    rolling10_peak_year = rolling_peak_year,
    max_frequency = max(freq, na.rm = TRUE),
    rolling10_peak_frequency = rolling_peak_frequency,
    exposure_years = exposure_years,
    persistence = persistence,
    contemporary_mean_2000_2022 = contemporary_mean,
    contemporary_retention = contemporary_retention,
    positive_year_share = mean(freq > 0, na.rm = TRUE),
    cumulative_frequency = sum(freq, na.rm = TRUE)
  )
}

collapse_domain3 <- function(x) {
  case_when(
    x %in% c(
      "food_drink",
      "body_medicine_martial",
      "heritage_historical_space",
      "material_culture_architecture"
    ) ~ "material_practice",

    x %in% c(
      "arts_literature_writing_language",
      "festivals_ritual_myth",
      "philosophy_religion_cosmology"
    ) ~ "symbolic_ideational",

    x %in% c(
      "popular_digital",
      "social_political_historical"
    ) ~ "social_political_modern",

    TRUE ~ NA_character_
  )
}


# ------------------------------------------------------------
# 3. LOCATE INPUTS
# ------------------------------------------------------------
FINAL_ANNUAL_FILE <- if (!is.na(FINAL_ANNUAL_OVERRIDE)) {
  FINAL_ANNUAL_OVERRIDE
} else {
  find_exact("Semantic_Clean_Annual_Data_FINAL.csv")
}

FINAL_SEMANTIC_FILE <- if (!is.na(FINAL_SEMANTIC_OVERRIDE)) {
  FINAL_SEMANTIC_OVERRIDE
} else {
  find_first_existing(
    c("Semantic_75_FINAL_USED.csv", "Semantic_75_FINAL.csv"),
    required = FALSE
  )
}

LEXICON_FILE <- if (!is.na(LEXICON_OVERRIDE)) {
  LEXICON_OVERRIDE
} else {
  find_exact("ngram_main_sample_cleaned.csv", required = FALSE)
}

DOWNLOAD_LOG_FILE <- if (!is.na(DOWNLOAD_LOG_OVERRIDE)) {
  DOWNLOAD_LOG_OVERRIDE
} else {
  find_exact("Google_Ngram_download_log.csv", required = FALSE)
}

HIST_VARIANTS_FILE <- if (!is.na(HIST_VARIANTS_OVERRIDE)) {
  HIST_VARIANTS_OVERRIDE
} else {
  find_exact("historical_spelling_annual_variants.csv", required = FALSE)
}

HIST_MAP_FILE <- if (!is.na(HIST_MAP_OVERRIDE)) {
  HIST_MAP_OVERRIDE
} else {
  find_exact("historical_spelling_variant_map_predefined.csv", required = FALSE)
}

cat("\n================ INPUT FILES ================\n")
cat("FINAL annual:", FINAL_ANNUAL_FILE, "\n")
cat("Final semantic:", FINAL_SEMANTIC_FILE, "\n")
cat("Lexicon:", LEXICON_FILE, "\n")
cat("Download log:", DOWNLOAD_LOG_FILE, "\n")
cat("Historical variants:", HIST_VARIANTS_FILE, "\n")
cat("Historical map:", HIST_MAP_FILE, "\n")
cat("=============================================\n\n")


# ------------------------------------------------------------
# 4. READ + AUDIT FINAL ANNUAL DATA
# ------------------------------------------------------------
main <- suppressMessages(
  read_csv(
    FINAL_ANNUAL_FILE,
    show_col_types = FALSE,
    progress = FALSE
  )
)

required_cols <- c(
  "row_id", "term", "ngram_query", "pathway",
  "pathway_comparison_eligible", "cultural_domain",
  "concept_group", "query_risk", "case_insensitive",
  "year", "frequency", "decision", "valid_from_year"
)

missing_cols <- setdiff(required_cols, names(main))
if (length(missing_cols) > 0) {
  stop("FINAL annual data missing columns: ",
       paste(missing_cols, collapse = ", "))
}

main <- main %>%
  mutate(
    row_id = as.integer(row_id),
    year = as.integer(year),
    frequency = as.numeric(frequency),
    pathway_comparison_eligible =
      to_logical(pathway_comparison_eligible),
    case_insensitive = to_logical(case_insensitive),
    decision = tolower(trimws(as.character(decision))),
    valid_from_year = as.integer(valid_from_year)
  ) %>%
  arrange(row_id, year)

duplicate_n <- main %>%
  count(row_id, year) %>%
  filter(n > 1) %>%
  nrow()

if (duplicate_n > 0) {
  stop("FINAL annual data contain duplicate row_id-year records.")
}

if (any(main$year < YEAR_START | main$year > YEAR_END)) {
  stop("FINAL annual data contain years outside 1800-2022.")
}

term_meta <- main %>%
  distinct(
    row_id, term, ngram_query, pathway,
    pathway_comparison_eligible, cultural_domain,
    concept_group, query_risk, case_insensitive,
    decision, valid_from_year
  ) %>%
  mutate(
    token_count = str_count(ngram_query, "\\S+"),
    domain3 = collapse_domain3(cultural_domain),
    pathway_analysis = if_else(
      pathway_comparison_eligible %in% TRUE &
        pathway %in% c("direct_borrowing", "calque"),
      pathway,
      NA_character_
    ),
    pathway_analysis = factor(
      pathway_analysis,
      levels = c("direct_borrowing", "calque")
    ),
    query_risk = factor(
      query_risk,
      levels = c("low", "moderate")
    ),
    case_insensitive = factor(case_insensitive),
    domain3 = factor(
      domain3,
      levels = c(
        "material_practice",
        "symbolic_ideational",
        "social_political_modern"
      )
    )
  )

domain3_mapping <- tibble(
  cultural_domain = c(
    "food_drink",
    "body_medicine_martial",
    "heritage_historical_space",
    "material_culture_architecture",
    "arts_literature_writing_language",
    "festivals_ritual_myth",
    "philosophy_religion_cosmology",
    "popular_digital",
    "social_political_historical"
  ),
  domain3 = c(
    "material_practice",
    "material_practice",
    "material_practice",
    "material_practice",
    "symbolic_ideational",
    "symbolic_ideational",
    "symbolic_ideational",
    "social_political_modern",
    "social_political_modern"
  )
)

write_csv(
  domain3_mapping,
  file.path(OUT_DIR, "Table_S0_FINAL_domain3_mapping.csv")
)

audit_summary <- tibble(
  item = c(
    "FINAL annual rows",
    "FINAL unique retained terms",
    "row_id-year duplicates",
    "minimum year",
    "maximum year",
    "direct borrowing retained",
    "calque retained",
    "overlap retained"
  ),
  value = c(
    nrow(main),
    n_distinct(main$row_id),
    duplicate_n,
    min(main$year),
    max(main$year),
    sum(term_meta$pathway == "direct_borrowing"),
    sum(term_meta$pathway == "calque"),
    sum(term_meta$pathway == "overlap_direct_and_calque")
  )
)

write_csv(audit_summary, file.path(OUT_DIR, "Table_1_FINAL_data_audit.csv"))

if (!is.na(FINAL_SEMANTIC_FILE) && file.exists(FINAL_SEMANTIC_FILE)) {
  final_sem <- suppressMessages(
    read_csv(FINAL_SEMANTIC_FILE, show_col_types = FALSE)
  )

  dec_col <- if ("final_decision" %in% names(final_sem)) {
    "final_decision"
  } else if ("decision" %in% names(final_sem)) {
    "decision"
  } else NA_character_

  if (!is.na(dec_col)) {
    semantic_counts <- final_sem %>%
      mutate(decision_final = tolower(trimws(.data[[dec_col]]))) %>%
      count(decision_final, name = "n")

    write_csv(
      semantic_counts,
      file.path(OUT_DIR, "Table_1_FINAL_semantic_decision_counts.csv")
    )
  }
}


# ------------------------------------------------------------
# 5. ORIGINAL DOWNLOAD COVERAGE (OPTIONAL)
# ------------------------------------------------------------
if (
  !is.na(LEXICON_FILE) && file.exists(LEXICON_FILE) &&
  !is.na(DOWNLOAD_LOG_FILE) && file.exists(DOWNLOAD_LOG_FILE)
) {
  lexicon <- suppressMessages(
    read_csv(LEXICON_FILE, show_col_types = FALSE)
  ) %>%
    mutate(row_id = row_number())

  dlog <- suppressMessages(
    read_csv(DOWNLOAD_LOG_FILE, show_col_types = FALSE)
  ) %>%
    mutate(row_id = as.integer(row_id))

  coverage <- lexicon %>%
    select(row_id, term, pathway, cultural_domain) %>%
    left_join(
      dlog %>% select(row_id, status, n_rows),
      by = "row_id"
    ) %>%
    mutate(download_success = status == "success")

  coverage_summary <- tibble(
    core_terms = nrow(lexicon),
    successful_series = sum(coverage$download_success, na.rm = TRUE),
    failed_or_no_data = sum(!coverage$download_success, na.rm = TRUE),
    success_rate = mean(coverage$download_success, na.rm = TRUE)
  )

  write_csv(
    coverage_summary,
    file.path(OUT_DIR, "Table_1_original_download_coverage.csv")
  )

  pathway_missing <- coverage %>%
    filter(pathway %in% c("direct_borrowing", "calque")) %>%
    count(pathway, download_success, name = "n") %>%
    complete(pathway, download_success, fill = list(n = 0))

  write_csv(
    pathway_missing,
    file.path(OUT_DIR, "Table_S1_download_success_by_pathway.csv")
  )

  ftab <- table(
    coverage$pathway[coverage$pathway %in% c("direct_borrowing", "calque")],
    coverage$download_success[coverage$pathway %in% c("direct_borrowing", "calque")]
  )

  fisher_download <- fisher.test(
    ftab,
    simulate.p.value = TRUE,
    B = MONTE_CARLO_B
  )

  write_csv(
    tibble(
      p_value = fisher_download$p.value,
      B = MONTE_CARLO_B
    ),
    file.path(OUT_DIR, "Table_S1_download_missingness_Fisher.csv")
  )
}


# ------------------------------------------------------------
# 6. TERM-LEVEL HISTORICAL METRICS
# ------------------------------------------------------------
term_metrics <- main %>%
  group_by(row_id) %>%
  group_modify(~ calc_term_metrics(.x)) %>%
  ungroup() %>%
  left_join(term_meta, by = "row_id") %>%
  mutate(
    token_count_c = token_count - mean(token_count, na.rm = TRUE)
  )

write_csv(
  term_metrics,
  file.path(OUT_DIR, "Table_3_FINAL_term_level_historical_metrics.csv")
)

# Guardrails for proportion models.
if (any(
  term_metrics$persistence < 0 |
    term_metrics$persistence > 1,
  na.rm = TRUE
)) stop("Persistence outside [0,1].")

if (any(
  term_metrics$contemporary_retention < 0 |
    term_metrics$contemporary_retention > 1,
  na.rm = TRUE
)) stop("Contemporary retention outside [0,1].")


# ------------------------------------------------------------
# 7. ANNUAL PANEL
# ------------------------------------------------------------
panel <- main %>%
  left_join(
    term_metrics %>%
      select(
        row_id, sustained_onset, pathway_analysis,
        domain3, token_count_c
      ),
    by = "row_id"
  ) %>%
  mutate(
    frequency_per_billion = frequency * 1e9,
    log_frequency = log1p(frequency_per_billion)
  ) %>%
  group_by(row_id) %>%
  mutate(
    term_log_mean = mean(log_frequency, na.rm = TRUE),
    term_log_sd = sd(log_frequency, na.rm = TRUE),
    z_log_frequency = if_else(
      is.finite(term_log_sd) & term_log_sd > 0,
      (log_frequency - term_log_mean) / term_log_sd,
      0
    )
  ) %>%
  ungroup()


# ------------------------------------------------------------
# 8. H1: PATHWAY × CULTURAL DOMAIN
# ------------------------------------------------------------
h1_data <- term_metrics %>%
  filter(!is.na(pathway_analysis))

path_domain_tab <- table(
  h1_data$cultural_domain,
  h1_data$pathway_analysis
)

path_domain_counts <- as.data.frame.matrix(path_domain_tab) %>%
  tibble::rownames_to_column("cultural_domain")

chi_standard <- suppressWarnings(
  chisq.test(path_domain_tab, correct = FALSE)
)

set.seed(20261029)
chi_mc <- chisq.test(
  path_domain_tab,
  simulate.p.value = TRUE,
  B = MONTE_CARLO_B
)

cramers_v <- sqrt(
  as.numeric(chi_standard$statistic) /
    (
      sum(path_domain_tab) *
        min(nrow(path_domain_tab) - 1, ncol(path_domain_tab) - 1)
    )
)

h1_test <- tibble(
  n = sum(path_domain_tab),
  chi_square = as.numeric(chi_standard$statistic),
  df = as.numeric(chi_standard$parameter),
  p_asymptotic = chi_standard$p.value,
  p_monte_carlo = chi_mc$p.value,
  monte_carlo_B = MONTE_CARLO_B,
  cramers_v = cramers_v,
  min_expected_count = min(chi_standard$expected)
)

h1_residuals <- as.data.frame(
  as.table(chi_standard$stdres)
) %>%
  rename(
    cultural_domain = Var1,
    pathway = Var2,
    standardized_residual = Freq
  )

write_csv(
  path_domain_counts,
  file.path(OUT_DIR, "Table_2_FINAL_pathway_by_domain_counts.csv")
)
write_csv(
  h1_test,
  file.path(OUT_DIR, "Table_2_FINAL_H1_test.csv")
)
write_csv(
  h1_residuals,
  file.path(OUT_DIR, "Table_2_FINAL_H1_standardized_residuals.csv")
)


# ------------------------------------------------------------
# 9. H2: ONSET / PERSISTENCE / RETENTION
# ------------------------------------------------------------
h2_data <- term_metrics %>%
  filter(
    !is.na(pathway_analysis),
    !is.na(domain3),
    !is.na(sustained_onset),
    !is.na(persistence),
    !is.na(contemporary_retention)
  ) %>%
  mutate(
    pathway_analysis = relevel(pathway_analysis, ref = "direct_borrowing"),
    domain3 = relevel(domain3, ref = "material_practice"),
    query_risk = relevel(query_risk, ref = "low")
  )

h2_desc <- h2_data %>%
  group_by(pathway_analysis) %>%
  summarise(
    n = n(),
    onset_median = median(sustained_onset),
    onset_IQR = IQR(sustained_onset),
    persistence_median = median(persistence),
    persistence_IQR = IQR(persistence),
    retention_median = median(contemporary_retention),
    retention_IQR = IQR(contemporary_retention),
    .groups = "drop"
  )

wilcox_results <- bind_rows(
  broom::tidy(
    wilcox.test(
      sustained_onset ~ pathway_analysis,
      data = h2_data,
      exact = FALSE
    )
  ) %>% mutate(outcome = "sustained_onset"),

  broom::tidy(
    wilcox.test(
      persistence ~ pathway_analysis,
      data = h2_data,
      exact = FALSE
    )
  ) %>% mutate(outcome = "persistence"),

  broom::tidy(
    wilcox.test(
      contemporary_retention ~ pathway_analysis,
      data = h2_data,
      exact = FALSE
    )
  ) %>% mutate(outcome = "contemporary_retention")
)

h2_rhs <- c(
  "pathway_analysis",
  "domain3",
  "token_count_c",
  "query_risk",
  "case_insensitive"
)

fit_onset <- lm(
  make_formula("sustained_onset", h2_rhs),
  data = h2_data
)

fit_persistence <- glm(
  make_formula("persistence", h2_rhs),
  data = h2_data,
  family = quasibinomial(link = "logit"),
  weights = exposure_years
)

fit_retention <- glm(
  make_formula("contemporary_retention", h2_rhs),
  data = h2_data,
  family = quasibinomial(link = "logit")
)

h2_models <- bind_rows(
  tidy_robust(
    fit_onset,
    "sustained_onset_year",
    exponentiate = FALSE
  ),
  tidy_robust(
    fit_persistence,
    "persistence_fractional_logit",
    exponentiate = TRUE
  ),
  tidy_robust(
    fit_retention,
    "contemporary_retention_fractional_logit",
    exponentiate = TRUE
  )
)

# H2 leverage / design diagnostics
X_h2 <- model.matrix(fit_onset)
hat_h2 <- hatvalues(fit_onset)

h2_diag <- tibble(
  n = nrow(h2_data),
  model_rank = fit_onset$rank,
  design_columns = ncol(X_h2),
  full_rank = fit_onset$rank == ncol(X_h2),
  max_hat = max(hat_h2),
  mean_hat = mean(hat_h2)
)

h2_leverage <- h2_data %>%
  select(row_id, term, pathway, cultural_domain, domain3) %>%
  mutate(hat_value = hat_h2) %>%
  arrange(desc(hat_value))

write_csv(h2_desc, file.path(OUT_DIR, "Table_3_FINAL_H2_descriptive.csv"))
write_csv(
  wilcox_results,
  file.path(OUT_DIR, "Table_S2_FINAL_H2_Wilcoxon.csv")
)
write_csv(h2_models, file.path(OUT_DIR, "Table_4_FINAL_H2_adjusted_models.csv"))
write_csv(h2_diag, file.path(OUT_DIR, "Table_S3_FINAL_H2_model_diagnostics.csv"))
write_csv(
  h2_leverage,
  file.path(OUT_DIR, "Table_S3_FINAL_H2_leverage.csv")
)


# ------------------------------------------------------------
# 10. ONSET-DEFINITION SENSITIVITY
#     Refit the same adjusted H2 model for all onset definitions.
# ------------------------------------------------------------
fit_alt_onset <- function(outcome, label) {
  dat <- h2_data %>% filter(!is.na(.data[[outcome]]))
  m <- lm(make_formula(outcome, h2_rhs), data = dat)
  tidy_robust(m, label, exponentiate = FALSE)
}

onset_sensitivity_models <- bind_rows(
  fit_alt_onset("sustained_onset", "onset_3of5"),
  fit_alt_onset("sustained_onset_4of5", "onset_4of5"),
  fit_alt_onset(
    "sustained_onset_3consecutive",
    "onset_3_consecutive"
  )
)

onset_sensitivity_desc <- term_metrics %>%
  filter(!is.na(pathway_analysis)) %>%
  group_by(pathway_analysis) %>%
  summarise(
    n = n(),
    median_3of5 = median(sustained_onset, na.rm = TRUE),
    median_4of5 = median(sustained_onset_4of5, na.rm = TRUE),
    median_3consecutive =
      median(sustained_onset_3consecutive, na.rm = TRUE),
    .groups = "drop"
  )

write_csv(
  onset_sensitivity_models,
  file.path(OUT_DIR, "Table_S4_FINAL_onset_definition_models.csv")
)
write_csv(
  onset_sensitivity_desc,
  file.path(OUT_DIR, "Table_S4_FINAL_onset_definition_descriptive.csv")
)


# ------------------------------------------------------------
# 11. LOW QUERY-RISK SENSITIVITY
# ------------------------------------------------------------
low_risk_data <- h2_data %>%
  filter(query_risk == "low") %>%
  droplevels()

if (nrow(low_risk_data) >= 30) {
  low_rhs <- c(
    "pathway_analysis",
    "domain3",
    "token_count_c",
    "case_insensitive"
  )

  low_onset <- lm(
    make_formula("sustained_onset", low_rhs),
    data = low_risk_data
  )

  low_persistence <- glm(
    make_formula("persistence", low_rhs),
    data = low_risk_data,
    family = quasibinomial(link = "logit"),
    weights = exposure_years
  )

  low_retention <- glm(
    make_formula("contemporary_retention", low_rhs),
    data = low_risk_data,
    family = quasibinomial(link = "logit")
  )

  lowrisk_results <- bind_rows(
    tidy_robust(low_onset, "low_risk_onset", FALSE),
    tidy_robust(low_persistence, "low_risk_persistence", TRUE),
    tidy_robust(low_retention, "low_risk_retention", TRUE)
  )

  write_csv(
    lowrisk_results,
    file.path(OUT_DIR, "Table_S5_FINAL_low_query_risk_models.csv")
  )
}


# ------------------------------------------------------------
# 12. RQ1: DOMAIN CHANGE BY DECADE
# ------------------------------------------------------------
decade_panel <- panel %>%
  mutate(decade = floor(year / 10) * 10) %>%
  group_by(row_id, term, cultural_domain, decade) %>%
  summarise(
    n_valid_years = n(),
    positive_years = sum(frequency > 0, na.rm = TRUE),
    mean_frequency = mean(frequency, na.rm = TRUE),
    active_decade =
      positive_years >= ceiling(0.30 * n_valid_years),
    .groups = "drop"
  )

domain_decade <- decade_panel %>%
  filter(active_decade) %>%
  count(decade, cultural_domain, name = "active_terms") %>%
  group_by(decade) %>%
  mutate(
    all_active_terms = sum(active_terms),
    domain_share = active_terms / all_active_terms
  ) %>%
  ungroup()

decade_totals <- decade_panel %>%
  filter(active_decade) %>%
  summarise(
    active_terms = n_distinct(row_id),
    .by = decade
  )

write_csv(
  domain_decade,
  file.path(OUT_DIR, "RQ1_FINAL_domain_by_decade.csv")
)
write_csv(
  decade_totals,
  file.path(OUT_DIR, "RQ1_FINAL_total_active_terms_by_decade.csv")
)

p_domain_count <- ggplot(
  domain_decade,
  aes(
    x = decade,
    y = active_terms,
    group = cultural_domain,
    linetype = cultural_domain
  )
) +
  geom_line(linewidth = 0.65) +
  geom_point(size = 1.3) +
  labs(
    x = "Decade",
    y = "Number of active terms",
    linetype = "Cultural domain"
  )

ggsave(
  file.path(OUT_DIR, "Figure_1_FINAL_domain_active_terms.png"),
  p_domain_count,
  width = 9,
  height = 5.5,
  dpi = 600
)
ggsave(
  file.path(OUT_DIR, "Figure_1_FINAL_domain_active_terms.pdf"),
  p_domain_count,
  width = 9,
  height = 5.5
)

# Grayscale-friendly composition plot.
p_domain_share <- ggplot(
  domain_decade,
  aes(
    x = factor(decade),
    y = domain_share,
    group = cultural_domain,
    linetype = cultural_domain
  )
) +
  geom_line(linewidth = 0.7) +
  geom_point(size = 1.2) +
  scale_y_continuous(labels = percent_format(accuracy = 1)) +
  labs(
    x = "Decade",
    y = "Share of active terms",
    linetype = "Cultural domain"
  ) +
  theme(
    axis.text.x = element_text(angle = 45, hjust = 1)
  )

ggsave(
  file.path(OUT_DIR, "Figure_2_FINAL_domain_composition.png"),
  p_domain_share,
  width = 9,
  height = 5.5,
  dpi = 600
)
ggsave(
  file.path(OUT_DIR, "Figure_2_FINAL_domain_composition.pdf"),
  p_domain_share,
  width = 9,
  height = 5.5
)


# ------------------------------------------------------------
# 13. RQ2: NONLINEAR PATHWAY TRAJECTORIES WITH AR(1)
# ------------------------------------------------------------
trajectory_data <- panel %>%
  filter(!is.na(pathway_analysis)) %>%
  mutate(
    pathway_analysis = droplevels(pathway_analysis),
    term_factor = factor(row_id)
  ) %>%
  arrange(row_id, year) %>%
  group_by(row_id) %>%
  mutate(AR_start = row_number() == 1L) %>%
  ungroup()

bam_initial <- mgcv::bam(
  z_log_frequency ~
    pathway_analysis +
    s(year, by = pathway_analysis, k = 15) +
    s(term_factor, bs = "re"),
  data = trajectory_data,
  method = "fREML",
  discrete = TRUE
)

trajectory_data$resid_initial <- residuals(bam_initial)

rho_by_term <- trajectory_data %>%
  group_by(row_id) %>%
  summarise(
    rho = if (
      n() >= 3 &&
      sd(resid_initial, na.rm = TRUE) > 0
    ) {
      suppressWarnings(
        cor(
          resid_initial[-n()],
          resid_initial[-1],
          use = "complete.obs"
        )
      )
    } else NA_real_,
    .groups = "drop"
  )

rho_hat <- median(rho_by_term$rho, na.rm = TRUE)
if (!is.finite(rho_hat)) rho_hat <- 0
rho_hat <- max(0, min(rho_hat, 0.90))

bam_ar1 <- mgcv::bam(
  z_log_frequency ~
    pathway_analysis +
    s(year, by = pathway_analysis, k = 15) +
    s(term_factor, bs = "re"),
  data = trajectory_data,
  method = "fREML",
  discrete = TRUE,
  rho = rho_hat,
  AR.start = trajectory_data$AR_start
)

capture.output(
  summary(bam_ar1),
  file = file.path(OUT_DIR, "RQ2_FINAL_BAM_AR1_summary.txt")
)

write_csv(
  tibble(estimated_AR1_rho = rho_hat),
  file.path(OUT_DIR, "RQ2_FINAL_BAM_AR1_rho.csv")
)

prediction_grid <- expand_grid(
  year = YEAR_START:YEAR_END,
  pathway_analysis = factor(
    c("direct_borrowing", "calque"),
    levels = levels(trajectory_data$pathway_analysis)
  )
) %>%
  mutate(
    term_factor = factor(
      levels(trajectory_data$term_factor)[1],
      levels = levels(trajectory_data$term_factor)
    )
  )

pred <- predict(
  bam_ar1,
  newdata = prediction_grid,
  se.fit = TRUE,
  exclude = "s(term_factor)"
)

trajectory_prediction <- prediction_grid %>%
  mutate(
    fitted = as.numeric(pred$fit),
    se = as.numeric(pred$se.fit),
    lower = fitted - 1.96 * se,
    upper = fitted + 1.96 * se
  )

write_csv(
  trajectory_prediction,
  file.path(OUT_DIR, "RQ2_FINAL_pathway_trajectory_predictions.csv")
)

p_trajectory <- ggplot(
  trajectory_prediction,
  aes(
    x = year,
    y = fitted,
    linetype = pathway_analysis
  )
) +
  geom_ribbon(
    data = trajectory_prediction,
    aes(
      x = year,
      ymin = lower,
      ymax = upper,
      group = pathway_analysis
    ),
    inherit.aes = FALSE,
    alpha = 0.12
  ) +
  geom_line(linewidth = 0.85) +
  labs(
    x = "Year",
    y = "Within-term standardized log visibility",
    linetype = "Transmission pathway"
  )

ggsave(
  file.path(OUT_DIR, "Figure_3_FINAL_pathway_trajectories.png"),
  p_trajectory,
  width = 9,
  height = 5.4,
  dpi = 600
)
ggsave(
  file.path(OUT_DIR, "Figure_3_FINAL_pathway_trajectories.pdf"),
  p_trajectory,
  width = 9,
  height = 5.4
)


# ------------------------------------------------------------
# 14. RQ3: PATHWAY × DOMAIN EXPLORATORY INTERACTIONS
# ------------------------------------------------------------
domain_cell_n <- h2_data %>%
  count(cultural_domain, pathway_analysis, name = "n") %>%
  complete(
    cultural_domain,
    pathway_analysis,
    fill = list(n = 0)
  )

interaction_domains <- domain_cell_n %>%
  group_by(cultural_domain) %>%
  summarise(min_cell_n = min(n), .groups = "drop") %>%
  filter(min_cell_n >= 3) %>%
  pull(cultural_domain)

write_csv(
  domain_cell_n,
  file.path(OUT_DIR, "RQ3_FINAL_pathway_domain_cell_counts.csv")
)

rq3_results <- tibble()

if (length(interaction_domains) >= 2) {
  rq3_data <- h2_data %>%
    filter(cultural_domain %in% interaction_domains) %>%
    mutate(
      domain_interaction = factor(cultural_domain),
      domain_interaction = relevel(
        domain_interaction,
        ref = levels(domain_interaction)[1]
      )
    )

  rq3_rhs <- c(
    "pathway_analysis * domain_interaction",
    "token_count_c",
    "query_risk",
    "case_insensitive"
  )

  rq3_onset <- lm(
    make_formula("sustained_onset", rq3_rhs),
    data = rq3_data
  )

  rq3_persistence <- glm(
    make_formula("persistence", rq3_rhs),
    data = rq3_data,
    family = quasibinomial(link = "logit"),
    weights = exposure_years
  )

  rq3_retention <- glm(
    make_formula("contemporary_retention", rq3_rhs),
    data = rq3_data,
    family = quasibinomial(link = "logit")
  )

  rq3_results <- bind_rows(
    tidy_robust(rq3_onset, "RQ3_onset", FALSE),
    tidy_robust(rq3_persistence, "RQ3_persistence", TRUE),
    tidy_robust(rq3_retention, "RQ3_retention", TRUE)
  )

  write_csv(
    rq3_results,
    file.path(OUT_DIR, "RQ3_FINAL_pathway_by_domain_models.csv")
  )
}


# ------------------------------------------------------------
# 15. RQ4: MULTIPLE ENGLISH FORMS FOR THE SAME CONCEPT
# ------------------------------------------------------------
concept_flags <- term_metrics %>%
  filter(!is.na(concept_group), concept_group != "") %>%
  group_by(concept_group) %>%
  summarise(
    n_terms = n_distinct(row_id),
    has_direct = any(
      pathway %in% c(
        "direct_borrowing",
        "overlap_direct_and_calque"
      )
    ),
    has_calque = any(
      pathway %in% c(
        "calque",
        "overlap_direct_and_calque"
      )
    ),
    .groups = "drop"
  ) %>%
  filter(n_terms >= 2, has_direct, has_calque)

write_csv(
  concept_flags,
  file.path(OUT_DIR, "RQ4_FINAL_viable_concept_pairs.csv")
)

pair_metrics <- term_metrics %>%
  filter(concept_group %in% concept_flags$concept_group) %>%
  select(
    concept_group, row_id, term, pathway,
    sustained_onset, persistence, contemporary_retention,
    first_positive_year, decision, valid_from_year
  )

write_csv(
  pair_metrics,
  file.path(OUT_DIR, "RQ4_FINAL_concept_pair_metrics.csv")
)

if (nrow(concept_flags) > 0) {
  pair_panel <- panel %>%
    filter(concept_group %in% concept_flags$concept_group) %>%
    group_by(row_id) %>%
    mutate(
      relative_to_own_peak = if_else(
        max(frequency, na.rm = TRUE) > 0,
        frequency / max(frequency, na.rm = TRUE),
        0
      )
    ) %>%
    ungroup()

  write_csv(
    pair_panel,
    file.path(OUT_DIR, "RQ4_FINAL_concept_pair_annual_data.csv")
  )

  p_pairs <- ggplot(
    pair_panel,
    aes(
      x = year,
      y = relative_to_own_peak,
      linetype = term
    )
  ) +
    geom_line(linewidth = 0.65) +
    facet_wrap(~ concept_group, scales = "free_y") +
    scale_y_continuous(labels = percent_format(accuracy = 1)) +
    labs(
      x = "Year",
      y = "Frequency relative to each term's own peak",
      linetype = "English form"
    )

  ggsave(
    file.path(OUT_DIR, "Figure_4_FINAL_concept_pair_histories.png"),
    p_pairs,
    width = 10,
    height = 7,
    dpi = 600
  )
  ggsave(
    file.path(OUT_DIR, "Figure_4_FINAL_concept_pair_histories.pdf"),
    p_pairs,
    width = 10,
    height = 7
  )
}


# ------------------------------------------------------------
# 16. HISTORICAL SPELLING SENSITIVITY
# ------------------------------------------------------------
hist_status <- "NOT RUN"
hist_compare <- tibble()
hist_mapped <- tibble()

if (
  !is.na(HIST_VARIANTS_FILE) &&
  file.exists(HIST_VARIANTS_FILE) &&
  !is.na(HIST_MAP_FILE) &&
  file.exists(HIST_MAP_FILE)
) {
  hist_variants <- suppressMessages(
    read_csv(HIST_VARIANTS_FILE, show_col_types = FALSE)
  ) %>%
    mutate(
      row_id = as.integer(row_id),
      year = as.integer(year),
      frequency = as.numeric(frequency)
    ) %>%
    filter(year >= YEAR_START, year <= YEAR_END)

  hist_map <- suppressMessages(
    read_csv(HIST_MAP_FILE, show_col_types = FALSE)
  )

  # Keep only terms retained after FINAL semantic adjudication.
  retained_ids <- term_meta$row_id

  hist_variants <- hist_variants %>%
    filter(row_id %in% retained_ids)

  # Historical variants are curated alternative spellings.
  # We do NOT sum their frequencies. We only ask whether ANY
  # variant is positive in a given year.
  variant_positive <- hist_variants %>%
    group_by(row_id, year) %>%
    summarise(
      historical_positive = any(frequency > 0, na.rm = TRUE),
      .groups = "drop"
    )

  year_grid <- expand_grid(
    row_id = term_meta$row_id,
    year = YEAR_START:YEAR_END
  )

  current_positive <- main %>%
    transmute(
      row_id,
      year,
      current_positive = frequency > 0
    )

  family_panel <- year_grid %>%
    left_join(current_positive, by = c("row_id", "year")) %>%
    left_join(variant_positive, by = c("row_id", "year")) %>%
    mutate(
      current_positive = coalesce(current_positive, FALSE),
      historical_positive = coalesce(historical_positive, FALSE),
      family_positive = current_positive | historical_positive
    )

  family_onsets <- family_panel %>%
    group_by(row_id) %>%
    summarise(
      onset_family = calc_sustained_onset_indicator(
        year,
        family_positive,
        MAIN_WINDOW,
        MAIN_MIN_POSITIVE
      ),
      .groups = "drop"
    )

  current_onsets <- term_metrics %>%
    select(row_id, onset_current = sustained_onset)

  hist_mapped <- term_meta %>%
    select(row_id, term, pathway, cultural_domain) %>%
    left_join(current_onsets, by = "row_id") %>%
    left_join(family_onsets, by = "row_id") %>%
    mutate(
      shift = onset_family - onset_current,
      has_historical_variant =
        row_id %in% unique(hist_variants$row_id)
    )

  write_csv(
    hist_mapped,
    file.path(
      OUT_DIR,
      "HistoricalSpelling_FINAL_term_onsets.csv"
    )
  )

  # Same-sample before/after comparison, using exactly the H2 model
  # covariates and the same complete cases.
  hist_model_data <- h2_data %>%
    select(
      row_id, term, pathway_analysis, domain3,
      token_count_c, query_risk, case_insensitive,
      sustained_onset
    ) %>%
    left_join(
      family_onsets,
      by = "row_id"
    ) %>%
    filter(
      !is.na(sustained_onset),
      !is.na(onset_family)
    )

  # Freeze the same rows for both models.
  hist_model_data <- hist_model_data %>%
    mutate(
      onset_current = sustained_onset
    )

  hist_current_model <- lm(
    make_formula("onset_current", h2_rhs),
    data = hist_model_data
  )

  hist_family_model <- lm(
    make_formula("onset_family", h2_rhs),
    data = hist_model_data
  )

  extract_path_effect <- function(fitted_model, outcome_label) {
    n_model <- nobs(fitted_model)

    x <- tidy_robust(fitted_model, outcome_label, FALSE) %>%
      filter(term == "pathway_analysiscalque") %>%
      mutate(n = n_model) %>%
      select(
        outcome = model,
        n,
        b = estimate,
        se_hc3 = std_error,
        ci_low = conf_low,
        ci_high = conf_high,
        p = p_value,
        hc3_status
      )

    x
  }

  hist_compare <- bind_rows(
    extract_path_effect(
      hist_current_model,
      "onset_current_FINAL"
    ),
    extract_path_effect(
      hist_family_model,
      "onset_family_historical_spelling_FINAL"
    )
  )

  write_csv(
    hist_compare,
    file.path(
      OUT_DIR,
      "HistoricalSpelling_FINAL_path_effect_before_after.csv"
    )
  )

  hist_variant_summary <- tibble(
    mapped_variant_rows = nrow(hist_variants),
    mapped_unique_terms = n_distinct(hist_variants$row_id),
    terms_with_earlier_family_onset = sum(
      hist_mapped$shift < 0,
      na.rm = TRUE
    ),
    median_shift_among_shifted = if (
      any(hist_mapped$shift < 0, na.rm = TRUE)
    ) {
      median(
        hist_mapped$shift[hist_mapped$shift < 0],
        na.rm = TRUE
      )
    } else NA_real_
  )

  write_csv(
    hist_variant_summary,
    file.path(
      OUT_DIR,
      "HistoricalSpelling_FINAL_summary.csv"
    )
  )

  hist_status <- "PASS"
} else {
  warning(
    "Historical spelling files not found. Main FINAL analyses ran, ",
    "but historical-spelling sensitivity was skipped."
  )
}


# ------------------------------------------------------------
# 17. MANUSCRIPT-READY KEY RESULTS TABLE
# ------------------------------------------------------------
h1_key <- h1_test %>%
  transmute(
    section = "H1",
    result = paste0(
      "Chi-square=", round(chi_square, 2),
      "; df=", df,
      "; Monte Carlo p=", signif(p_monte_carlo, 4),
      "; Cramer's V=", round(cramers_v, 3),
      "; n=", n
    )
  )

h2_path <- h2_models %>%
  filter(term == "pathway_analysiscalque") %>%
  mutate(
    section = case_when(
      model == "sustained_onset_year" ~ "H2_onset",
      model == "persistence_fractional_logit" ~ "H2_persistence",
      model == "contemporary_retention_fractional_logit" ~ "H2_retention",
      TRUE ~ model
    ),
    result = case_when(
      model == "sustained_onset_year" ~ paste0(
        "b=", round(estimate, 2),
        "; HC3 SE=", round(std_error, 2),
        "; 95% CI [", round(conf_low, 2), ", ", round(conf_high, 2),
        "]; p=", signif(p_value, 4)
      ),
      TRUE ~ paste0(
        "OR=", round(effect_ratio, 2),
        "; 95% CI [", round(effect_ratio_low, 2), ", ",
        round(effect_ratio_high, 2),
        "]; p=", signif(p_value, 4)
      )
    )
  ) %>%
  select(section, result)

rq2_key <- tibble(
  section = "RQ2",
  result = paste0(
    "BAM AR(1) rho=", round(rho_hat, 3),
    "; adjusted R-sq=",
    round(summary(bam_ar1)$r.sq, 3)
  )
)

hist_key <- if (nrow(hist_compare) > 0) {
  hist_compare %>%
    mutate(
      section = paste0("Historical_spelling_", outcome),
      result = paste0(
        "b=", round(b, 2),
        "; HC3 SE=", round(se_hc3, 2),
        "; 95% CI [", round(ci_low, 2), ", ", round(ci_high, 2),
        "]; p=", signif(p, 4),
        "; n=", n
      )
    ) %>%
    select(section, result)
} else {
  tibble(
    section = "Historical_spelling",
    result = "Not run"
  )
}

key_results <- bind_rows(
  h1_key,
  h2_path,
  rq2_key,
  hist_key
)

write_csv(
  key_results,
  file.path(OUT_DIR, "00_MANUSCRIPT_KEY_RESULTS.csv")
)


# ------------------------------------------------------------
# 18. SUMMARY TEXT
# ------------------------------------------------------------
semantic_line <- if (exists("semantic_counts")) {
  paste(
    semantic_counts$decision_final,
    semantic_counts$n,
    sep = "=",
    collapse = "; "
  )
} else {
  "Semantic decision table not found"
}

h2_onset_key <- h2_models %>%
  filter(
    model == "sustained_onset_year",
    term == "pathway_analysiscalque"
  )

h2_pers_key <- h2_models %>%
  filter(
    model == "persistence_fractional_logit",
    term == "pathway_analysiscalque"
  )

h2_ret_key <- h2_models %>%
  filter(
    model == "contemporary_retention_fractional_logit",
    term == "pathway_analysiscalque"
  )

summary_lines <- c(
  "FINAL MASTER ANALYSIS",
  "=====================",
  "",
  paste0("FINAL annual source: ", FINAL_ANNUAL_FILE),
  paste0("FINAL retained terms: ", n_distinct(main$row_id)),
  paste0("FINAL annual rows: ", nrow(main)),
  paste0("Semantic decisions: ", semantic_line),
  "",
  paste0(
    "H1: chi-square=",
    round(h1_test$chi_square, 2),
    ", df=", h1_test$df,
    ", Monte Carlo p=",
    signif(h1_test$p_monte_carlo, 4),
    ", Cramer's V=",
    round(h1_test$cramers_v, 3),
    ", n=", h1_test$n
  ),
  "",
  paste0(
    "H2 onset pathway effect (calque vs direct): b=",
    round(h2_onset_key$estimate, 2),
    ", HC3 SE=",
    round(h2_onset_key$std_error, 2),
    ", 95% CI [",
    round(h2_onset_key$conf_low, 2),
    ", ",
    round(h2_onset_key$conf_high, 2),
    "], p=",
    signif(h2_onset_key$p_value, 4)
  ),
  paste0(
    "H2 persistence pathway effect: OR=",
    round(h2_pers_key$effect_ratio, 2),
    ", p=",
    signif(h2_pers_key$p_value, 4)
  ),
  paste0(
    "H2 retention pathway effect: OR=",
    round(h2_ret_key$effect_ratio, 2),
    ", p=",
    signif(h2_ret_key$p_value, 4)
  ),
  "",
  paste0(
    "RQ2 BAM AR(1) rho=",
    round(rho_hat, 3),
    "; adjusted R-sq=",
    round(summary(bam_ar1)$r.sq, 3)
  ),
  "",
  paste0(
    "RQ3 eligible interaction domains: ",
    paste(interaction_domains, collapse = " | ")
  ),
  paste0(
    "RQ4 viable concept groups: ",
    paste(concept_flags$concept_group, collapse = " | ")
  ),
  "",
  paste0("Historical spelling sensitivity status: ", hist_status),
  if (nrow(hist_compare) > 0) {
    paste(
      capture.output(print(hist_compare)),
      collapse = "\n"
    )
  } else {
    "Historical spelling comparison unavailable."
  },
  "",
  "Use these FINAL outputs for manuscript revision. Do not reuse old numerical results."
)

write_txt(
  summary_lines,
  file.path(OUT_DIR, "00_FINAL_RESULTS_SUMMARY.txt")
)


# ------------------------------------------------------------
# 19. SAVE MODELS / SESSION
# ------------------------------------------------------------
model_list <- list(
  H2_onset = fit_onset,
  H2_persistence = fit_persistence,
  H2_retention = fit_retention,
  RQ2_bam_initial = bam_initial,
  RQ2_bam_ar1 = bam_ar1
)

if (exists("rq3_onset")) {
  model_list$RQ3_onset <- rq3_onset
  model_list$RQ3_persistence <- rq3_persistence
  model_list$RQ3_retention <- rq3_retention
}

if (exists("hist_current_model")) {
  model_list$Historical_current <- hist_current_model
  model_list$Historical_family <- hist_family_model
}

saveRDS(
  model_list,
  file.path(OUT_DIR, "FINAL_MODELS.rds")
)

capture.output(
  sessionInfo(),
  file = file.path(OUT_DIR, "sessionInfo_FINAL.txt")
)


# ------------------------------------------------------------
# 20. CONSOLE
# ------------------------------------------------------------
cat("\n============================================================\n")
cat("FINAL MASTER ANALYSIS COMPLETE\n")
cat("============================================================\n")
cat("FINAL retained terms:", n_distinct(main$row_id), "\n")
cat("FINAL annual rows:", nrow(main), "\n")
cat("H1 Monte Carlo p:", h1_test$p_monte_carlo, "\n")
cat("H1 Cramer's V:", h1_test$cramers_v, "\n")

cat("\nH2 pathway coefficients:\n")
print(
  h2_models %>%
    filter(term == "pathway_analysiscalque")
)

cat("\nHistorical spelling sensitivity:", hist_status, "\n")
if (nrow(hist_compare) > 0) print(hist_compare)

cat("\nOutput directory:\n", OUT_DIR, "\n", sep = "")
cat("\nFIRST FILE TO OPEN:\n")
cat(file.path(OUT_DIR, "00_FINAL_RESULTS_SUMMARY.txt"), "\n")
cat("\nThen upload the whole FINAL_ANALYSIS_OUTPUTS folder or the key CSV/TXT files to ChatGPT.\n")
cat("============================================================\n")
