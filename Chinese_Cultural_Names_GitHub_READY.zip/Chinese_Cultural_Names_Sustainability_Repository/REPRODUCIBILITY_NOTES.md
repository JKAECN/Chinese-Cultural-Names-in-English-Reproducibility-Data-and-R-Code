# Reproducibility Notes

## Authoritative analysis path

The final manuscript results are reproduced from:

1. `data/02_semantic_rebuild/Semantic_Clean_Annual_Data_FINAL.csv`
2. the final pathway and chronological audit rules in `data/04_final_analysis/`
3. the verified historical-spelling inputs in `data/03_historical_spelling/`
4. `scripts/final/10_FINAL_SUBMISSION_ANALYSIS_GITHUB.R`

Run the final script from the repository root.

## Do not mix archived and final outputs

Files under `archive/` are retained to document the evolution of the workflow. They include earlier semantic-coding generators, earlier main-analysis scripts, intermediate diagnostics, and output snapshots.

They are not interchangeable with the final files.

## Original local paths

Some archived process scripts preserve the original Windows project path for provenance. The GitHub-ready final script does not require that path. It uses the current repository root by default:

```r
ROOT_DIR <- normalizePath(
  Sys.getenv("CULTURE_PROJECT_ROOT", unset = "."),
  winslash = "/",
  mustWork = TRUE
)
```

You may also set the `CULTURE_PROJECT_ROOT` environment variable if running the script from another working directory.

## Generated output directory

The final script writes a new directory called:

`FINAL_SUBMISSION_OUTPUTS/`

This directory can be deleted and regenerated. The frozen comparison outputs are stored under `outputs/final/`.
