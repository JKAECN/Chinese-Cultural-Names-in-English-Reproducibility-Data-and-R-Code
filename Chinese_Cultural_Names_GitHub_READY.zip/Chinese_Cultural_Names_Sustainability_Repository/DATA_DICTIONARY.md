# Data Dictionary

This file documents the principal research tables needed to understand and reproduce the final analysis.

## `data/04_final_analysis/FINAL_SUBMISSION_ANNUAL_DATA.csv`

| Variable | Meaning |
|---|---|
| `row_id` | Stable term identifier |
| `term` | Human-readable English term |
| `ngram_query` | Query string used for the annual Ngram series |
| `pathway_comparison_eligible` | Whether the item was eligible for pathway comparison under the original curation |
| `cultural_domain` | Fixed cultural-domain label |
| `concept_group` | Concept-level grouping used for multiple-name cases |
| `query_risk` | Query-risk category |
| `case_insensitive` | Whether the query was treated case-insensitively |
| `corpus` | Ngram corpus identifier |
| `phrase_returned` | Phrase returned by the source query |
| `type_returned` | Returned Ngram type |
| `year` | Calendar year |
| `frequency` | Annual Ngram frequency |
| `decision` | Final semantic decision inherited from the semantic audit |
| `valid_from_year` | Semantic validity boundary before the final chronological audit |
| `pathway` | Final pathway classification used in the submission analysis |
| `primary_analysis_start` | Conservative start year used in the primary analysis |
| `audited_valid_from` | Final effective lower bound for the annual series |

## `data/01_coding/Semantic_75_FINAL.csv`

| Variable | Meaning |
|---|---|
| `row_id` | Stable term identifier |
| `term` | Term under semantic audit |
| `final_decision` | Frozen final semantic decision (`keep`, `truncate`, or `exclude`) |
| `final_valid_from_year` | Frozen valid-from boundary when applicable |
| `final_note` | Adjudication note |
| `final_status` | Final audit status |

## `data/04_final_analysis/PATHWAY_FINAL_AUDIT.csv`

Contains the provisional and final pathway labels plus the adjudication basis for terms whose final classification required rule-sensitive review.

## `data/04_final_analysis/DATE_EVIDENCE_MATRIX.csv`

Separates four chronological concepts:

- `object_formation_guardrail`
- `verified_target_example_year`
- `official_standardization_year`
- `adopted_analysis_start`

The distinction is important because a verified example year does not prove that every earlier occurrence is invalid.

## `data/03_historical_spelling/historical_spelling_annual_variants.csv`

Annual series for candidate historical spelling variants used during spelling-sensitivity auditing.

## `outputs/final/`

Contains final hypothesis tests, model coefficients, fixed-window results, interaction tests, bootstrap outputs, session information, and version metadata.
