# ============================================================
# 04_Independent_Coding_Agreement.R
# Independent coding agreement for:
#   (A) Pathway / Cultural Domain coding (~187 items)
#   (B) Semantic audit coding (~75 items)
#
# Design goals:
#   1. Do NOT assume non-existent files such as
#      S1_path_audit_187.csv / Path_Domain_187_coder2.csv /
#      Semantic_75_coder2.csv.
#   2. Read Coder 2 directly from Second_Coder_Blind.xlsx.
#   3. Auto-detect likely files, sheets, IDs, and coding columns.
#   4. Never silently recode substantive category labels.
#      Only case/whitespace are normalized before comparison.
#   5. Export matched data, unmatched items, diagnostics, and a
#      publication-ready agreement summary table.
# ============================================================

# -----------------------------
# 0. USER SETTINGS
# -----------------------------
ROOT_DIR <- "E:/论文/中国文化/英语中的中文"
SUBMIT_DIR <- file.path(ROOT_DIR, "准备投稿版")
OUT_DIR <- file.path(ROOT_DIR, "independent_coding_agreement")
dir.create(OUT_DIR, recursive = TRUE, showWarnings = FALSE)

# Known files
CODER1_SEM_FILE <- file.path(SUBMIT_DIR, "S2_semantic_audit_75.csv")
CODER2_XLSX     <- file.path(SUBMIT_DIR, "Second_Coder_Blind.xlsx")

# Optional manual overrides.
# Leave as NA_character_ for automatic detection.
CODER1_PATH_FILE   <- NA_character_
CODER2_PATH_SHEET  <- NA_character_
CODER2_SEM_SHEET   <- NA_character_

# Optional column-name overrides.
# Leave as NA_character_ unless auto-detection fails.
C1_PATH_ID_COL     <- NA_character_
C1_PATHWAY_COL     <- NA_character_
C1_DOMAIN_COL      <- NA_character_

C2_PATH_ID_COL     <- NA_character_
C2_PATHWAY_COL     <- NA_character_
C2_DOMAIN_COL      <- NA_character_

C1_SEM_ID_COL      <- NA_character_
C1_SEM_COL         <- NA_character_

C2_SEM_ID_COL      <- NA_character_
C2_SEM_COL         <- NA_character_

# Expected sizes are used only for ranking candidates.
EXPECTED_PATH_N <- 187L
EXPECTED_SEM_N  <- 75L


# -----------------------------
# 1. PACKAGES
# -----------------------------
pkgs <- c("readr", "readxl", "dplyr", "tibble", "stringr", "irr")
need <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
if (length(need) > 0) {
  install.packages(need, repos = "https://cloud.r-project.org")
}

suppressPackageStartupMessages({
  library(readr)
  library(readxl)
  library(dplyr)
  library(tibble)
  library(stringr)
  library(irr)
})


# -----------------------------
# 2. HELPERS
# -----------------------------
clean_names_simple <- function(nm) {
  nm <- enc2utf8(nm)
  nm <- trimws(nm)
  nm <- tolower(nm)
  nm <- gsub("[^[:alnum:]]+", "_", nm)
  nm <- gsub("^_+|_+$", "", nm)
  make.unique(nm, sep = "_")
}

clean_df_names <- function(df) {
  names(df) <- clean_names_simple(names(df))
  df
}

norm_id <- function(x) {
  x <- as.character(x)
  x <- enc2utf8(x)
  x <- trimws(x)
  x <- gsub("\\s+", " ", x)
  tolower(x)
}

# IMPORTANT:
# Only formatting is normalized. No substantive synonym mapping.
norm_label <- function(x) {
  x <- as.character(x)
  x <- enc2utf8(x)
  x <- trimws(x)
  x <- gsub("\\s+", " ", x)
  x[x %in% c("", "na", "n/a", "NA", "N/A")] <- NA_character_
  tolower(x)
}

nonempty_n <- function(x) {
  sum(!is.na(norm_label(x)))
}

first_match <- function(nms, exact = character(), regex = character()) {
  nms_l <- tolower(nms)

  if (length(exact) > 0) {
    exact_l <- tolower(exact)
    for (z in exact_l) {
      hit <- which(nms_l == z)
      if (length(hit) > 0) return(nms[hit[1]])
    }
  }

  if (length(regex) > 0) {
    for (pat in regex) {
      hit <- which(grepl(pat, nms_l, perl = TRUE))
      if (length(hit) > 0) return(nms[hit[1]])
    }
  }

  NA_character_
}

guess_id_col <- function(df, override = NA_character_) {
  if (!is.na(override)) {
    if (!override %in% names(df)) {
      stop("Specified ID column not found: ", override,
           "\nAvailable columns: ", paste(names(df), collapse = ", "))
    }
    return(override)
  }

  first_match(
    names(df),
    exact = c(
      "term", "source_term", "source_form", "word", "item",
      "lexical_item", "expression", "term_id", "item_id", "id"
    ),
    regex = c(
      "(^|_)source(_|$).*term",
      "(^|_)term(_|$)",
      "(^|_)word(_|$)",
      "(^|_)item(_|$)",
      "(^|_)lexical"
    )
  )
}

guess_pathway_col <- function(df, override = NA_character_) {
  if (!is.na(override)) {
    if (!override %in% names(df)) stop("Specified pathway column not found: ", override)
    return(override)
  }

  first_match(
    names(df),
    exact = c(
      "pathway", "path", "borrowing_pathway", "transmission_pathway",
      "route", "route_type", "path_code", "pathway_code"
    ),
    regex = c("pathway", "transmission.*path", "borrowing.*path", "(^|_)route(_|$)")
  )
}

guess_domain_col <- function(df, override = NA_character_) {
  if (!is.na(override)) {
    if (!override %in% names(df)) stop("Specified domain column not found: ", override)
    return(override)
  }

  first_match(
    names(df),
    exact = c(
      "domain", "cultural_domain", "semantic_domain",
      "domain_code", "cultural_domain_code", "category"
    ),
    regex = c("cultural.*domain", "semantic.*domain", "(^|_)domain(_|$)")
  )
}

guess_sem_col <- function(df, override = NA_character_) {
  if (!is.na(override)) {
    if (!override %in% names(df)) stop("Specified semantic column not found: ", override)
    return(override)
  }

  # Prefer decision-like variables over free-text notes/comments.
  first_match(
    names(df),
    exact = c(
      "semantic_decision", "decision", "semantic_judgment",
      "semantic_judgement", "semantic_match", "semantic_code",
      "audit_decision", "include", "retain", "keep"
    ),
    regex = c(
      "semantic.*decision",
      "semantic.*judg",
      "audit.*decision",
      "(^|_)decision(_|$)",
      "semantic.*match",
      "semantic.*code"
    )
  )
}

read_csv_safe <- function(path) {
  x <- suppressMessages(readr::read_csv(
    path,
    show_col_types = FALSE,
    progress = FALSE,
    name_repair = "minimal"
  ))
  clean_df_names(x)
}

read_sheet_safe <- function(path, sheet) {
  x <- suppressMessages(readxl::read_excel(
    path,
    sheet = sheet,
    .name_repair = "minimal"
  ))
  clean_df_names(x)
}

sheet_summary <- function(path) {
  sh <- readxl::excel_sheets(path)
  out <- vector("list", length(sh))

  for (i in seq_along(sh)) {
    x <- tryCatch(read_sheet_safe(path, sh[i]), error = function(e) NULL)

    if (is.null(x)) {
      out[[i]] <- tibble(
        sheet = sh[i], n = NA_integer_, p = NA_integer_,
        id_col = NA_character_, pathway_col = NA_character_,
        domain_col = NA_character_, sem_col = NA_character_
      )
    } else {
      out[[i]] <- tibble(
        sheet = sh[i],
        n = nrow(x),
        p = ncol(x),
        id_col = guess_id_col(x),
        pathway_col = guess_pathway_col(x),
        domain_col = guess_domain_col(x),
        sem_col = guess_sem_col(x)
      )
    }
  }

  bind_rows(out)
}

score_sheet_path <- function(summary_df) {
  summary_df %>%
    mutate(
      score =
        ifelse(grepl("path|domain|coding|coder", sheet, ignore.case = TRUE), 4, 0) +
        ifelse(!is.na(n) & abs(n - EXPECTED_PATH_N) <= 3, 5, 0) +
        ifelse(!is.na(pathway_col), 4, 0) +
        ifelse(!is.na(domain_col), 4, 0) +
        ifelse(!is.na(id_col), 2, 0)
    ) %>%
    arrange(desc(score), abs(n - EXPECTED_PATH_N))
}

score_sheet_sem <- function(summary_df) {
  summary_df %>%
    mutate(
      score =
        ifelse(grepl("sem|meaning|audit|75", sheet, ignore.case = TRUE), 4, 0) +
        ifelse(!is.na(n) & abs(n - EXPECTED_SEM_N) <= 3, 5, 0) +
        ifelse(!is.na(sem_col), 6, 0) +
        ifelse(!is.na(id_col), 2, 0)
    ) %>%
    arrange(desc(score), abs(n - EXPECTED_SEM_N))
}

# Search all CSV files for a plausible Coder-1 Path/Domain source.
find_coder1_path_file <- function(root) {
  files <- list.files(
    root,
    pattern = "\\.csv$",
    recursive = TRUE,
    full.names = TRUE,
    ignore.case = TRUE
  )

  if (length(files) == 0) stop("No CSV files found under ROOT_DIR.")

  # Strongly prefer human/manual coding files, but still inspect all.
  res <- vector("list", length(files))

  for (i in seq_along(files)) {
    f <- files[i]

    x <- tryCatch(read_csv_safe(f), error = function(e) NULL)

    if (is.null(x)) {
      res[[i]] <- tibble(
        file = f, n = NA_integer_, id_col = NA_character_,
        pathway_col = NA_character_, domain_col = NA_character_,
        pathway_nonempty = 0L, domain_nonempty = 0L, score = -999
      )
      next
    }

    idc <- guess_id_col(x)
    pc  <- guess_pathway_col(x)
    dc  <- guess_domain_col(x)

    pn <- if (!is.na(pc)) nonempty_n(x[[pc]]) else 0L
    dn <- if (!is.na(dc)) nonempty_n(x[[dc]]) else 0L

    bn <- basename(f)

    score <-
      ifelse(abs(nrow(x) - EXPECTED_PATH_N) <= 3, 8, 0) +
      ifelse(!is.na(idc), 2, 0) +
      ifelse(!is.na(pc), 4, 0) +
      ifelse(!is.na(dc), 4, 0) +
      ifelse(pn > 0, 5, 0) +
      ifelse(dn > 0, 5, 0) +
      ifelse(grepl("manual|coding|audit|path", bn, ignore.case = TRUE), 3, 0) -
      ifelse(grepl(
        "table|figure|rq[0-9]|prediction|download|historical|before_after|cell_counts",
        bn, ignore.case = TRUE
      ), 4, 0)

    res[[i]] <- tibble(
      file = f,
      n = nrow(x),
      id_col = idc,
      pathway_col = pc,
      domain_col = dc,
      pathway_nonempty = pn,
      domain_nonempty = dn,
      score = score
    )
  }

  ans <- bind_rows(res) %>%
    arrange(desc(score), abs(n - EXPECTED_PATH_N))

  readr::write_csv(
    ans,
    file.path(OUT_DIR, "diagnostic_coder1_path_file_candidates.csv")
  )

  ans
}

make_pairs <- function(c1, c2,
                       id1, id2,
                       rating1, rating2,
                       label) {

  if (any(is.na(c(id1, id2, rating1, rating2)))) {
    stop(label, ": required column could not be identified.")
  }

  a <- c1 %>%
    transmute(
      id_raw_coder1 = as.character(.data[[id1]]),
      id_key = norm_id(.data[[id1]]),
      coder1_raw = as.character(.data[[rating1]]),
      coder1 = norm_label(.data[[rating1]])
    ) %>%
    filter(!is.na(id_key), id_key != "")

  b <- c2 %>%
    transmute(
      id_raw_coder2 = as.character(.data[[id2]]),
      id_key = norm_id(.data[[id2]]),
      coder2_raw = as.character(.data[[rating2]]),
      coder2 = norm_label(.data[[rating2]])
    ) %>%
    filter(!is.na(id_key), id_key != "")

  dup1 <- a %>% count(id_key) %>% filter(n > 1)
  dup2 <- b %>% count(id_key) %>% filter(n > 1)

  if (nrow(dup1) > 0) {
    write_csv(dup1, file.path(OUT_DIR, paste0("duplicate_ids_coder1_", label, ".csv")))
    stop(label, ": duplicate IDs found in Coder 1. See output diagnostic file.")
  }
  if (nrow(dup2) > 0) {
    write_csv(dup2, file.path(OUT_DIR, paste0("duplicate_ids_coder2_", label, ".csv")))
    stop(label, ": duplicate IDs found in Coder 2. See output diagnostic file.")
  }

  matched <- inner_join(a, b, by = "id_key")

  unmatched1 <- anti_join(a, b, by = "id_key")
  unmatched2 <- anti_join(b, a, by = "id_key")

  write_csv(
    unmatched1,
    file.path(OUT_DIR, paste0("unmatched_coder1_", label, ".csv"))
  )
  write_csv(
    unmatched2,
    file.path(OUT_DIR, paste0("unmatched_coder2_", label, ".csv"))
  )

  matched
}

compute_agreement <- function(pairs, dimension) {
  complete <- pairs %>%
    filter(!is.na(coder1), !is.na(coder2))

  if (nrow(complete) == 0) {
    return(tibble(
      dimension = dimension,
      n_matched_ids = nrow(pairs),
      n_complete_pairs = 0L,
      raw_agreement = NA_real_,
      kappa = NA_real_,
      statistic = NA_real_,
      p_value = NA_real_,
      coder1_levels = NA_character_,
      coder2_levels = NA_character_
    ))
  }

  raw_ag <- mean(complete$coder1 == complete$coder2)

  lev1 <- sort(unique(complete$coder1))
  lev2 <- sort(unique(complete$coder2))
  all_levels <- sort(unique(c(lev1, lev2)))

  # Kappa requires at least two observed categories overall.
  if (length(all_levels) < 2) {
    kap <- NA_real_
    stat <- NA_real_
    pval <- NA_real_
  } else {
    kdat <- data.frame(
      coder1 = factor(complete$coder1, levels = all_levels),
      coder2 = factor(complete$coder2, levels = all_levels)
    )

    kfit <- irr::kappa2(kdat, weight = "unweighted")

    kap  <- unname(kfit$value)
    stat <- if (!is.null(kfit$statistic)) unname(kfit$statistic) else NA_real_
    pval <- if (!is.null(kfit$p.value)) unname(kfit$p.value) else NA_real_
  }

  tibble(
    dimension = dimension,
    n_matched_ids = nrow(pairs),
    n_complete_pairs = nrow(complete),
    raw_agreement = raw_ag,
    kappa = kap,
    statistic = stat,
    p_value = pval,
    coder1_levels = paste(lev1, collapse = " | "),
    coder2_levels = paste(lev2, collapse = " | ")
  )
}

confusion_long <- function(pairs, dimension) {
  x <- pairs %>%
    filter(!is.na(coder1), !is.na(coder2))

  if (nrow(x) == 0) return(tibble())

  as.data.frame(table(x$coder1, x$coder2), stringsAsFactors = FALSE) %>%
    as_tibble() %>%
    rename(coder1 = Var1, coder2 = Var2, n = Freq) %>%
    mutate(dimension = dimension, .before = 1)
}


# -----------------------------
# 3. BASIC FILE CHECKS
# -----------------------------
if (!dir.exists(ROOT_DIR)) {
  stop("ROOT_DIR does not exist: ", ROOT_DIR)
}
if (!file.exists(CODER1_SEM_FILE)) {
  stop("Coder 1 semantic file not found: ", CODER1_SEM_FILE)
}
if (!file.exists(CODER2_XLSX)) {
  stop("Coder 2 workbook not found: ", CODER2_XLSX)
}

cat("\n============================================================\n")
cat("Independent Coding Agreement\n")
cat("============================================================\n")
cat("ROOT_DIR: ", ROOT_DIR, "\n", sep = "")
cat("Coder 1 semantic: ", CODER1_SEM_FILE, "\n", sep = "")
cat("Coder 2 workbook: ", CODER2_XLSX, "\n", sep = "")


# -----------------------------
# 4. FIND CODER 1 PATH/DOMAIN DATA
# -----------------------------
if (!is.na(CODER1_PATH_FILE)) {

  if (!file.exists(CODER1_PATH_FILE)) {
    stop("Manual CODER1_PATH_FILE does not exist: ", CODER1_PATH_FILE)
  }

  coder1_path_file <- CODER1_PATH_FILE

} else {

  cands <- find_coder1_path_file(ROOT_DIR)

  usable <- cands %>%
    filter(
      !is.na(id_col),
      !is.na(pathway_col) | !is.na(domain_col),
      pathway_nonempty > 0 | domain_nonempty > 0
    )

  if (nrow(usable) == 0) {
    cat("\nNo usable Coder 1 Path/Domain file was detected.\n")
    cat("See:\n")
    cat(file.path(OUT_DIR, "diagnostic_coder1_path_file_candidates.csv"), "\n")
    stop(
      "Cannot continue Path/Domain agreement until a Coder 1 file ",
      "with item IDs and completed Pathway/Domain coding is available."
    )
  }

  coder1_path_file <- usable$file[1]
}

cat("\nSelected Coder 1 Path/Domain file:\n", coder1_path_file, "\n", sep = "")

c1_path <- read_csv_safe(coder1_path_file)


# -----------------------------
# 5. INSPECT / SELECT CODER 2 SHEETS
# -----------------------------
sh_summary <- sheet_summary(CODER2_XLSX)
write_csv(
  sh_summary,
  file.path(OUT_DIR, "diagnostic_second_coder_sheet_summary.csv")
)

cat("\nCoder 2 workbook sheets:\n")
print(sh_summary)

# ---- Path/Domain sheet
if (!is.na(CODER2_PATH_SHEET)) {

  if (!CODER2_PATH_SHEET %in% sh_summary$sheet) {
    stop("Specified CODER2_PATH_SHEET not found: ", CODER2_PATH_SHEET)
  }

  path_sheet <- CODER2_PATH_SHEET

} else {

  ranked_path <- score_sheet_path(sh_summary)
  write_csv(
    ranked_path,
    file.path(OUT_DIR, "diagnostic_second_coder_path_sheet_ranking.csv")
  )

  if (nrow(ranked_path) == 0 || ranked_path$score[1] <= 0) {
    stop("Could not identify a Path/Domain sheet in Second_Coder_Blind.xlsx.")
  }

  path_sheet <- ranked_path$sheet[1]
}

# ---- Semantic sheet
if (!is.na(CODER2_SEM_SHEET)) {

  if (!CODER2_SEM_SHEET %in% sh_summary$sheet) {
    stop("Specified CODER2_SEM_SHEET not found: ", CODER2_SEM_SHEET)
  }

  sem_sheet <- CODER2_SEM_SHEET

} else {

  ranked_sem <- score_sheet_sem(sh_summary)
  write_csv(
    ranked_sem,
    file.path(OUT_DIR, "diagnostic_second_coder_sem_sheet_ranking.csv")
  )

  if (nrow(ranked_sem) == 0 || ranked_sem$score[1] <= 0) {
    stop("Could not identify a Semantic sheet in Second_Coder_Blind.xlsx.")
  }

  sem_sheet <- ranked_sem$sheet[1]
}

cat("\nSelected Coder 2 Path/Domain sheet: ", path_sheet, "\n", sep = "")
cat("Selected Coder 2 Semantic sheet: ", sem_sheet, "\n", sep = "")

c2_path <- read_sheet_safe(CODER2_XLSX, path_sheet)
c2_sem  <- read_sheet_safe(CODER2_XLSX, sem_sheet)
c1_sem  <- read_csv_safe(CODER1_SEM_FILE)


# -----------------------------
# 6. IDENTIFY COLUMNS
# -----------------------------
c1_path_id <- guess_id_col(c1_path, C1_PATH_ID_COL)
c1_pathway <- guess_pathway_col(c1_path, C1_PATHWAY_COL)
c1_domain  <- guess_domain_col(c1_path, C1_DOMAIN_COL)

c2_path_id <- guess_id_col(c2_path, C2_PATH_ID_COL)
c2_pathway <- guess_pathway_col(c2_path, C2_PATHWAY_COL)
c2_domain  <- guess_domain_col(c2_path, C2_DOMAIN_COL)

c1_sem_id  <- guess_id_col(c1_sem, C1_SEM_ID_COL)
c1_sem_col <- guess_sem_col(c1_sem, C1_SEM_COL)

c2_sem_id  <- guess_id_col(c2_sem, C2_SEM_ID_COL)
c2_sem_col <- guess_sem_col(c2_sem, C2_SEM_COL)

colmap <- tibble(
  dataset = c(
    "Coder1_PathDomain", "Coder1_PathDomain", "Coder1_PathDomain",
    "Coder2_PathDomain", "Coder2_PathDomain", "Coder2_PathDomain",
    "Coder1_Semantic", "Coder1_Semantic",
    "Coder2_Semantic", "Coder2_Semantic"
  ),
  role = c(
    "ID", "Pathway", "Domain",
    "ID", "Pathway", "Domain",
    "ID", "Semantic",
    "ID", "Semantic"
  ),
  detected_column = c(
    c1_path_id, c1_pathway, c1_domain,
    c2_path_id, c2_pathway, c2_domain,
    c1_sem_id, c1_sem_col,
    c2_sem_id, c2_sem_col
  )
)

write_csv(
  colmap,
  file.path(OUT_DIR, "diagnostic_detected_columns.csv")
)

cat("\nDetected columns:\n")
print(colmap)

# Essential checks
if (is.na(c1_path_id) || is.na(c2_path_id)) {
  stop(
    "Path/Domain ID column could not be identified.\n",
    "See diagnostic_detected_columns.csv and set C1_PATH_ID_COL / C2_PATH_ID_COL."
  )
}

if (is.na(c1_sem_id) || is.na(c2_sem_id)) {
  stop(
    "Semantic ID column could not be identified.\n",
    "See diagnostic_detected_columns.csv and set C1_SEM_ID_COL / C2_SEM_ID_COL."
  )
}

if (is.na(c1_pathway) && is.na(c1_domain)) {
  stop("Coder 1 Path/Domain source contains neither a detectable Pathway nor Domain column.")
}

if (is.na(c2_pathway) && is.na(c2_domain)) {
  stop("Coder 2 Path/Domain sheet contains neither a detectable Pathway nor Domain column.")
}

if (is.na(c1_sem_col) || is.na(c2_sem_col)) {
  stop(
    "Semantic decision column could not be identified.\n",
    "See diagnostic_detected_columns.csv and set C1_SEM_COL / C2_SEM_COL."
  )
}


# -----------------------------
# 7. PATHWAY AGREEMENT
# -----------------------------
results <- list()
confusions <- list()

if (!is.na(c1_pathway) && !is.na(c2_pathway)) {

  path_pairs <- make_pairs(
    c1 = c1_path,
    c2 = c2_path,
    id1 = c1_path_id,
    id2 = c2_path_id,
    rating1 = c1_pathway,
    rating2 = c2_pathway,
    label = "pathway"
  )

  write_csv(
    path_pairs,
    file.path(OUT_DIR, "matched_pathway_pairs.csv")
  )

  results[["Pathway"]] <- compute_agreement(path_pairs, "Pathway")
  confusions[["Pathway"]] <- confusion_long(path_pairs, "Pathway")

} else {
  warning("Pathway agreement skipped because a Pathway column was not found for both coders.")
}


# -----------------------------
# 8. DOMAIN AGREEMENT
# -----------------------------
if (!is.na(c1_domain) && !is.na(c2_domain)) {

  domain_pairs <- make_pairs(
    c1 = c1_path,
    c2 = c2_path,
    id1 = c1_path_id,
    id2 = c2_path_id,
    rating1 = c1_domain,
    rating2 = c2_domain,
    label = "domain"
  )

  write_csv(
    domain_pairs,
    file.path(OUT_DIR, "matched_domain_pairs.csv")
  )

  results[["Cultural Domain"]] <- compute_agreement(
    domain_pairs,
    "Cultural Domain"
  )

  confusions[["Cultural Domain"]] <- confusion_long(
    domain_pairs,
    "Cultural Domain"
  )

} else {
  warning("Domain agreement skipped because a Domain column was not found for both coders.")
}


# -----------------------------
# 9. SEMANTIC AGREEMENT
# -----------------------------
sem_pairs <- make_pairs(
  c1 = c1_sem,
  c2 = c2_sem,
  id1 = c1_sem_id,
  id2 = c2_sem_id,
  rating1 = c1_sem_col,
  rating2 = c2_sem_col,
  label = "semantic"
)

write_csv(
  sem_pairs,
  file.path(OUT_DIR, "matched_semantic_pairs.csv")
)

results[["Semantic decision"]] <- compute_agreement(
  sem_pairs,
  "Semantic decision"
)

confusions[["Semantic decision"]] <- confusion_long(
  sem_pairs,
  "Semantic decision"
)


# -----------------------------
# 10. EXPORT SUMMARY
# -----------------------------
agreement_table <- bind_rows(results) %>%
  mutate(
    raw_agreement_percent = 100 * raw_agreement
  ) %>%
  select(
    dimension,
    n_matched_ids,
    n_complete_pairs,
    raw_agreement,
    raw_agreement_percent,
    kappa,
    statistic,
    p_value,
    coder1_levels,
    coder2_levels
  )

write_csv(
  agreement_table,
  file.path(OUT_DIR, "Table_Independent_Coding_Agreement.csv")
)

confusion_table <- bind_rows(confusions)
write_csv(
  confusion_table,
  file.path(OUT_DIR, "Independent_Coding_Confusion_Matrices_Long.csv")
)


# -----------------------------
# 11. HUMAN-READABLE REPORT
# -----------------------------
summary_file <- file.path(
  OUT_DIR,
  "Independent_Coding_Agreement_Summary.txt"
)

con <- file(summary_file, open = "wt", encoding = "UTF-8")

writeLines("INDEPENDENT CODING AGREEMENT", con)
writeLines("============================", con)
writeLines("", con)

writeLines(paste0("Coder 1 Path/Domain source: ", coder1_path_file), con)
writeLines(paste0("Coder 1 Semantic source: ", CODER1_SEM_FILE), con)
writeLines(paste0("Coder 2 workbook: ", CODER2_XLSX), con)
writeLines(paste0("Coder 2 Path/Domain sheet: ", path_sheet), con)
writeLines(paste0("Coder 2 Semantic sheet: ", sem_sheet), con)
writeLines("", con)

for (i in seq_len(nrow(agreement_table))) {
  z <- agreement_table[i, ]

  writeLines(paste0("[", z$dimension, "]"), con)
  writeLines(paste0("Matched IDs: ", z$n_matched_ids), con)
  writeLines(paste0("Complete rating pairs: ", z$n_complete_pairs), con)

  if (!is.na(z$raw_agreement_percent)) {
    writeLines(
      paste0("Raw agreement: ", sprintf("%.1f%%", z$raw_agreement_percent)),
      con
    )
  } else {
    writeLines("Raw agreement: NA", con)
  }

  if (!is.na(z$kappa)) {
    writeLines(
      paste0("Cohen's kappa: ", sprintf("%.3f", z$kappa)),
      con
    )
  } else {
    writeLines("Cohen's kappa: NA", con)
  }

  if (!is.na(z$p_value)) {
    writeLines(
      paste0("p-value: ", format.pval(z$p_value, digits = 3, eps = 0.001)),
      con
    )
  }

  writeLines(paste0("Coder 1 categories: ", z$coder1_levels), con)
  writeLines(paste0("Coder 2 categories: ", z$coder2_levels), con)
  writeLines("", con)
}

writeLines(
  paste0(
    "NOTE: Category labels were normalized only for letter case and ",
    "whitespace. No substantive category synonyms were silently merged."
  ),
  con
)

writeLines(
  paste0(
    "Check unmatched_* files and the confusion-matrix output before ",
    "reporting the final coefficients in the manuscript."
  ),
  con
)

close(con)


# -----------------------------
# 12. CONSOLE OUTPUT
# -----------------------------
cat("\n============================================================\n")
cat("FINAL AGREEMENT TABLE\n")
cat("============================================================\n")
print(
  agreement_table %>%
    mutate(
      raw_agreement = round(raw_agreement, 3),
      raw_agreement_percent = round(raw_agreement_percent, 1),
      kappa = round(kappa, 3),
      statistic = round(statistic, 3)
    )
)

cat("\nOutputs written to:\n", OUT_DIR, "\n", sep = "")
cat("\nMain files:\n")
cat("  - Table_Independent_Coding_Agreement.csv\n")
cat("  - Independent_Coding_Agreement_Summary.txt\n")
cat("  - Independent_Coding_Confusion_Matrices_Long.csv\n")
cat("  - matched_pathway_pairs.csv (if available)\n")
cat("  - matched_domain_pairs.csv (if available)\n")
cat("  - matched_semantic_pairs.csv\n")
cat("  - diagnostic_*.csv\n")
cat("  - unmatched_*.csv\n")
cat("\nDONE.\n")
