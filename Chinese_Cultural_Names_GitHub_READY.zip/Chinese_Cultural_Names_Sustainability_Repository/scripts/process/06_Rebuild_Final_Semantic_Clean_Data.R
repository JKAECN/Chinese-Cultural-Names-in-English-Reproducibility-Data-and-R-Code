# ============================================================
# 06_Rebuild_Final_Semantic_Clean_Data.R
#
# PURPOSE
#   Rebuild the FINAL annual Ngram dataset after Round-2 semantic
#   reliability + adjudication have been frozen.
#
# FINAL SEMANTIC RULES
#   keep     -> retain the complete pre-semantic annual series
#   truncate -> retain only years >= final_valid_from_year
#   exclude  -> remove the term entirely
#
# SAFETY PRINCIPLE
#   This script WILL NOT rebuild from the old semantic-cleaned file
#   if that file cannot restore years removed by earlier truncation.
#   It searches for a true pre-semantic annual source and stops if
#   the required historical coverage cannot be verified.
#
# EXPECTED STUDY WINDOW
#   1800-2022
# ============================================================


# ------------------------------------------------------------
# 0. USER SETTINGS
# ------------------------------------------------------------
ROOT_DIR <- "E:/论文/中国文化/英语中的中文"

OUT_DIR <- file.path(ROOT_DIR, "semantic_final")
dir.create(OUT_DIR, recursive = TRUE, showWarnings = FALSE)

STUDY_START_YEAR <- 1800L
STUDY_END_YEAR   <- 2022L

# Optional manual overrides.
# Leave as NA_character_ for automatic discovery.
FINAL_DECISION_FILE_OVERRIDE <- NA_character_
SOURCE_ANNUAL_FILE_OVERRIDE  <- NA_character_
OLD_CLEAN_FILE_OVERRIDE      <- NA_character_


# ------------------------------------------------------------
# 1. PACKAGES
# ------------------------------------------------------------
pkgs <- c("readr", "dplyr", "stringr", "tibble", "purrr")
need <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]

if (length(need) > 0) {
  install.packages(need, repos = "https://cloud.r-project.org")
}

suppressPackageStartupMessages({
  library(readr)
  library(dplyr)
  library(stringr)
  library(tibble)
  library(purrr)
})


# ------------------------------------------------------------
# 2. HELPERS
# ------------------------------------------------------------
norm_text <- function(x) {
  x <- as.character(x)
  x <- enc2utf8(x)
  x <- str_trim(x)
  x <- str_squish(x)
  tolower(x)
}

find_latest_matching_file <- function(root, regex, exclude_regex = NULL) {

  hits <- list.files(
    root,
    pattern = "\\.csv$",
    recursive = TRUE,
    full.names = TRUE,
    ignore.case = TRUE
  )

  hits <- hits[grepl(regex, basename(hits), ignore.case = TRUE)]

  if (!is.null(exclude_regex)) {
    hits <- hits[!grepl(exclude_regex, basename(hits), ignore.case = TRUE)]
  }

  if (length(hits) == 0) return(NA_character_)

  info <- file.info(hits)
  hits[order(info$mtime, decreasing = TRUE)][1]
}

pick_name <- function(nms, candidates) {
  nms_low <- tolower(nms)
  for (cand in candidates) {
    hit <- which(nms_low == tolower(cand))
    if (length(hit) > 0) return(nms[hit[1]])
  }
  NA_character_
}

safe_header <- function(path) {
  tryCatch(
    names(
      suppressMessages(
        readr::read_csv(
          path,
          n_max = 0,
          show_col_types = FALSE,
          progress = FALSE,
          name_repair = "minimal"
        )
      )
    ),
    error = function(e) character(0)
  )
}

standardize_three_cols <- function(x, row_col, term_col, year_col) {
  x %>%
    transmute(
      row_id_key = as.character(.data[[row_col]]),
      term_source = as.character(.data[[term_col]]),
      year_num = suppressWarnings(as.integer(.data[[year_col]]))
    ) %>%
    filter(
      !is.na(row_id_key), row_id_key != "",
      !is.na(year_num)
    )
}

write_txt <- function(lines, path) {
  con <- file(path, open = "wt", encoding = "UTF-8")
  on.exit(close(con), add = TRUE)
  writeLines(lines, con = con, useBytes = TRUE)
}


# ------------------------------------------------------------
# 3. LOCATE AND READ FROZEN FINAL SEMANTIC DECISIONS
# ------------------------------------------------------------
if (!is.na(FINAL_DECISION_FILE_OVERRIDE)) {

  FINAL_FILE <- FINAL_DECISION_FILE_OVERRIDE

} else {

  FINAL_FILE <- find_latest_matching_file(
    ROOT_DIR,
    "^Semantic_75_FINAL.*\\.csv$"
  )
}

if (is.na(FINAL_FILE) || !file.exists(FINAL_FILE)) {
  stop(
    "Cannot find Semantic_75_FINAL.csv.\n",
    "Please copy the frozen final adjudication CSV into ROOT_DIR ",
    "or one of its subfolders, or set FINAL_DECISION_FILE_OVERRIDE."
  )
}

cat("\n============================================================\n")
cat("FINAL SEMANTIC DECISION FILE\n")
cat("============================================================\n")
cat(FINAL_FILE, "\n")

final_sem <- suppressMessages(
  read_csv(
    FINAL_FILE,
    show_col_types = FALSE,
    progress = FALSE
  )
)

required_final_cols <- c(
  "row_id",
  "term",
  "final_decision",
  "final_valid_from_year"
)

missing_final_cols <- setdiff(required_final_cols, names(final_sem))

if (length(missing_final_cols) > 0) {
  stop(
    "Semantic_75_FINAL is missing required columns: ",
    paste(missing_final_cols, collapse = ", ")
  )
}

final_sem <- final_sem %>%
  mutate(
    row_id_key = as.character(row_id),
    term = as.character(term),
    final_decision = norm_text(final_decision),
    final_valid_from_year =
      suppressWarnings(as.integer(final_valid_from_year))
  )

if (nrow(final_sem) != 75L) {
  stop(
    "Expected 75 frozen semantic decisions, but found ",
    nrow(final_sem), "."
  )
}

if (anyDuplicated(final_sem$row_id_key) > 0) {
  stop("Duplicate row_id values found in Semantic_75_FINAL.")
}

allowed_decisions <- c("keep", "truncate", "exclude")
bad_decisions <- setdiff(
  unique(final_sem$final_decision),
  allowed_decisions
)

if (length(bad_decisions) > 0) {
  stop(
    "Unexpected final_decision values: ",
    paste(bad_decisions, collapse = ", ")
  )
}

bad_truncate <- final_sem %>%
  filter(
    final_decision == "truncate",
    is.na(final_valid_from_year) |
      final_valid_from_year < STUDY_START_YEAR |
      final_valid_from_year > STUDY_END_YEAR
  )

if (nrow(bad_truncate) > 0) {
  write_csv(
    bad_truncate,
    file.path(OUT_DIR, "ERROR_invalid_truncate_years.csv")
  )
  stop(
    "Some truncate items have invalid final_valid_from_year. ",
    "See ERROR_invalid_truncate_years.csv."
  )
}

decision_counts <- final_sem %>% count(final_decision)

cat("\nFrozen semantic decisions:\n")
print(decision_counts)


# ------------------------------------------------------------
# 4. DEFINE REQUIRED HISTORICAL COVERAGE
# ------------------------------------------------------------
# For KEEP, the source must restore the complete study window.
# For TRUNCATE, the source must reach at least the final cutoff year.
# EXCLUDE items do not need to survive into the final dataset.

coverage_req <- final_sem %>%
  mutate(
    required_start_year = case_when(
      final_decision == "keep" ~ STUDY_START_YEAR,
      final_decision == "truncate" ~ final_valid_from_year,
      TRUE ~ NA_integer_
    ),
    required_in_final = final_decision != "exclude"
  ) %>%
  select(
    row_id_key,
    row_id,
    term,
    final_decision,
    final_valid_from_year,
    required_start_year,
    required_in_final
  )


# ------------------------------------------------------------
# 5. SEARCH FOR A TRUE PRE-SEMANTIC ANNUAL SOURCE
# ------------------------------------------------------------
all_csv <- list.files(
  ROOT_DIR,
  pattern = "\\.csv$",
  recursive = TRUE,
  full.names = TRUE,
  ignore.case = TRUE
)

# Never consider files produced by this script.
all_csv <- all_csv[
  !startsWith(
    normalizePath(all_csv, winslash = "/", mustWork = FALSE),
    normalizePath(OUT_DIR, winslash = "/", mustWork = FALSE)
  )
]

# Never use the frozen decision file itself as annual data.
all_csv <- all_csv[
  normalizePath(all_csv, winslash = "/", mustWork = FALSE) !=
    normalizePath(FINAL_FILE, winslash = "/", mustWork = FALSE)
]

cat("\nScanning CSV files for annual-data candidates...\n")

inspect_candidate <- function(path) {

  hdr <- safe_header(path)

  row_col <- pick_name(
    hdr,
    c("row_id", "term_id", "id")
  )

  term_col <- pick_name(
    hdr,
    c("term", "source_term", "lexical_item")
  )

  year_col <- pick_name(
    hdr,
    c("year")
  )

  freq_col <- pick_name(
    hdr,
    c("frequency", "freq", "relative_frequency")
  )

  basic_ok <- all(!is.na(c(row_col, term_col, year_col, freq_col)))

  if (!basic_ok) {
    return(
      tibble(
        file = path,
        basename = basename(path),
        has_required_columns = FALSE,
        n_rows_checked = NA_integer_,
        n_required_ids_present = NA_integer_,
        n_required_ids_total = sum(coverage_req$required_in_final),
        n_start_year_ok = NA_integer_,
        n_start_year_required = sum(coverage_req$required_in_final),
        source_min_year = NA_integer_,
        source_max_year = NA_integer_,
        audit_duplicate_row_years = NA_integer_,
        suspicious_name = NA,
        usable_presemantic_source = FALSE,
        score = -Inf
      )
    )
  }

  x <- tryCatch(
    suppressMessages(
      read_csv(
        path,
        col_select = all_of(unique(c(row_col, term_col, year_col))),
        show_col_types = FALSE,
        progress = FALSE,
        name_repair = "minimal"
      )
    ),
    error = function(e) NULL
  )

  if (is.null(x)) {
    return(
      tibble(
        file = path,
        basename = basename(path),
        has_required_columns = TRUE,
        n_rows_checked = NA_integer_,
        n_required_ids_present = NA_integer_,
        n_required_ids_total = sum(coverage_req$required_in_final),
        n_start_year_ok = NA_integer_,
        n_start_year_required = sum(coverage_req$required_in_final),
        source_min_year = NA_integer_,
        source_max_year = NA_integer_,
        audit_duplicate_row_years = NA_integer_,
        suspicious_name = NA,
        usable_presemantic_source = FALSE,
        score = -Inf
      )
    )
  }

  z <- standardize_three_cols(
    x,
    row_col = row_col,
    term_col = term_col,
    year_col = year_col
  )

  audit_z <- z %>%
    semi_join(
      coverage_req %>% filter(required_in_final),
      by = "row_id_key"
    )

  starts <- audit_z %>%
    group_by(row_id_key) %>%
    summarise(
      source_item_min_year = min(year_num, na.rm = TRUE),
      .groups = "drop"
    ) %>%
    right_join(
      coverage_req %>%
        filter(required_in_final) %>%
        select(row_id_key, required_start_year),
      by = "row_id_key"
    ) %>%
    mutate(
      start_ok =
        !is.na(source_item_min_year) &
        source_item_min_year <= required_start_year
    )

  dup_n <- audit_z %>%
    count(row_id_key, year_num) %>%
    filter(n > 1) %>%
    nrow()

  suspicious <- grepl(
    paste(
      c(
        "semantic_clean",
        "semantic-clean",
        "semantic_final",
        "round2",
        "adjudication",
        "historical_spelling",
        "independent_coding"
      ),
      collapse = "|"
    ),
    path,
    ignore.case = TRUE
  )

  n_present <- sum(!is.na(starts$source_item_min_year))
  n_start_ok <- sum(starts$start_ok, na.rm = TRUE)
  n_required <- nrow(starts)

  src_min <- suppressWarnings(min(z$year_num, na.rm = TRUE))
  src_max <- suppressWarnings(max(z$year_num, na.rm = TRUE))

  if (!is.finite(src_min)) src_min <- NA_integer_
  if (!is.finite(src_max)) src_max <- NA_integer_

  full_span <-
    !is.na(src_min) && !is.na(src_max) &&
    src_min <= STUDY_START_YEAR &&
    src_max >= STUDY_END_YEAR

  usable <-
    n_present == n_required &&
    n_start_ok == n_required &&
    full_span &&
    dup_n == 0

  score <-
    100 * n_present +
    200 * n_start_ok +
    ifelse(full_span, 5000, 0) -
    50 * dup_n -
    ifelse(suspicious, 10000, 0)

  tibble(
    file = path,
    basename = basename(path),
    has_required_columns = TRUE,
    n_rows_checked = nrow(z),
    n_required_ids_present = n_present,
    n_required_ids_total = n_required,
    n_start_year_ok = n_start_ok,
    n_start_year_required = n_required,
    source_min_year = src_min,
    source_max_year = src_max,
    audit_duplicate_row_years = dup_n,
    suspicious_name = suspicious,
    usable_presemantic_source = usable,
    score = score
  )
}

if (!is.na(SOURCE_ANNUAL_FILE_OVERRIDE)) {

  if (!file.exists(SOURCE_ANNUAL_FILE_OVERRIDE)) {
    stop(
      "SOURCE_ANNUAL_FILE_OVERRIDE does not exist:\n",
      SOURCE_ANNUAL_FILE_OVERRIDE
    )
  }

  candidate_paths <- SOURCE_ANNUAL_FILE_OVERRIDE

} else {

  candidate_paths <- all_csv
}

candidate_diag <- map_dfr(
  candidate_paths,
  inspect_candidate
) %>%
  arrange(
    desc(usable_presemantic_source),
    desc(score)
  )

write_csv(
  candidate_diag,
  file.path(
    OUT_DIR,
    "Semantic_Final_Source_Candidate_Diagnostics.csv"
  )
)

cat("\nTop annual-data candidates:\n")
print(head(candidate_diag, 15))


# ------------------------------------------------------------
# 6. SELECT SOURCE OR STOP SAFELY
# ------------------------------------------------------------
usable_sources <- candidate_diag %>%
  filter(usable_presemantic_source)

if (nrow(usable_sources) == 0) {

  stop(
    paste0(
      "\nNo safe pre-semantic annual source was verified.\n",
      "Nothing has been rebuilt.\n\n",
      "Open:\n",
      file.path(
        OUT_DIR,
        "Semantic_Final_Source_Candidate_Diagnostics.csv"
      ),
      "\n\n",
      "A valid source must contain row_id, term, year, frequency; ",
      "cover 1800-2022; contain every retained semantic-audit item; ",
      "restore every required early year; and have no duplicate ",
      "row_id-year combinations for the audited terms."
    )
  )
}

SOURCE_FILE <- usable_sources$file[1]

cat("\n============================================================\n")
cat("SELECTED PRE-SEMANTIC ANNUAL SOURCE\n")
cat("============================================================\n")
cat(SOURCE_FILE, "\n")


# ------------------------------------------------------------
# 7. READ FULL SOURCE
# ------------------------------------------------------------
src <- suppressMessages(
  read_csv(
    SOURCE_FILE,
    show_col_types = FALSE,
    progress = FALSE,
    name_repair = "minimal"
  )
)

src_names <- names(src)

ROW_COL <- pick_name(src_names, c("row_id", "term_id", "id"))
TERM_COL <- pick_name(src_names, c("term", "source_term", "lexical_item"))
YEAR_COL <- pick_name(src_names, c("year"))
FREQ_COL <- pick_name(
  src_names,
  c("frequency", "freq", "relative_frequency")
)

if (any(is.na(c(ROW_COL, TERM_COL, YEAR_COL, FREQ_COL)))) {
  stop(
    "Selected source unexpectedly lacks required annual columns."
  )
}

# Standard helper keys, while preserving original source columns.
src <- src %>%
  mutate(
    .row_id_key = as.character(.data[[ROW_COL]]),
    .term_source = as.character(.data[[TERM_COL]]),
    .year_num = suppressWarnings(as.integer(.data[[YEAR_COL]]))
  )

if (any(is.na(src$.year_num))) {
  stop(
    "Selected source contains non-numeric/missing year values."
  )
}

# Whole-source duplicate check.
dup_source <- src %>%
  count(.row_id_key, .year_num) %>%
  filter(n > 1)

if (nrow(dup_source) > 0) {
  write_csv(
    dup_source,
    file.path(OUT_DIR, "ERROR_source_duplicate_row_id_year.csv")
  )

  stop(
    "Selected source has duplicate row_id-year combinations. ",
    "The script will not sum frequencies automatically. ",
    "See ERROR_source_duplicate_row_id_year.csv."
  )
}


# ------------------------------------------------------------
# 8. VERIFY row_id <-> term ALIGNMENT
# ------------------------------------------------------------
source_terms <- src %>%
  distinct(.row_id_key, .term_source) %>%
  semi_join(final_sem, by = c(".row_id_key" = "row_id_key"))

term_check <- final_sem %>%
  select(row_id_key, term_final = term) %>%
  left_join(
    source_terms,
    by = c("row_id_key" = ".row_id_key")
  ) %>%
  mutate(
    final_norm = norm_text(term_final),
    source_norm = norm_text(.term_source),
    term_match = final_norm == source_norm
  )

term_problems <- term_check %>%
  filter(
    is.na(.term_source) |
    !term_match
  )

if (nrow(term_problems) > 0) {
  write_csv(
    term_problems,
    file.path(OUT_DIR, "ERROR_row_id_term_mismatch.csv")
  )

  stop(
    "row_id-to-term mismatches were found between the frozen ",
    "semantic decisions and the selected annual source. ",
    "See ERROR_row_id_term_mismatch.csv."
  )
}


# ------------------------------------------------------------
# 9. PRESERVE ANY OLD SEMANTIC COLUMNS FOR AUDIT
# ------------------------------------------------------------
if ("decision" %in% names(src)) {
  names(src)[names(src) == "decision"] <- "decision_before_final_rebuild"
}

if ("valid_from_year" %in% names(src)) {
  names(src)[names(src) == "valid_from_year"] <-
    "valid_from_year_before_final_rebuild"
}


# ------------------------------------------------------------
# 10. JOIN FINAL DECISIONS
# ------------------------------------------------------------
join_map <- final_sem %>%
  select(
    row_id_key,
    final_decision,
    final_valid_from_year
  )

src2 <- src %>%
  left_join(
    join_map,
    by = c(".row_id_key" = "row_id_key")
  )

# Minimum available source year for every term.
source_min_by_id <- src2 %>%
  group_by(.row_id_key) %>%
  summarise(
    .source_min_year = min(.year_num),
    .groups = "drop"
  )

src2 <- src2 %>%
  left_join(
    source_min_by_id,
    by = ".row_id_key"
  ) %>%
  mutate(
    # Terms outside the 75-item semantic audit are implicitly retained.
    decision = case_when(
      !is.na(final_decision) ~ final_decision,
      TRUE ~ "keep"
    ),

    # For KEEP (including non-audited terms), the validity boundary is
    # the beginning of the complete available source series.
    valid_from_year = case_when(
      decision == "truncate" ~ final_valid_from_year,
      decision == "keep" ~ .source_min_year,
      TRUE ~ NA_integer_
    )
  )


# ------------------------------------------------------------
# 11. APPLY FINAL SEMANTIC FILTERS
# ------------------------------------------------------------
final_annual <- src2 %>%
  filter(
    decision != "exclude",
    decision != "truncate" |
      .year_num >= valid_from_year
  ) %>%
  arrange(
    suppressWarnings(as.numeric(.row_id_key)),
    .row_id_key,
    .year_num
  )


# ------------------------------------------------------------
# 12. FINAL INTEGRITY AUDIT
# ------------------------------------------------------------
final_term_audit <- final_annual %>%
  group_by(.row_id_key) %>%
  summarise(
    final_min_year = min(.year_num),
    final_max_year = max(.year_num),
    final_n_years = n(),
    .groups = "drop"
  )

semantic_audit <- coverage_req %>%
  left_join(
    source_min_by_id,
    by = c("row_id_key" = ".row_id_key")
  ) %>%
  left_join(
    final_term_audit,
    by = c("row_id_key" = ".row_id_key")
  ) %>%
  mutate(
    expected_min_year = case_when(
      final_decision == "keep" ~ .source_min_year,
      final_decision == "truncate" ~ final_valid_from_year,
      final_decision == "exclude" ~ NA_integer_
    ),

    pass_presence = case_when(
      final_decision == "exclude" ~ is.na(final_min_year),
      TRUE ~ !is.na(final_min_year)
    ),

    pass_no_early_rows = case_when(
      final_decision == "truncate" ~
        !is.na(final_min_year) &
        final_min_year >= final_valid_from_year,
      TRUE ~ TRUE
    ),

    pass_keep_restored = case_when(
      final_decision == "keep" ~
        !is.na(final_min_year) &
        final_min_year == .source_min_year,
      TRUE ~ TRUE
    ),

    overall_pass =
      pass_presence &
      pass_no_early_rows &
      pass_keep_restored
  )

write_csv(
  semantic_audit,
  file.path(
    OUT_DIR,
    "Semantic_Final_Rebuild_Term_Audit.csv"
  )
)

bad_final <- semantic_audit %>%
  filter(!overall_pass)

if (nrow(bad_final) > 0) {
  write_csv(
    bad_final,
    file.path(
      OUT_DIR,
      "ERROR_final_semantic_integrity_failures.csv"
    )
  )

  stop(
    "Final semantic integrity checks failed. ",
    "The FINAL annual dataset has NOT been written. ",
    "See ERROR_final_semantic_integrity_failures.csv."
  )
}


# ------------------------------------------------------------
# 13. COMPARE AGAINST OLD SEMANTIC-CLEANED DATA, IF AVAILABLE
# ------------------------------------------------------------
if (!is.na(OLD_CLEAN_FILE_OVERRIDE)) {

  OLD_CLEAN_FILE <- OLD_CLEAN_FILE_OVERRIDE

} else {

  OLD_CLEAN_FILE <- find_latest_matching_file(
    ROOT_DIR,
    "^Semantic_Clean_Annual_Data.*\\.csv$",
    exclude_regex = "FINAL"
  )
}

before_after <- tibble()

if (!is.na(OLD_CLEAN_FILE) && file.exists(OLD_CLEAN_FILE)) {

  old_hdr <- safe_header(OLD_CLEAN_FILE)

  old_row <- pick_name(old_hdr, c("row_id", "term_id", "id"))
  old_year <- pick_name(old_hdr, c("year"))

  if (!is.na(old_row) && !is.na(old_year)) {

    old_keys <- suppressMessages(
      read_csv(
        OLD_CLEAN_FILE,
        col_select = all_of(c(old_row, old_year)),
        show_col_types = FALSE,
        progress = FALSE,
        name_repair = "minimal"
      )
    ) %>%
      transmute(
        row_id_key = as.character(.data[[old_row]]),
        year = suppressWarnings(as.integer(.data[[old_year]]))
      ) %>%
      distinct()

    new_keys <- final_annual %>%
      transmute(
        row_id_key = .row_id_key,
        year = .year_num
      ) %>%
      distinct()

    restored <- anti_join(
      new_keys,
      old_keys,
      by = c("row_id_key", "year")
    )

    removed <- anti_join(
      old_keys,
      new_keys,
      by = c("row_id_key", "year")
    )

    restored_by_term <- restored %>%
      count(row_id_key, name = "n_rows_restored")

    removed_by_term <- removed %>%
      count(row_id_key, name = "n_rows_removed")

    before_after <- final_sem %>%
      select(row_id_key, row_id, term, final_decision) %>%
      left_join(restored_by_term, by = "row_id_key") %>%
      left_join(removed_by_term, by = "row_id_key") %>%
      mutate(
        n_rows_restored = coalesce(n_rows_restored, 0L),
        n_rows_removed = coalesce(n_rows_removed, 0L)
      )

    write_csv(
      restored,
      file.path(
        OUT_DIR,
        "Semantic_Final_Rows_Restored_vs_Old_Clean.csv"
      )
    )

    write_csv(
      removed,
      file.path(
        OUT_DIR,
        "Semantic_Final_Rows_Removed_vs_Old_Clean.csv"
      )
    )

    write_csv(
      before_after,
      file.path(
        OUT_DIR,
        "Semantic_Final_Before_After_By_Term.csv"
      )
    )
  }
}


# ------------------------------------------------------------
# 14. CLEAN HELPER COLUMNS AND WRITE FINAL DATA
# ------------------------------------------------------------
drop_helper <- c(
  ".row_id_key",
  ".term_source",
  ".year_num",
  ".source_min_year",
  "final_decision",
  "final_valid_from_year"
)

final_export <- final_annual %>%
  select(-any_of(drop_helper))

FINAL_ANNUAL_FILE <- file.path(
  OUT_DIR,
  "Semantic_Clean_Annual_Data_FINAL.csv"
)

write_csv(
  final_export,
  FINAL_ANNUAL_FILE
)

write_csv(
  final_sem %>% select(-row_id_key),
  file.path(
    OUT_DIR,
    "Semantic_75_FINAL_USED.csv"
  )
)

write_csv(
  decision_counts,
  file.path(
    OUT_DIR,
    "Semantic_Final_Decision_Counts.csv"
  )
)


# ------------------------------------------------------------
# 15. SUMMARY
# ------------------------------------------------------------
n_final_terms <- dplyr::n_distinct(
  final_export[[ROW_COL]]
)

n_final_rows <- nrow(final_export)

n_excluded <- sum(final_sem$final_decision == "exclude")
n_truncated <- sum(final_sem$final_decision == "truncate")
n_kept <- sum(final_sem$final_decision == "keep")

restored_total <- if (nrow(before_after) > 0) {
  sum(before_after$n_rows_restored)
} else {
  NA_integer_
}

removed_total <- if (nrow(before_after) > 0) {
  sum(before_after$n_rows_removed)
} else {
  NA_integer_
}

summary_lines <- c(
  "FINAL SEMANTIC CLEAN REBUILD",
  "============================",
  "",
  paste0("Frozen semantic decision file: ", FINAL_FILE),
  paste0("Pre-semantic annual source: ", SOURCE_FILE),
  if (!is.na(OLD_CLEAN_FILE)) {
    paste0("Old semantic-cleaned comparison file: ", OLD_CLEAN_FILE)
  } else {
    "Old semantic-cleaned comparison file: not found"
  },
  "",
  paste0("Study window: ", STUDY_START_YEAR, "-", STUDY_END_YEAR),
  paste0("Frozen audit items: ", nrow(final_sem)),
  paste0("KEEP: ", n_kept),
  paste0("TRUNCATE: ", n_truncated),
  paste0("EXCLUDE: ", n_excluded),
  "",
  paste0("Final annual rows: ", n_final_rows),
  paste0("Final unique row_id terms: ", n_final_terms),
  if (!is.na(restored_total)) {
    paste0("Rows restored relative to old semantic-cleaned data: ", restored_total)
  } else {
    "Rows restored relative to old semantic-cleaned data: comparison unavailable"
  },
  if (!is.na(removed_total)) {
    paste0("Rows removed relative to old semantic-cleaned data: ", removed_total)
  } else {
    "Rows removed relative to old semantic-cleaned data: comparison unavailable"
  },
  "",
  "Integrity status: PASS",
  "",
  paste0("FINAL annual file: ", FINAL_ANNUAL_FILE),
  "",
  "Next step:",
  "Use Semantic_Clean_Annual_Data_FINAL.csv as the single source for",
  "all downstream H1/H2/RQ1-RQ4 analyses and then rerun the",
  "historical-spelling sensitivity analysis on the frozen semantic data."
)

SUMMARY_FILE <- file.path(
  OUT_DIR,
  "Semantic_Final_Rebuild_Summary.txt"
)

write_txt(
  summary_lines,
  SUMMARY_FILE
)

capture.output(
  sessionInfo(),
  file = file.path(
    OUT_DIR,
    "sessionInfo_semantic_final_rebuild.txt"
  )
)


# ------------------------------------------------------------
# 16. CONSOLE REPORT
# ------------------------------------------------------------
cat("\n============================================================\n")
cat("FINAL SEMANTIC REBUILD COMPLETE\n")
cat("============================================================\n")
cat("KEEP     :", n_kept, "\n")
cat("TRUNCATE :", n_truncated, "\n")
cat("EXCLUDE  :", n_excluded, "\n")
cat("Final rows:", n_final_rows, "\n")
cat("Final terms:", n_final_terms, "\n")

if (!is.na(restored_total)) {
  cat("Rows restored vs old clean:", restored_total, "\n")
}

if (!is.na(removed_total)) {
  cat("Rows removed vs old clean:", removed_total, "\n")
}

cat("\nOutput directory:\n", OUT_DIR, "\n", sep = "")
cat("\nMain output:\n", FINAL_ANNUAL_FILE, "\n", sep = "")
cat("\nIntegrity audit:\n",
    file.path(OUT_DIR, "Semantic_Final_Rebuild_Term_Audit.csv"),
    "\n", sep = "")
cat("\nSummary:\n", SUMMARY_FILE, "\n", sep = "")
cat("\nDONE.\n")
