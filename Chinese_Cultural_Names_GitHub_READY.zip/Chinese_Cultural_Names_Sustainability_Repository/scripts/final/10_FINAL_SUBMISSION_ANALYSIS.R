# ============================================================
# 10_FINAL_SUBMISSION_ANALYSIS.R
#
# Final submission analysis after focused external-review corrections.
#
# Core changes:
#   1) Restore final three-way pathway scheme:
#        source_form / pure_calque / mixed
#      and eliminate "overlap" as a substantive pathway.
#   2) Apply historically defensible no-earlier-than boundaries
#      to date-sensitive political / institutional expressions.
#   3) Restore fixed 20-year and 30-year persistence windows.
#   4) Recompute H1, H2, RQ1-RQ4 after the corrections.
#   5) Report ALL RQ3 interactions + within-domain simple effects.
#   6) Historical-spelling sensitivity uses ONLY individually
#      verified historical variants with variant-specific boundaries.
#      Unverified Nien / tang chung forms are explicitly blocked.
#   7) Bootstrap the paired change in pathway coefficient (delta-b).
#
# IMPORTANT:
#   The previous kappa=.972 described agreement under the provisional
#   pathway scheme. It should NOT be presented as proof that the
#   revised three-way labels are correct. The rule-sensitive cases
#   below are etymologically adjudicated and exported for audit.
# ============================================================


# ------------------------------------------------------------
# 0. SETTINGS
# ------------------------------------------------------------
ROOT_DIR <- "E:/论文/中国文化/英语中的中文"
OUT_DIR  <- file.path(ROOT_DIR, "FINAL_SUBMISSION_OUTPUTS")
dir.create(OUT_DIR, recursive = TRUE, showWarnings = FALSE)

YEAR_START <- 1800L
YEAR_END   <- 2022L
MONTE_CARLO_B <- 50000L
BOOT_B <- 2000L
INSTALL_MISSING <- TRUE

# Optional overrides
FINAL_ANNUAL_OVERRIDE <- NA_character_
HIST_VARIANTS_OVERRIDE <- NA_character_
HIST_MAP_OVERRIDE <- NA_character_

# Main sustained-onset definition
MAIN_WINDOW <- 5L
MAIN_MIN_POSITIVE <- 3L


# ------------------------------------------------------------
# 1. PACKAGES
# ------------------------------------------------------------
packages <- c(
  "readr","dplyr","tidyr","stringr","purrr","forcats",
  "ggplot2","slider","broom","sandwich","lmtest","mgcv",
  "scales","ggrepel","tibble","openxlsx"
)

missing_packages <- packages[
  !vapply(packages, requireNamespace, logical(1), quietly = TRUE)
]

if (length(missing_packages) > 0) {
  if (!INSTALL_MISSING) {
    stop("Missing packages: ", paste(missing_packages, collapse=", "))
  }
  install.packages(missing_packages, repos="https://cloud.r-project.org")
}

suppressPackageStartupMessages({
  library(readr); library(dplyr); library(tidyr); library(stringr)
  library(purrr); library(forcats); library(ggplot2); library(slider)
  library(broom); library(sandwich); library(lmtest); library(mgcv)
  library(scales); library(ggrepel); library(tibble); library(openxlsx)
})

theme_set(
  theme_bw(base_size = 11) +
    theme(
      panel.grid.minor = element_blank(),
      legend.position = "bottom",
      plot.title = element_blank()
    )
)


# ------------------------------------------------------------
# 2. HELPERS
# ------------------------------------------------------------
find_exact <- function(filename, required=TRUE) {
  hits <- list.files(
    ROOT_DIR,
    pattern=paste0("^", gsub("\\.", "\\\\.", filename), "$"),
    recursive=TRUE, full.names=TRUE, ignore.case=TRUE
  )
  if (length(hits)==0) {
    if (required) stop("Cannot find: ", filename)
    return(NA_character_)
  }
  info <- file.info(hits)
  hits[order(info$mtime, decreasing=TRUE)][1]
}

to_logical <- function(x) {
  if (is.logical(x)) return(x)
  z <- tolower(trimws(as.character(x)))
  dplyr::case_when(
    z %in% c("true","t","1","yes","y") ~ TRUE,
    z %in% c("false","f","0","no","n") ~ FALSE,
    TRUE ~ NA
  )
}

write_txt <- function(lines, path) {
  con <- file(path, "wt", encoding="UTF-8")
  on.exit(close(con), add=TRUE)
  writeLines(lines, con, useBytes=TRUE)
}

make_formula <- function(outcome, rhs) {
  as.formula(paste(outcome, "~", paste(rhs, collapse=" + ")))
}

safe_vcovHC <- function(model) {
  tryCatch(sandwich::vcovHC(model, type="HC3"), error=function(e) NULL)
}

tidy_robust <- function(model, model_name, exponentiate=FALSE) {
  vc <- safe_vcovHC(model)
  if (is.null(vc) || any(!is.finite(vc))) {
    return(tibble(
      model=model_name, term=names(coef(model)),
      estimate=unname(coef(model)),
      std_error=NA_real_, statistic=NA_real_, p_value=NA_real_,
      conf_low=NA_real_, conf_high=NA_real_,
      effect_ratio=NA_real_, effect_ratio_low=NA_real_,
      effect_ratio_high=NA_real_, hc3_status="FAILED"
    ))
  }

  ct <- lmtest::coeftest(model, vcov.=vc)
  z <- tibble(
    model=model_name,
    term=rownames(ct),
    estimate=ct[,1],
    std_error=ct[,2],
    statistic=ct[,3],
    p_value=ct[,4],
    conf_low=ct[,1]-1.96*ct[,2],
    conf_high=ct[,1]+1.96*ct[,2],
    hc3_status="PASS"
  )

  if (exponentiate) {
    z <- z %>% mutate(
      effect_ratio=exp(estimate),
      effect_ratio_low=exp(conf_low),
      effect_ratio_high=exp(conf_high)
    )
  } else {
    z <- z %>% mutate(
      effect_ratio=NA_real_,
      effect_ratio_low=NA_real_,
      effect_ratio_high=NA_real_
    )
  }
  z
}

calc_sustained_onset <- function(year, frequency,
                                 window=5L, min_positive=3L) {
  o <- order(year)
  year <- as.integer(year[o])
  frequency <- as.numeric(frequency[o])
  pos <- !is.na(frequency) & frequency > 0

  if (length(pos) < window) return(NA_integer_)

  for (i in seq_len(length(pos)-window+1L)) {
    idx <- i:(i+window-1L)
    if (sum(pos[idx]) >= min_positive) return(year[i])
  }
  NA_integer_
}

calc_sustained_indicator <- function(year, positive,
                                     window=5L, min_positive=3L) {
  o <- order(year)
  year <- as.integer(year[o])
  positive <- as.logical(positive[o])
  positive[is.na(positive)] <- FALSE

  if (length(positive) < window) return(NA_integer_)

  for (i in seq_len(length(positive)-window+1L)) {
    idx <- i:(i+window-1L)
    if (sum(positive[idx]) >= min_positive) return(year[i])
  }
  NA_integer_
}

calc_consecutive_onset <- function(year, frequency, run=3L) {
  o <- order(year)
  year <- as.integer(year[o])
  frequency <- as.numeric(frequency[o])
  pos <- !is.na(frequency) & frequency > 0

  if (length(pos) < run) return(NA_integer_)

  for (i in seq_len(length(pos)-run+1L)) {
    idx <- i:(i+run-1L)
    if (all(pos[idx])) return(year[i])
  }
  NA_integer_
}

calc_fixed_window <- function(year, frequency, onset, width) {
  if (is.na(onset)) return(NA_real_)
  end_year <- onset + width - 1L
  if (end_year > YEAR_END) return(NA_real_)

  use <- year >= onset & year <= end_year
  # Require a complete calendar window after semantic/date filtering.
  if (sum(use) != width) return(NA_real_)
  mean(frequency[use] > 0, na.rm=TRUE)
}

calc_term_metrics <- function(df) {
  df <- df %>% arrange(year)
  year <- df$year
  freq <- df$frequency

  first_positive <- if (any(freq > 0, na.rm=TRUE)) {
    min(year[freq > 0], na.rm=TRUE)
  } else NA_integer_

  onset <- calc_sustained_onset(
    year, freq, MAIN_WINDOW, MAIN_MIN_POSITIVE
  )
  onset4 <- calc_sustained_onset(year, freq, 5L, 4L)
  onset3c <- calc_consecutive_onset(year, freq, 3L)

  roll10 <- slider::slide_dbl(
    freq, mean, .before=4L, .after=5L,
    .complete=TRUE, na.rm=TRUE
  )

  peak10 <- if (all(is.na(roll10))) NA_real_ else max(roll10, na.rm=TRUE)

  if (!is.na(onset)) {
    post <- year >= onset
    exposure_years <- sum(post)
    persistence_to_2022 <- mean(freq[post] > 0, na.rm=TRUE)
  } else {
    exposure_years <- NA_integer_
    persistence_to_2022 <- NA_real_
  }

  contemporary_mean <- mean(
    freq[year >= 2000 & year <= 2022], na.rm=TRUE
  )

  contemporary_retention <- if (is.finite(peak10) && peak10 > 0) {
    contemporary_mean / peak10
  } else NA_real_

  tibble(
    first_positive_year=first_positive,
    sustained_onset=onset,
    sustained_onset_4of5=onset4,
    sustained_onset_3consecutive=onset3c,
    exposure_years=exposure_years,
    persistence_to_2022=persistence_to_2022,
    persistence_20y=calc_fixed_window(year, freq, onset, 20L),
    persistence_30y=calc_fixed_window(year, freq, onset, 30L),
    contemporary_retention=contemporary_retention,
    cumulative_frequency=sum(freq, na.rm=TRUE)
  )
}

collapse_domain3 <- function(x) {
  case_when(
    x %in% c(
      "food_drink","body_medicine_martial",
      "heritage_historical_space","material_culture_architecture"
    ) ~ "material_practice",
    x %in% c(
      "arts_literature_writing_language",
      "festivals_ritual_myth",
      "philosophy_religion_cosmology"
    ) ~ "symbolic_ideational",
    x %in% c(
      "popular_digital","social_political_historical"
    ) ~ "social_political_modern",
    TRUE ~ NA_character_
  )
}


# ------------------------------------------------------------
# 3. INPUTS
# ------------------------------------------------------------
FINAL_ANNUAL_FILE <- if (!is.na(FINAL_ANNUAL_OVERRIDE)) {
  FINAL_ANNUAL_OVERRIDE
} else {
  find_exact("Semantic_Clean_Annual_Data_FINAL.csv")
}

HIST_VARIANTS_FILE <- if (!is.na(HIST_VARIANTS_OVERRIDE)) {
  HIST_VARIANTS_OVERRIDE
} else {
  find_exact("historical_spelling_annual_variants.csv", required=FALSE)
}

HIST_MAP_FILE <- if (!is.na(HIST_MAP_OVERRIDE)) {
  HIST_MAP_OVERRIDE
} else {
  find_exact("historical_spelling_variant_map_predefined.csv", required=FALSE)
}

LEXICON_FILE <- find_exact(
  "ngram_main_sample_cleaned.csv",
  required=FALSE
)

cat("\nFINAL annual:", FINAL_ANNUAL_FILE, "\n")
cat("Historical variants:", HIST_VARIANTS_FILE, "\n")
cat("Historical map:", HIST_MAP_FILE, "\n")
cat("Lexicon:", LEXICON_FILE, "\n\n")


# ------------------------------------------------------------
# 4. READ FINAL SEMANTIC-CLEAN ANNUAL DATA
# ------------------------------------------------------------
raw <- suppressMessages(
  read_csv(FINAL_ANNUAL_FILE, show_col_types=FALSE)
)

needed <- c(
  "row_id","term","ngram_query","pathway",
  "pathway_comparison_eligible","cultural_domain",
  "concept_group","query_risk","case_insensitive",
  "year","frequency","decision","valid_from_year"
)

miss <- setdiff(needed, names(raw))
if (length(miss)>0) {
  stop("Missing columns: ", paste(miss, collapse=", "))
}

raw <- raw %>%
  mutate(
    row_id=as.integer(row_id),
    year=as.integer(year),
    frequency=as.numeric(frequency),
    pathway_comparison_eligible=to_logical(pathway_comparison_eligible),
    case_insensitive=to_logical(case_insensitive)
  )

if (raw %>% count(row_id, year) %>% filter(n>1) %>% nrow() > 0) {
  stop("Duplicate row_id-year records found.")
}


# ------------------------------------------------------------
# 5. FINAL PATHWAY CODEBOOK + TARGETED INDEPENDENT VERIFICATION
# ------------------------------------------------------------
# Final coding hierarchy:
#   Priority 1: entry-level etymological analysis of the whole English term.
#   Priority 2: lexical status of components when whole-term etymology is
#               absent or underspecified.
#   Priority 3: Wiktionary parent categories are discovery metadata only
#               and never override an entry-level etymology.
#
# SOURCE_FORM:
#   The English item substantially preserves a Chinese source form,
#   transliteration, romanization, or source-language lexical shape.
#
# PURE_CALQUE:
#   The whole English expression is documented as a calque / loan
#   translation of the Chinese expression. A conventional English exonym
#   (e.g., a long-established English place-name form) counts as English
#   lexical material when the whole expression is explicitly documented
#   as a calque.
#
# MIXED:
#   A directly retained Chinese source-form/transliterated component is
#   combined with an English generic or translated component, AND there is
#   no stronger entry-level evidence that the whole expression is a full
#   calque.
#
# Consequence for rule-sensitive geographic-name compounds:
#   - Whole-expression calque evidence has priority over surface appearance.
#   - A romanized source component + English generic is mixed when the
#     whole item lacks full-calque evidence.
#
# The old "overlap_direct_and_calque" label is NOT a linguistic pathway;
# it represented category nesting and is resolved item by item.

pathway_codebook <- tribble(
  ~rule_id, ~rule, ~operational_definition,
  "P1", "Whole-entry etymology has first priority",
  "If a reliable entry-level etymology explicitly identifies the whole English expression as a calque/loan translation, code pure_calque even if one component is a conventional English exonym.",
  "P2", "Source-form retention",
  "Code source_form when the English item substantially preserves Chinese phonological/romanized/source-language form and is not a mixed source-form-plus-English-generic compound.",
  "P3", "Mixed construction",
  "Code mixed when a directly retained/transliterated Chinese component combines with an English generic/translated component and no stronger whole-expression full-calque analysis is available.",
  "P4", "Conventional English exonyms",
  "A conventional English exonym is treated as established English lexical material when the whole expression is explicitly documented as a calque; the exonym alone does not force a mixed label.",
  "P5", "Parent-category conflict",
  "Wiktionary parent/child category membership is discovery metadata. Entry-level etymology overrides parent-category overlap.",
  "P6", "Unresolved conflict",
  "If entry-level etymology and surface decomposition remain genuinely incompatible, mark unresolved and exclude the term from binary pathway inference until adjudicated."
)

write_csv(
  pathway_codebook,
  file.path(OUT_DIR, "PATHWAY_CODEBOOK_FINAL.csv")
)

mixed_terms <- c(
  "Qingming Festival",
  "Gougu theorem",
  "Laba Festival",
  "Chinkiang vinegar",
  "Laba congee",
  "Laba porridge"
)

explicit_calque_terms <- c(
  "Mid-Autumn Festival",
  "Double Ninth Festival",
  "yellow wine",
  "insect wax",
  "white wax",
  "Pure Land"
)

meta0 <- raw %>%
  distinct(
    row_id, term, ngram_query, pathway,
    pathway_comparison_eligible, cultural_domain,
    concept_group, query_risk, case_insensitive,
    decision, valid_from_year
  )

path_audit <- meta0 %>%
  mutate(
    pathway_provisional=pathway,
    pathway_final=case_when(
      term %in% mixed_terms ~ "mixed",
      term %in% explicit_calque_terms ~ "pure_calque",
      pathway == "direct_borrowing" ~ "source_form",
      pathway == "calque" ~ "pure_calque",
      pathway == "overlap_direct_and_calque" ~ "pure_calque",
      TRUE ~ NA_character_
    ),
    pathway_change=pathway_final != case_when(
      pathway=="direct_borrowing" ~ "source_form",
      pathway=="calque" ~ "pure_calque",
      pathway=="overlap_direct_and_calque" ~ "overlap",
      TRUE ~ pathway
    ),
    adjudication_basis=case_when(
      term=="Qingming Festival" ~
        "Entry-level etymology identifies a partial calque; retained source-form Qingming + English Festival.",
      term=="Mid-Autumn Festival" ~
        "Entry-level etymology identifies the whole expression as a calque.",
      term=="Peking duck" ~
        "Whole-expression calque evidence has priority; Peking functions as an established English exonym in this expression.",
      term=="Chinkiang vinegar" ~
        "Chinkiang preserves a historical romanized Chinese place-name form + English generic vinegar; no whole-expression full-calque analysis used.",
      term %in% c("Double Ninth Festival","yellow wine","insect wax",
                  "white wax","Pure Land") ~
        "Parent-category overlap resolved by entry-level calque etymology.",
      term %in% c("Gougu theorem","Laba Festival",
                  "Laba congee","Laba porridge") ~
        "Retained source-form component + English generic/translated component.",
      pathway=="overlap_direct_and_calque" ~
        "Old overlap label represented category nesting, not a linguistic pathway.",
      TRUE ~ "No rule-sensitive reclassification."
    )
  )

write_csv(
  path_audit,
  file.path(OUT_DIR, "PATHWAY_FINAL_AUDIT.csv")
)

# Build a targeted independent-review workbook.
# This is NOT a replacement for the previous full-sample kappa.
# It documents independent verification of all changed / boundary cases
# under the FINAL codebook.
lex_urls <- tibble(term=character(), source_category=character(),
                   wiktionary_url=character())

if (!is.na(LEXICON_FILE) && file.exists(LEXICON_FILE)) {
  lex0 <- suppressMessages(
    read_csv(LEXICON_FILE, show_col_types=FALSE)
  )
  keep_url_cols <- intersect(
    c("term","source_category","wiktionary_url"),
    names(lex0)
  )
  if ("term" %in% keep_url_cols) {
    lex_urls <- lex0 %>%
      select(all_of(keep_url_cols)) %>%
      distinct(term, .keep_all=TRUE)
  }
}

target_terms <- unique(c(
  path_audit$term[path_audit$pathway_change %in% TRUE],
  path_audit$term[path_audit$pathway_final=="mixed"],
  "Peking duck"
))

target_review <- path_audit %>%
  filter(term %in% target_terms) %>%
  select(row_id,term,ngram_query,cultural_domain) %>%
  left_join(lex_urls,by="term") %>%
  mutate(
    coder2_pathway=NA_character_,
    confidence=NA_character_,
    evidence_note=NA_character_
  ) %>%
  arrange(row_id)

write_csv(
  target_review,
  file.path(OUT_DIR, "PATHWAY_TARGETED_REVIEW_BLANK.csv")
)

wb <- createWorkbook()
addWorksheet(wb,"Instructions")
addWorksheet(wb,"Codebook")
addWorksheet(wb,"Targeted_Review")

instructions_path <- tibble(
  Item=c(
    "Purpose","Independence","Allowed labels","Priority",
    "Exonym rule","Mixed rule","Conflict rule","Reporting"
  ),
  Detail=c(
    "Independent verification of rule-sensitive pathway items after the final three-way codebook was clarified.",
    "The reviewer should not consult PATHWAY_FINAL_AUDIT.csv or the first coder's final labels before completing this sheet.",
    "source_form; pure_calque; mixed; unresolved",
    "Whole-entry etymology > component analysis > parent-category metadata.",
    "A conventional English exonym does not by itself force mixed coding when the whole expression is explicitly documented as a calque.",
    "Use mixed when a directly retained/romanized Chinese component combines with an English generic/translation component and there is no stronger full-calque analysis.",
    "If evidence genuinely conflicts, choose unresolved and explain why; do not force agreement.",
    "Because this is a targeted boundary subset, report raw agreement and, if category distribution permits, kappa as targeted verification rather than full-sample reliability."
  )
)

writeData(wb,"Instructions",instructions_path)
writeData(wb,"Codebook",pathway_codebook)
writeData(wb,"Targeted_Review",target_review)

dataValidation(
  wb,"Targeted_Review",
  cols=which(names(target_review)=="coder2_pathway"),
  rows=2:(nrow(target_review)+1),
  type="list",
  value='"source_form,pure_calque,mixed,unresolved"'
)
dataValidation(
  wb,"Targeted_Review",
  cols=which(names(target_review)=="confidence"),
  rows=2:(nrow(target_review)+1),
  type="list",
  value='"high,medium,low"'
)

freezePane(wb,"Targeted_Review",firstRow=TRUE)
setColWidths(wb,"Targeted_Review",cols=1:ncol(target_review),widths="auto")
setColWidths(wb,"Instructions",cols=1,widths=22)
setColWidths(wb,"Instructions",cols=2,widths=100)
setColWidths(wb,"Codebook",cols=1:3,widths=c(10,28,100))

saveWorkbook(
  wb,
  file.path(OUT_DIR,"PATHWAY_TARGETED_INDEPENDENT_REVIEW.xlsx"),
  overwrite=TRUE
)

cat("\nPathway counts after final adjudication (retained terms):\n")
print(path_audit %>% count(pathway_final))

main0 <- raw %>%
  select(-pathway) %>%
  left_join(
    path_audit %>% select(row_id, pathway_final),
    by="row_id"
  ) %>%
  rename(pathway=pathway_final)


# ------------------------------------------------------------
# 6. DATE-EVIDENCE MATRIX + CONSERVATIVE OBSERVATION STARTS
# ------------------------------------------------------------
# Three evidence types are kept analytically distinct:
#
# A. object_formation_guardrail:
#    The target institution / political movement / named object could
#    not have existed before this year. This can exclude impossible
#    earlier homographic strings.
#
# B. verified_target_example_year:
#    A checked historical example proves that the target sense existed
#    BY this year. It does NOT prove that every earlier occurrence is
#    invalid.
#
# C. official_standardization_year:
#    An administrative / official naming or standardization node. It
#    does NOT establish the earliest possible English target-sense use.
#
# D. adopted_analysis_start:
#    The conservative observation start used in the PRIMARY analysis.
#    This is a study design choice and is not presented as the true
#    first attestation unless independent evidence specifically warrants it.
#
# The PRIMARY model uses adopted_analysis_start.
# A boundary-sensitivity model uses only hard object-formation guardrails
# plus the pre-existing semantic adjudication boundary. This directly
# tests dependence on conservative attestation/standardization choices.

date_evidence <- tribble(
  ~term, ~object_formation_guardrail, ~verified_target_example_year,
  ~official_standardization_year, ~adopted_analysis_start,
  ~evidence_type, ~evidence_note,

  "Belt and Road", 2013L, NA_integer_, 2015L, 2015L,
  "official_standardization_conservative_start",
  "The initiative dates to 2013; the official English short form was standardized in 2015. The primary analysis adopts 2015 conservatively and does not claim that all 2013-2014 English uses are invalid.",

  "brainwash", NA_integer_, 1950L, NA_integer_, 1950L,
  "lexicographic_first_record_conservative_start",
  "OUP identifies 1950 as the first recorded English target term. The study uses 1950 conservatively while acknowledging the general limits of first-record evidence.",

  "brainwashing", NA_integer_, 1950L, NA_integer_, 1950L,
  "lexicographic_first_record_conservative_start",
  "OUP identifies 1950 as the first recorded English target term. Earlier generic strings are not treated as target evidence.",

  "Eighth Route Army", 1937L, 1938L, NA_integer_, 1937L,
  "object_formation_guardrail",
  "The institution was created in 1937; pre-1937 strings cannot denote this army. A 1938 English book provides checked target-sense evidence.",

  "Great Leap Forward", 1958L, 1959L, NA_integer_, 1958L,
  "object_formation_guardrail",
  "The PRC campaign began in 1958; pre-1958 strings cannot denote the target political campaign.",

  "Chinese Dream", 2012L, NA_integer_, NA_integer_, 2012L,
  "object_formation_guardrail",
  "The current Xi-era political slogan was introduced in 2012; earlier generic uses of the same string are outside this target sense.",

  "Four Olds", 1966L, NA_integer_, NA_integer_, 1966L,
  "object_formation_guardrail",
  "The target Cultural Revolution campaign belongs to 1966 and later.",

  "Gang of Four", 1976L, NA_integer_, NA_integer_, 1976L,
  "object_formation_guardrail",
  "The target faction label refers to the post-Mao political grouping associated with 1976.",

  "capitalist roader", 1965L, NA_integer_, NA_integer_, 1965L,
  "object_formation_guardrail",
  "The target Maoist political label is documented from the mid-1960s; earlier generic strings are outside the target sense.",

  "wumao", 2004L, NA_integer_, NA_integer_, 2004L,
  "object_formation_guardrail",
  "The target paid-online-commentator phenomenon is documented from 2004; earlier strings cannot denote this internet-political sense.",

  "iron rice bowl", NA_integer_, 1980L, NA_integer_, 1980L,
  "verified_example_conservative_start",
  "English policy usage is directly documented by 1980. The study adopts 1980 as a conservative observation start; it does not assert that all earlier target uses are impossible.",

  "struggle session", 1946L, NA_integer_, NA_integer_, 1946L,
  "object_formation_guardrail",
  "The target Maoist land-reform practice is documented in the late 1940s; 1946 is used to remove impossible earlier generic uses.",

  "Spring Festival", NA_integer_, NA_integer_, 1914L, 1914L,
  "official_naming_conservative_start",
  "1914 is an administrative naming node for Chunjie/Spring Festival. It is used as a conservative observation start, not as proof that all earlier English target-sense uses are invalid.",

  "yellow wine", NA_integer_, 1891L, NA_integer_, 1891L,
  "verified_example_conservative_start",
  "Coltman (1891, p.122) explicitly links 'huang chiu' and 'yellow wine'. This proves target use by 1891, not that every earlier occurrence is invalid; 1891 is a conservative analysis start.",

  "let a thousand flowers bloom", 1956L, NA_integer_, NA_integer_, 1956L,
  "object_formation_guardrail",
  "The target Hundred Flowers political slogan dates to 1956; earlier flower-blooming strings cannot carry this political sense."
)

write_csv(
  date_evidence,
  file.path(OUT_DIR,"DATE_EVIDENCE_MATRIX.csv")
)

# Existing semantic adjudication remains the base boundary.
base_boundaries <- main0 %>%
  distinct(row_id,term,valid_from_year) %>%
  mutate(
    semantic_start=coalesce(as.integer(valid_from_year),YEAR_START)
  ) %>%
  left_join(date_evidence,by="term") %>%
  mutate(
    primary_analysis_start=case_when(
      !is.na(adopted_analysis_start) ~
        pmax(semantic_start,adopted_analysis_start),
      TRUE ~ semantic_start
    ),
    hard_guardrail_start=case_when(
      !is.na(object_formation_guardrail) ~
        pmax(semantic_start,object_formation_guardrail),
      TRUE ~ semantic_start
    ),
    primary_is_observation_choice =
      !is.na(adopted_analysis_start) &
      (
        is.na(object_formation_guardrail) |
        adopted_analysis_start > object_formation_guardrail
      )
  )

write_csv(
  base_boundaries,
  file.path(OUT_DIR,"DATE_BOUNDARY_BEFORE_AFTER.csv")
)

# PRIMARY dataset: conservative adopted observation starts.
main1 <- main0 %>%
  left_join(
    base_boundaries %>%
      select(row_id,primary_analysis_start),
    by="row_id"
  ) %>%
  mutate(audited_valid_from=primary_analysis_start) %>%
  filter(year >= audited_valid_from)

# HARD-GUARDRAIL sensitivity dataset: only object formation + prior
# semantic adjudication. This is not automatically "truer"; it shows
# how much the primary coefficient depends on conservative starts.
main_hard <- main0 %>%
  left_join(
    base_boundaries %>%
      select(row_id,hard_guardrail_start),
    by="row_id"
  ) %>%
  mutate(audited_valid_from=hard_guardrail_start) %>%
  filter(year >= audited_valid_from)

write_csv(
  main1,
  file.path(OUT_DIR,"FINAL_SUBMISSION_ANNUAL_DATA.csv")
)
write_csv(
  main_hard,
  file.path(OUT_DIR,"BOUNDARY_SENSITIVITY_HARD_GUARDRAIL_DATA.csv")
)


# ------------------------------------------------------------
# 7. TERM METRICS INCLUDING FIXED 20/30-YEAR WINDOWS
# ------------------------------------------------------------
term_meta <- main1 %>%
  distinct(
    row_id, term, ngram_query, pathway, cultural_domain,
    concept_group, query_risk, case_insensitive,
    audited_valid_from, decision
  ) %>%
  mutate(
    pathway_binary=if_else(
      pathway %in% c("source_form","pure_calque"),
      pathway, NA_character_
    ),
    pathway_binary=factor(
      pathway_binary,
      levels=c("source_form","pure_calque")
    ),
    token_count=str_count(ngram_query, "\\S+"),
    domain3=factor(
      collapse_domain3(cultural_domain),
      levels=c("material_practice","symbolic_ideational",
               "social_political_modern")
    ),
    query_risk=factor(query_risk, levels=c("low","moderate")),
    case_insensitive=factor(case_insensitive)
  )

term_metrics <- main1 %>%
  group_by(row_id) %>%
  group_modify(~calc_term_metrics(.x)) %>%
  ungroup() %>%
  left_join(term_meta, by="row_id") %>%
  mutate(
    token_count_c=token_count-mean(token_count, na.rm=TRUE)
  )

write_csv(
  term_metrics,
  file.path(OUT_DIR, "TERM_METRICS_AUDITED.csv")
)


# ------------------------------------------------------------
# 8. BROADER DATE SCREEN FOR POLITICAL / INSTITUTIONAL TERMS
# ------------------------------------------------------------
date_screen <- term_metrics %>%
  filter(cultural_domain=="social_political_historical") %>%
  arrange(sustained_onset) %>%
  select(
    row_id, term, pathway, sustained_onset,
    first_positive_year, audited_valid_from,
    query_risk, decision
  ) %>%
  mutate(
    needs_manual_context_check =
      sustained_onset < 1949 & !term %in% date_audit$term
  )

write_csv(
  date_screen,
  file.path(OUT_DIR, "DATE_SCREEN_ALL_SOCIAL_POLITICAL_TERMS.csv")
)


# ------------------------------------------------------------
# 9. H1: FINAL THREE-WAY CODING, BINARY INFERENCE ONLY
# ------------------------------------------------------------
h1 <- term_metrics %>%
  filter(!is.na(pathway_binary))

tab <- table(h1$cultural_domain, h1$pathway_binary)

chi <- suppressWarnings(chisq.test(tab, correct=FALSE))
set.seed(20261029)
chi_mc <- chisq.test(tab, simulate.p.value=TRUE, B=MONTE_CARLO_B)

V <- sqrt(
  as.numeric(chi$statistic) /
    (sum(tab)*min(nrow(tab)-1, ncol(tab)-1))
)

h1_test <- tibble(
  n=sum(tab),
  chi_square=as.numeric(chi$statistic),
  df=as.numeric(chi$parameter),
  p_asymptotic=chi$p.value,
  p_monte_carlo=chi_mc$p.value,
  B=MONTE_CARLO_B,
  cramers_v=V,
  min_expected=min(chi$expected)
)

h1_counts <- as.data.frame.matrix(tab) %>%
  tibble::rownames_to_column("cultural_domain")

h1_resid <- as.data.frame(as.table(chi$stdres)) %>%
  rename(
    cultural_domain=Var1,
    pathway=Var2,
    standardized_residual=Freq
  )

write_csv(h1_test, file.path(OUT_DIR,"H1_FINAL_TEST.csv"))
write_csv(h1_counts, file.path(OUT_DIR,"H1_FINAL_COUNTS.csv"))
write_csv(h1_resid, file.path(OUT_DIR,"H1_FINAL_RESIDUALS.csv"))


# ------------------------------------------------------------
# 10. H2: OUTCOME-SPECIFIC ANALYTICAL SAMPLES
# ------------------------------------------------------------
# IMPORTANT:
# Each outcome uses the largest sample with that outcome and its own
# covariates. Missingness in a different outcome is NOT an exclusion
# criterion.
#
# Expected logic:
#   onset: all binary-pathway terms with onset + covariates
#   persistence: all binary-pathway terms with persistence + covariates
#   contemporary retention: only terms with retention + covariates
#
# A common-complete sample is retained ONLY as a sensitivity analysis.

base_h2 <- term_metrics %>%
  filter(
    !is.na(pathway_binary),
    !is.na(domain3),
    !is.na(token_count_c),
    !is.na(query_risk),
    !is.na(case_insensitive)
  ) %>%
  mutate(
    pathway_binary=relevel(pathway_binary,ref="source_form"),
    domain3=relevel(domain3,ref="material_practice"),
    query_risk=relevel(query_risk,ref="low")
  )

onset_data <- base_h2 %>%
  filter(!is.na(sustained_onset))

persistence_data <- base_h2 %>%
  filter(
    !is.na(persistence_to_2022),
    !is.na(exposure_years)
  )

retention_data <- base_h2 %>%
  filter(!is.na(contemporary_retention))

common_complete <- base_h2 %>%
  filter(
    !is.na(sustained_onset),
    !is.na(persistence_to_2022),
    !is.na(contemporary_retention)
  )

sample_flow <- tibble(
  outcome=c(
    "sustained_onset",
    "persistence_to_2022",
    "contemporary_retention",
    "common_complete_sensitivity"
  ),
  n=c(
    nrow(onset_data),
    nrow(persistence_data),
    nrow(retention_data),
    nrow(common_complete)
  )
)

write_csv(
  sample_flow,
  file.path(OUT_DIR,"H2_OUTCOME_SPECIFIC_SAMPLE_FLOW.csv")
)

# Explicitly list exclusions by outcome.
all_binary_ids <- base_h2 %>% select(row_id,term,pathway_binary)

sample_exclusions <- bind_rows(
  all_binary_ids %>%
    anti_join(onset_data %>% select(row_id),by="row_id") %>%
    mutate(outcome="sustained_onset"),
  all_binary_ids %>%
    anti_join(persistence_data %>% select(row_id),by="row_id") %>%
    mutate(outcome="persistence_to_2022"),
  all_binary_ids %>%
    anti_join(retention_data %>% select(row_id),by="row_id") %>%
    mutate(outcome="contemporary_retention")
)

write_csv(
  sample_exclusions,
  file.path(OUT_DIR,"H2_OUTCOME_SPECIFIC_EXCLUSIONS.csv")
)

rhs <- c(
  "pathway_binary","domain3","token_count_c",
  "query_risk","case_insensitive"
)

m_onset <- lm(
  make_formula("sustained_onset",rhs),
  data=onset_data
)

m_persist <- glm(
  make_formula("persistence_to_2022",rhs),
  data=persistence_data,
  family=quasibinomial(link="logit"),
  weights=exposure_years
)

m_ret <- glm(
  make_formula("contemporary_retention",rhs),
  data=retention_data,
  family=quasibinomial(link="logit")
)

# Common-complete onset sensitivity.
m_onset_common <- lm(
  make_formula("sustained_onset",rhs),
  data=common_complete
)

h2_models <- bind_rows(
  tidy_robust(m_onset,"onset_primary_outcome_specific",FALSE),
  tidy_robust(m_persist,"persistence_primary_outcome_specific",TRUE),
  tidy_robust(m_ret,"retention_primary_outcome_specific",TRUE),
  tidy_robust(m_onset_common,"onset_common_complete_sensitivity",FALSE)
)

write_csv(
  h2_models,
  file.path(OUT_DIR,"H2_FINAL_OUTCOME_SPECIFIC_MODELS.csv")
)

# Outcome-specific descriptive statistics.
h2_desc <- bind_rows(
  onset_data %>%
    group_by(pathway_binary) %>%
    summarise(
      outcome="sustained_onset",
      n=n(),
      median=median(sustained_onset),
      IQR=IQR(sustained_onset),
      .groups="drop"
    ),
  persistence_data %>%
    group_by(pathway_binary) %>%
    summarise(
      outcome="persistence_to_2022",
      n=n(),
      median=median(persistence_to_2022),
      IQR=IQR(persistence_to_2022),
      .groups="drop"
    ),
  retention_data %>%
    group_by(pathway_binary) %>%
    summarise(
      outcome="contemporary_retention",
      n=n(),
      median=median(contemporary_retention),
      IQR=IQR(contemporary_retention),
      .groups="drop"
    )
)

write_csv(
  h2_desc,
  file.path(OUT_DIR,"H2_FINAL_OUTCOME_SPECIFIC_DESCRIPTIVE.csv")
)

# Boundary-choice sensitivity for onset.
term_metrics_hard <- main_hard %>%
  group_by(row_id) %>%
  group_modify(~calc_term_metrics(.x)) %>%
  ungroup() %>%
  left_join(
    term_meta %>%
      select(
        row_id,term,pathway_binary,domain3,
        token_count,query_risk,case_insensitive
      ),
    by="row_id"
  ) %>%
  mutate(
    token_count_c=token_count-mean(token_count,na.rm=TRUE),
    pathway_binary=factor(
      pathway_binary,
      levels=c("source_form","pure_calque")
    ),
    domain3=factor(
      domain3,
      levels=c(
        "material_practice",
        "symbolic_ideational",
        "social_political_modern"
      )
    ),
    query_risk=factor(query_risk,levels=c("low","moderate")),
    case_insensitive=factor(case_insensitive)
  ) %>%
  filter(
    !is.na(pathway_binary),!is.na(domain3),
    !is.na(sustained_onset),!is.na(token_count_c),
    !is.na(query_risk),!is.na(case_insensitive)
  ) %>%
  mutate(
    pathway_binary=relevel(pathway_binary,ref="source_form"),
    domain3=relevel(domain3,ref="material_practice"),
    query_risk=relevel(query_risk,ref="low")
  )

m_onset_hard <- lm(
  make_formula("sustained_onset",rhs),
  data=term_metrics_hard
)

boundary_sensitivity <- bind_rows(
  tidy_robust(m_onset,"conservative_observation_starts",FALSE),
  tidy_robust(m_onset_hard,"hard_object_guardrails_only",FALSE)
) %>%
  filter(term=="pathway_binarypure_calque") %>%
  mutate(
    n=c(nobs(m_onset),nobs(m_onset_hard))
  )

write_csv(
  boundary_sensitivity,
  file.path(OUT_DIR,"H2_BOUNDARY_CHOICE_SENSITIVITY.csv")
)


# ------------------------------------------------------------
# 11. FIXED 20- AND 30-YEAR PERSISTENCE:
#     N, EXACT P, EFFECT SIZE, BOOTSTRAP CI
# ------------------------------------------------------------
# Effect size = Cliff's delta (equivalent pairwise dominance / rank-
# biserial direction for two independent groups). Positive values mean
# higher persistence for pure_calque than source_form.

cliffs_delta <- function(source, calque) {
  source <- source[is.finite(source)]
  calque <- calque[is.finite(calque)]
  if(length(source)==0 || length(calque)==0) return(NA_real_)

  diffs <- outer(calque,source,"-")
  (sum(diffs>0)-sum(diffs<0))/length(diffs)
}

bootstrap_delta <- function(source,calque,B=5000L,seed=20261029L) {
  source <- source[is.finite(source)]
  calque <- calque[is.finite(calque)]
  set.seed(seed)
  vals <- replicate(B,{
    s <- sample(source,length(source),replace=TRUE)
    c <- sample(calque,length(calque),replace=TRUE)
    cliffs_delta(s,c)
  })
  c(
    estimate=cliffs_delta(source,calque),
    ci_low=quantile(vals,.025,names=FALSE),
    ci_high=quantile(vals,.975,names=FALSE)
  )
}

fixed_one <- function(outcome,label) {
  d <- term_metrics %>%
    filter(
      !is.na(pathway_binary),
      !is.na(.data[[outcome]])
    )

  s <- d %>%
    filter(pathway_binary=="source_form") %>%
    pull(all_of(outcome))

  c <- d %>%
    filter(pathway_binary=="pure_calque") %>%
    pull(all_of(outcome))

  wt <- wilcox.test(c,s,exact=FALSE)
  eff <- bootstrap_delta(s,c,B=5000L)

  tibble(
    window=label,
    n_source_form=length(s),
    n_pure_calque=length(c),
    median_source_form=median(s),
    IQR_source_form=IQR(s),
    median_pure_calque=median(c),
    IQR_pure_calque=IQR(c),
    wilcoxon_W=unname(wt$statistic),
    p_value=wt$p.value,
    cliffs_delta=unname(eff["estimate"]),
    delta_ci_low=unname(eff["ci_low"]),
    delta_ci_high=unname(eff["ci_high"])
  )
}

fixed_summary <- bind_rows(
  fixed_one("persistence_20y","20_year"),
  fixed_one("persistence_30y","30_year")
)

write_csv(
  fixed_summary,
  file.path(OUT_DIR,"FIXED_WINDOW_COMPLETE_REPORT.csv")
)

# Adjusted fixed-window models remain supplementary.
fit_fixed <- function(outcome,label) {
  d <- term_metrics %>%
    filter(
      !is.na(pathway_binary), !is.na(domain3),
      !is.na(.data[[outcome]]),
      !is.na(token_count_c), !is.na(query_risk),
      !is.na(case_insensitive)
    ) %>%
    mutate(
      pathway_binary=relevel(
        factor(pathway_binary,levels=c("source_form","pure_calque")),
        ref="source_form"
      ),
      domain3=relevel(domain3,ref="material_practice"),
      query_risk=relevel(query_risk,ref="low")
    )

  m <- glm(
    make_formula(outcome,rhs),
    data=d,
    family=quasibinomial(link="logit")
  )

  tidy_robust(m,label,TRUE)
}

fixed_models <- bind_rows(
  fit_fixed("persistence_20y","fixed_20y"),
  fit_fixed("persistence_30y","fixed_30y")
)

write_csv(
  fixed_models,
  file.path(OUT_DIR,"FIXED_WINDOW_ADJUSTED_MODELS.csv")
)


# ------------------------------------------------------------
# 12. ONSET-DEFINITION / LOW-RISK SENSITIVITY
# ------------------------------------------------------------
fit_onset_alt <- function(outcome,label) {
  d <- term_metrics %>%
    filter(
      !is.na(pathway_binary),!is.na(domain3),
      !is.na(.data[[outcome]])
    ) %>%
    mutate(
      pathway_binary=relevel(pathway_binary,ref="source_form"),
      domain3=relevel(domain3,ref="material_practice"),
      query_risk=relevel(query_risk,ref="low")
    )
  m <- lm(make_formula(outcome,rhs),data=d)
  tidy_robust(m,label,FALSE)
}

onset_sens <- bind_rows(
  fit_onset_alt("sustained_onset","3of5"),
  fit_onset_alt("sustained_onset_4of5","4of5"),
  fit_onset_alt("sustained_onset_3consecutive","3_consecutive")
)

low <- onset_data %>% filter(query_risk=="low") %>% droplevels()

low_rhs <- c(
  "pathway_binary","domain3","token_count_c","case_insensitive"
)

low_onset <- lm(
  make_formula("sustained_onset",low_rhs),
  data=low
)

write_csv(
  onset_sens,
  file.path(OUT_DIR,"ONSET_DEFINITION_SENSITIVITY.csv")
)
write_csv(
  tidy_robust(low_onset,"low_query_risk",FALSE),
  file.path(OUT_DIR,"LOW_QUERY_RISK_ONSET_MODEL.csv")
)


# ------------------------------------------------------------
# 13. RQ1: FULL DECADES ONLY; 2020-2022 SEPARATE
# ------------------------------------------------------------
panel <- main1 %>%
  left_join(
    term_metrics %>%
      select(row_id,sustained_onset,pathway_binary),
    by="row_id"
  )

decade <- panel %>%
  filter(year <= 2019) %>%
  mutate(decade=floor(year/10)*10) %>%
  group_by(row_id,term,cultural_domain,decade) %>%
  summarise(
    n_years=n(),
    positive_years=sum(frequency>0,na.rm=TRUE),
    active=positive_years >= ceiling(.30*n_years),
    .groups="drop"
  ) %>%
  filter(active) %>%
  count(decade,cultural_domain,name="active_terms") %>%
  group_by(decade) %>%
  mutate(
    all_active_terms=sum(active_terms),
    domain_share=active_terms/all_active_terms
  ) %>%
  ungroup()

recent2020 <- panel %>%
  filter(year>=2020,year<=2022) %>%
  group_by(row_id,term,cultural_domain) %>%
  summarise(
    n_years=n(),
    positive_years=sum(frequency>0,na.rm=TRUE),
    active=positive_years >= ceiling(.30*n_years),
    .groups="drop"
  ) %>%
  filter(active) %>%
  count(cultural_domain,name="active_terms") %>%
  mutate(period="2020-2022")

write_csv(decade,file.path(OUT_DIR,"RQ1_FULL_DECADES.csv"))
write_csv(recent2020,file.path(OUT_DIR,"RQ1_2020_2022_SUPPLEMENT.csv"))


# ------------------------------------------------------------
# 14. RQ2: DESCRIPTIVE LONG-TERM TRAJECTORIES
# ------------------------------------------------------------
traj <- panel %>%
  filter(!is.na(pathway_binary)) %>%
  mutate(
    frequency_per_billion=frequency*1e9,
    log_frequency=log1p(frequency_per_billion)
  ) %>%
  group_by(row_id) %>%
  mutate(
    mu=mean(log_frequency,na.rm=TRUE),
    s=sd(log_frequency,na.rm=TRUE),
    z=if_else(is.finite(s)&s>0,(log_frequency-mu)/s,0)
  ) %>%
  ungroup() %>%
  mutate(term_factor=factor(row_id)) %>%
  arrange(row_id,year) %>%
  group_by(row_id) %>%
  mutate(AR_start=row_number()==1L) %>%
  ungroup()

bam0 <- mgcv::bam(
  z ~ pathway_binary +
    s(year,by=pathway_binary,k=15) +
    s(term_factor,bs="re"),
  data=traj, method="fREML", discrete=TRUE
)

traj$resid0 <- residuals(bam0)

rho_terms <- traj %>%
  group_by(row_id) %>%
  summarise(
    rho=if(n()>=3 && sd(resid0,na.rm=TRUE)>0) {
      suppressWarnings(cor(
        resid0[-n()],resid0[-1],use="complete.obs"
      ))
    } else NA_real_,
    .groups="drop"
  )

rho_hat <- median(rho_terms$rho,na.rm=TRUE)
if(!is.finite(rho_hat)) rho_hat <- 0
rho_hat <- max(0,min(.90,rho_hat))

bam1 <- mgcv::bam(
  z ~ pathway_binary +
    s(year,by=pathway_binary,k=15) +
    s(term_factor,bs="re"),
  data=traj, method="fREML", discrete=TRUE,
  rho=rho_hat, AR.start=traj$AR_start
)

capture.output(
  summary(bam1),
  file=file.path(OUT_DIR,"RQ2_BAM_AR1_SUMMARY.txt")
)


# ------------------------------------------------------------
# 15. RQ3: ALL INTERACTIONS + SIMPLE EFFECTS
# ------------------------------------------------------------
cells <- onset_data %>%
  count(cultural_domain,pathway_binary,name="n") %>%
  complete(cultural_domain,pathway_binary,fill=list(n=0))

eligible_domains <- cells %>%
  group_by(cultural_domain) %>%
  summarise(min_n=min(n),.groups="drop") %>%
  filter(min_n>=3) %>%
  pull(cultural_domain)

write_csv(cells,file.path(OUT_DIR,"RQ3_DOMAIN_CELLS.csv"))

rq3_all <- tibble()
rq3_simple <- tibble()

if(length(eligible_domains)>=2) {
  d3 <- onset_data %>%
    filter(cultural_domain %in% eligible_domains) %>%
    mutate(
      domain_interaction=factor(cultural_domain),
      domain_interaction=relevel(
        domain_interaction,
        ref=sort(unique(as.character(domain_interaction)))[1]
      )
    )

  m3 <- lm(
    sustained_onset ~ pathway_binary*domain_interaction +
      token_count_c + query_risk + case_insensitive,
    data=d3
  )

  rq3_all <- tidy_robust(m3,"RQ3_all_coefficients",FALSE)
  write_csv(
    rq3_all,
    file.path(OUT_DIR,"RQ3_ALL_INTERACTION_COEFFICIENTS.csv")
  )

  vc <- sandwich::vcovHC(m3,type="HC3")
  b <- coef(m3)
  cn <- names(b)

  simple_one <- function(dom) {
    L <- rep(0,length(b)); names(L)<-cn
    L["pathway_binarypure_calque"] <- 1

    ref <- levels(d3$domain_interaction)[1]
    if(dom != ref) {
      int1 <- paste0(
        "pathway_binarypure_calque:domain_interaction",dom
      )
      int2 <- paste0(
        "domain_interaction",dom,":pathway_binarypure_calque"
      )
      if(int1 %in% cn) L[int1] <- 1
      if(int2 %in% cn) L[int2] <- 1
    }

    est <- sum(L*b)
    se <- sqrt(as.numeric(t(L)%*%vc%*%L))
    tibble(
      cultural_domain=dom,
      b_years=est,
      se_hc3=se,
      ci_low=est-1.96*se,
      ci_high=est+1.96*se,
      z=est/se,
      p=2*pnorm(abs(est/se),lower.tail=FALSE)
    )
  }

  rq3_simple <- map_dfr(
    levels(d3$domain_interaction),
    simple_one
  )

  write_csv(
    rq3_simple,
    file.path(OUT_DIR,"RQ3_WITHIN_DOMAIN_SIMPLE_EFFECTS.csv")
  )
}


# ------------------------------------------------------------
# 16. RQ4: MULTI-NAME CASES + DIRECT-LABEL FIGURE
# ------------------------------------------------------------
concepts <- term_metrics %>%
  filter(!is.na(concept_group),concept_group!="") %>%
  group_by(concept_group) %>%
  summarise(
    n=n_distinct(row_id),
    has_source=any(pathway=="source_form"),
    has_calque=any(pathway=="pure_calque"),
    has_mixed=any(pathway=="mixed"),
    .groups="drop"
  ) %>%
  filter(n>=2)

rq4_metrics <- term_metrics %>%
  filter(concept_group %in% concepts$concept_group) %>%
  select(
    concept_group,row_id,term,pathway,
    sustained_onset,persistence_20y,persistence_30y,
    persistence_to_2022,contemporary_retention
  )

write_csv(
  rq4_metrics,
  file.path(OUT_DIR,"RQ4_MULTI_NAME_METRICS.csv")
)

pair_panel <- panel %>%
  filter(concept_group %in% concepts$concept_group) %>%
  group_by(row_id) %>%
  mutate(
    peak=max(frequency,na.rm=TRUE),
    relative_to_own_peak=if_else(
      is.finite(peak)&peak>0, frequency/peak, 0
    )
  ) %>%
  ungroup()

end_labels <- pair_panel %>%
  group_by(concept_group,term) %>%
  filter(year==max(year)) %>%
  slice_tail(n=1) %>%
  ungroup()

p4 <- ggplot(
  pair_panel,
  aes(x=year,y=relative_to_own_peak,group=term,linetype=term)
) +
  geom_line(linewidth=.55) +
  facet_wrap(~concept_group,scales="free_y") +
  ggrepel::geom_text_repel(
    data=end_labels,
    aes(label=term),
    size=2.4,
    direction="y",
    hjust=0,
    nudge_x=3,
    segment.size=.2,
    show.legend=FALSE
  ) +
  coord_cartesian(xlim=c(YEAR_START,YEAR_END+18),clip="off") +
  scale_y_continuous(labels=percent_format(accuracy=1)) +
  labs(
    x="Year",
    y="Frequency relative to each form's own historical peak",
    linetype="English form"
  ) +
  theme(plot.margin=margin(5.5,90,5.5,5.5))

ggsave(
  file.path(OUT_DIR,"Figure_4_DIRECT_LABELS.png"),
  p4,width=11,height=8,dpi=600
)


# ------------------------------------------------------------
# 17. HISTORICAL VARIANT AUDIT
# ------------------------------------------------------------
hist_effect <- tibble()
delta_boot <- tibble()

if(
  !is.na(HIST_VARIANTS_FILE) && file.exists(HIST_VARIANTS_FILE) &&
  !is.na(HIST_MAP_FILE) && file.exists(HIST_MAP_FILE)
) {

  hmap <- suppressMessages(
    read_csv(HIST_MAP_FILE,show_col_types=FALSE)
  )

  # Default: NOT VERIFIED, therefore excluded from union.
  # Positive cases currently supported by a historical target-sense source:
  #   dao -> Tao (James Legge, 1891)
  #   huangjiu -> huang chiu (Robert Coltman, 1891, pp. 122-124)
  # Negative/high-risk controls explicitly blocked:
  #   Nian -> Nien
  #   tangzhong -> t'ang chung / tang chung

  hist_audit <- hmap %>%
    mutate(
      variant_status=case_when(
        term=="dao" & historical_variant=="Tao" ~ "verified",
        term=="huangjiu" &
          tolower(historical_variant)=="huang chiu" ~ "verified",
        term=="Nian" &
          tolower(historical_variant)=="nien" ~ "blocked_semantic_risk",
        term=="tangzhong" &
          tolower(historical_variant) %in%
          c("t'ang chung","tang chung") ~ "blocked_semantic_risk",
        TRUE ~ "unverified_do_not_use"
      ),
      variant_valid_from_year=case_when(
        term=="dao" & historical_variant=="Tao" ~ 1891L,
        term=="huangjiu" &
          tolower(historical_variant)=="huang chiu" ~ 1891L,
        TRUE ~ NA_integer_
      ),
      evidence_note=case_when(
        term=="dao" & historical_variant=="Tao" ~
          "James Legge, The Texts of Taoism (1891): target philosophical/Daoist use.",
        term=="huangjiu" &
          tolower(historical_variant)=="huang chiu" ~
          "Robert Coltman, The Chinese, Their Present and Future (1891), pp.122-124: 'huang chiu' explicitly glossed as yellow wine.",
        term=="Nian" &
          tolower(historical_variant)=="nien" ~
          "Blocked: early Nien can mean 'year' or other referents; no early target year-beast evidence established.",
        term=="tangzhong" &
          tolower(historical_variant) %in%
          c("t'ang chung","tang chung") ~
          "Blocked: spelling equivalence alone does not establish early bread-technique sense.",
        TRUE ~
          "No token-level historical target-sense validation supplied; excluded from validated union."
      )
    )

  write_csv(
    hist_audit,
    file.path(OUT_DIR,"HISTORICAL_VARIANT_AUDIT.csv")
  )

  hv <- suppressMessages(
    read_csv(HIST_VARIANTS_FILE,show_col_types=FALSE)
  ) %>%
    mutate(
      row_id=as.integer(row_id),
      year=as.integer(year),
      frequency=as.numeric(frequency)
    ) %>%
    inner_join(
      hist_audit %>%
        filter(variant_status=="verified") %>%
        select(
          term,
          variant=historical_variant,
          variant_valid_from_year
        ),
      by=c("term","variant")
    ) %>%
    filter(year >= variant_valid_from_year)

  verified_pos <- hv %>%
    group_by(row_id,year) %>%
    summarise(
      historical_positive=any(frequency>0,na.rm=TRUE),
      .groups="drop"
    )

  current_valid <- main1 %>%
    transmute(
      row_id,year,current_positive=frequency>0
    )

  verified_start <- hv %>%
    group_by(row_id) %>%
    summarise(
      variant_start=min(variant_valid_from_year),
      .groups="drop"
    )

  family_start <- term_meta %>%
    select(row_id,audited_valid_from) %>%
    left_join(verified_start,by="row_id") %>%
    mutate(
      family_valid_from=if_else(
        !is.na(variant_start),
        pmin(audited_valid_from,variant_start),
        audited_valid_from
      )
    )

  grid <- family_start %>%
    rowwise() %>%
    mutate(years=list(seq(family_valid_from,YEAR_END))) %>%
    unnest(years) %>%
    rename(year=years) %>%
    ungroup()

  fam_panel <- grid %>%
    left_join(current_valid,by=c("row_id","year")) %>%
    left_join(verified_pos,by=c("row_id","year")) %>%
    mutate(
      current_positive=coalesce(current_positive,FALSE),
      historical_positive=coalesce(historical_positive,FALSE),
      family_positive=current_positive|historical_positive
    )

  fam_onset <- fam_panel %>%
    group_by(row_id) %>%
    summarise(
      onset_family_verified=calc_sustained_indicator(
        year,family_positive,MAIN_WINDOW,MAIN_MIN_POSITIVE
      ),
      .groups="drop"
    )

  hist_dat <- onset_data %>%
    select(
      row_id,term,pathway_binary,domain3,
      token_count_c,query_risk,case_insensitive,
      onset_current=sustained_onset
    ) %>%
    left_join(fam_onset,by="row_id") %>%
    filter(
      !is.na(onset_current),
      !is.na(onset_family_verified)
    )

  m_cur <- lm(
    make_formula("onset_current",rhs),
    data=hist_dat
  )
  m_fam <- lm(
    make_formula("onset_family_verified",rhs),
    data=hist_dat
  )

  extract_path <- function(m,label) {
    tidy_robust(m,label,FALSE) %>%
      filter(term=="pathway_binarypure_calque") %>%
      transmute(
        model=label,n=nobs(m),
        b=estimate,se_hc3=std_error,
        ci_low=conf_low,ci_high=conf_high,p=p_value
      )
  }

  hist_effect <- bind_rows(
    extract_path(m_cur,"current_spelling_audited"),
    extract_path(m_fam,"verified_historical_variants_only")
  )

  write_csv(
    hist_effect,
    file.path(OUT_DIR,"HISTORICAL_SPELLING_VERIFIED_EFFECT.csv")
  )

  # Paired bootstrap of attenuation delta:
  # delta = b_family - b_current.
  # Positive delta means the negative calque coefficient moves toward zero.
  coef_path <- function(d,outcome) {
    tryCatch({
      m <- lm(make_formula(outcome,rhs),data=d)
      unname(coef(m)["pathway_binarypure_calque"])
    }, error=function(e) NA_real_)
  }

  set.seed(20261029)
  boots <- map_dfr(seq_len(BOOT_B),function(bi){
    idx <- sample(seq_len(nrow(hist_dat)),replace=TRUE)
    db <- hist_dat[idx,,drop=FALSE]
    bc <- coef_path(db,"onset_current")
    bf <- coef_path(db,"onset_family_verified")
    tibble(
      replicate=bi,
      b_current=bc,
      b_family=bf,
      delta_b=bf-bc
    )
  }) %>%
    filter(is.finite(delta_b))

  delta_boot <- tibble(
    B=nrow(boots),
    delta_b_mean=mean(boots$delta_b),
    delta_b_median=median(boots$delta_b),
    ci_low=quantile(boots$delta_b,.025,names=FALSE),
    ci_high=quantile(boots$delta_b,.975,names=FALSE),
    verified_variant_terms=n_distinct(hv$row_id)
  )

  write_csv(
    boots,
    file.path(OUT_DIR,"HISTORICAL_SPELLING_DELTA_BOOTSTRAP_DRAWS.csv")
  )
  write_csv(
    delta_boot,
    file.path(OUT_DIR,"HISTORICAL_SPELLING_DELTA_BOOTSTRAP_SUMMARY.csv")
  )
}


# ------------------------------------------------------------
# 18. EXAMPLE / EVIDENCE AUDIT TABLE FOR MANUSCRIPT
# ------------------------------------------------------------
example_audit <- tribble(
  ~evidence_task, ~term_or_pair, ~status, ~source_note,
  "pathway_boundary","Qingming Festival","verified",
  "Wiktionary: partial calque; Qingming + English Festival.",
  "pathway_boundary","Mid-Autumn Festival","verified",
  "Wiktionary: calque of Chinese 中秋節/中秋节.",
  "date_boundary","Belt and Road","verified",
  "Official Chinese agencies standardized 'the Belt and Road' / 'Belt and Road Initiative' in 2015.",
  "date_boundary","brainwashing","verified",
  "Oxford University Press: term first recorded in 1950.",
  "date_boundary","Eighth Route Army","verified",
  "Agnes Smedley, China Fights Back: An American Woman with the Eighth Route Army (1938); unit created in 1937.",
  "date_boundary","Great Leap Forward","verified",
  "1959 U.S. historical document explicitly discusses China's 1958 'great leap forward' program.",
  "historical_variant","dao / Tao","verified_positive",
  "James Legge, The Texts of Taoism (1891), target philosophical/Daoist usage.",
  "historical_variant","huangjiu / huang chiu","verified_positive",
  "Robert Coltman (1891), pp.122-124, explicitly glosses 'huang chiu' as yellow wine.",
  "historical_variant","Nian / Nien","negative_control",
  "Do not union early Nien hits without token-level evidence for the year-beast sense.",
  "historical_variant","tangzhong / tang chung","negative_control",
  "Do not union early tang chung hits without token-level evidence for the bread-technique sense.",
  "co_reference","Monkey King / Sun Wukong","verified_modern",
  "Penguin description: the Monkey King is called Sun Wukong."
)

write_csv(
  example_audit,
  file.path(OUT_DIR,"MANUSCRIPT_EXAMPLE_EVIDENCE_AUDIT.csv")
)


# ------------------------------------------------------------
# 19. FINAL SUMMARY + VERSION MANIFEST
# ------------------------------------------------------------
path_counts <- path_audit %>% count(pathway_final)

h2_key <- h2_models %>%
  filter(
    model=="onset_primary_outcome_specific",
    term=="pathway_binarypure_calque"
  )

common_key <- h2_models %>%
  filter(
    model=="onset_common_complete_sensitivity",
    term=="pathway_binarypure_calque"
  )

hist_note <- if(nrow(hist_effect)>0) {
  paste(
    capture.output(print(hist_effect)),
    collapse="\n"
  )
} else "Not run / historical files unavailable."

delta_note <- if(nrow(delta_boot)>0) {
  paste(
    capture.output(print(delta_boot)),
    collapse="\n"
  )
} else "Not available."

summary_lines <- c(
  "FINAL SUBMISSION ANALYSIS",
  "=========================",
  "",
  paste0("Input semantic-clean data: ",FINAL_ANNUAL_FILE),
  paste0("Primary final annual rows: ",nrow(main1)),
  paste0("Primary final retained terms: ",n_distinct(main1$row_id)),
  "",
  "PATHWAY CODING:",
  paste(capture.output(print(path_counts)),collapse="\n"),
  "Targeted independent review workbook generated:",
  file.path(OUT_DIR,"PATHWAY_TARGETED_INDEPENDENT_REVIEW.xlsx"),
  "",
  paste0(
    "H1: chi-square=",round(h1_test$chi_square,3),
    ", df=",h1_test$df,
    ", Monte Carlo p=",format.pval(h1_test$p_monte_carlo,digits=4),
    ", Cramer's V=",round(h1_test$cramers_v,3),
    ", n=",h1_test$n
  ),
  "",
  paste0(
    "H2 onset PRIMARY outcome-specific sample: n=",nrow(onset_data),
    "; b=",round(h2_key$estimate,2),
    "; HC3 SE=",round(h2_key$std_error,2),
    "; 95% CI [",round(h2_key$conf_low,2),", ",
    round(h2_key$conf_high,2),"]; p=",
    format.pval(h2_key$p_value,digits=4)
  ),
  paste0(
    "H2 onset common-complete sensitivity: n=",nrow(common_complete),
    "; b=",round(common_key$estimate,2),
    "; p=",format.pval(common_key$p_value,digits=4)
  ),
  paste0(
    "Persistence model n=",nrow(persistence_data),
    "; contemporary retention model n=",nrow(retention_data)
  ),
  "",
  "FIXED-WINDOW COMPLETE REPORT:",
  paste(capture.output(print(fixed_summary)),collapse="\n"),
  "",
  "BOUNDARY-CHOICE SENSITIVITY:",
  paste(capture.output(print(boundary_sensitivity)),collapse="\n"),
  "",
  "HISTORICAL SPELLING:",
  hist_note,
  "",
  "PAIRED ATTENUATION DELTA-B BOOTSTRAP:",
  delta_note,
  "",
  "INTERPRETIVE RULE:",
  "If the delta-b 95% interval includes 0, report that the verified variants move the point estimate toward zero but the attenuation magnitude remains uncertain.",
  "",
  "DATE-EVIDENCE RULE:",
  "Object-formation guardrails, verified examples, official standardization years, and adopted analysis starts are separate evidence types.",
  "The primary sustained onset is explicitly the onset WITHIN the adopted observation range, not a claim about the true first English use.",
  "",
  "VERSION RULE:",
  "Only files in FINAL_SUBMISSION_OUTPUTS should be used for manuscript tables, figures, data sharing, and repository upload."
)

write_txt(
  summary_lines,
  file.path(OUT_DIR,"00_FINAL_SUBMISSION_RESULTS_SUMMARY.txt")
)

# Version manifest with checksums for reproducibility.
manifest_paths <- c(
  FINAL_ANNUAL_FILE,
  HIST_VARIANTS_FILE,
  HIST_MAP_FILE,
  LEXICON_FILE,
  file.path(OUT_DIR,"FINAL_SUBMISSION_ANNUAL_DATA.csv"),
  file.path(OUT_DIR,"PATHWAY_FINAL_AUDIT.csv"),
  file.path(OUT_DIR,"DATE_EVIDENCE_MATRIX.csv"),
  file.path(OUT_DIR,"H2_FINAL_OUTCOME_SPECIFIC_MODELS.csv"),
  file.path(OUT_DIR,"FIXED_WINDOW_COMPLETE_REPORT.csv"),
  file.path(OUT_DIR,"RQ3_ALL_INTERACTION_COEFFICIENTS.csv"),
  file.path(OUT_DIR,"RQ3_WITHIN_DOMAIN_SIMPLE_EFFECTS.csv"),
  file.path(OUT_DIR,"HISTORICAL_VARIANT_AUDIT.csv"),
  file.path(OUT_DIR,"HISTORICAL_SPELLING_VERIFIED_EFFECT.csv"),
  file.path(OUT_DIR,"HISTORICAL_SPELLING_DELTA_BOOTSTRAP_SUMMARY.csv")
)

manifest_paths <- manifest_paths[
  !is.na(manifest_paths) & file.exists(manifest_paths)
]

version_manifest <- tibble(
  file=normalizePath(manifest_paths,winslash="/",mustWork=FALSE),
  basename=basename(manifest_paths),
  size_bytes=file.info(manifest_paths)$size,
  modified=file.info(manifest_paths)$mtime,
  md5=unname(tools::md5sum(manifest_paths))
)

write_csv(
  version_manifest,
  file.path(OUT_DIR,"VERSION_MANIFEST.csv")
)

saveRDS(
  list(
    H2_onset=m_onset,
    H2_onset_common=m_onset_common,
    H2_persistence=m_persist,
    H2_retention=m_ret,
    H2_onset_hard_guardrail=m_onset_hard,
    RQ2_bam=bam1,
    RQ3=if(exists("m3")) m3 else NULL,
    hist_current=if(exists("m_cur")) m_cur else NULL,
    hist_verified=if(exists("m_fam")) m_fam else NULL
  ),
  file.path(OUT_DIR,"FINAL_SUBMISSION_MODELS.rds")
)

capture.output(
  sessionInfo(),
  file=file.path(OUT_DIR,"sessionInfo_FINAL_SUBMISSION.txt")
)

cat("\n====================================================\n")
cat("FINAL SUBMISSION ANALYSIS COMPLETE\n")
cat("Output:",OUT_DIR,"\n")
cat("First open: 00_FINAL_SUBMISSION_RESULTS_SUMMARY.txt\n")
cat("Human step still required before final manuscript lock:\n")
cat("  PATHWAY_TARGETED_INDEPENDENT_REVIEW.xlsx\n")
cat("====================================================\n")
